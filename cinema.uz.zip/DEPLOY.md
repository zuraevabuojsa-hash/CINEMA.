# 🚀 CinemaUz loyihasini Deploy qilish bo'yicha To'liq Qo'llanma

Ushbu loyiha 2 qismdan iborat:
1. **Backend**: Node.js + Express + Socket.IO (WebSocket va WebRTC uchun doimiy server talab qiladi) -> **Render.com** (bepul)
2. **Frontend**: Next.js 14 App Router -> **Vercel** (bepul, yuqori tezlik)

---

## 📌 1-Qadam: Loyihani GitHub-ga joylash

Render va Vercel avtomatik deploy qilishi uchun eng qulay yo'l — GitHub repozitoriyasi.

1. [github.com](https://github.com) ga kiring va yangi bo'sh repozitoriy oching (masalan, `cinema-app`).
2. Agar kompyuteringizda Git o'rnatilmagan bo'lsa:
   - [Git for Windows](https://git-scm.com/download/win) yoki [GitHub Desktop](https://desktop.github.com) dasturini yuklab oling.
3. Loyiha papkasida terminalni ochib, quyidagi buyruqlarni bajaring:
   ```bash
   git init
   git add .
   git commit -m "Initial commit for deployment"
   git branch -M main
   git remote add origin https://github.com/SIZNING_USERNAME/cinema-app.git
   git push -u origin main
   ```

*(Eslatma: `cinema-frontend.zip` va `node_modules` avtomatik tarzda e'tibordan chetda qoldiriladi).*

---

## 📌 2-Qadam: Backend-ni Render.com ga deploy qilish

> ⚠️ **Muhim**: Avval backend deploy qilinadi, chunki uning jonli URL manzili frontendga kerak bo'ladi.

1. [dashboard.render.com](https://dashboard.render.com) ga kiring (GitHub orqali bepul ro'yxatdan o'tish mumkin).
2. **"New +"** tugmasini bosing va **"Web Service"** ni tanlang.
3. GitHub-dagi `cinema-app` repozitoriyangizni tanlang.
4. Quyidagi sozlamalarni kiriting:
   - **Name**: `cinema-backend` (yoki o'zingiz xohlagan nom)
   - **Region**: Frankfurt (Yevropa — O'zbekiston uchun eng yaqin)
   - **Root Directory**: `backend`
   - **Runtime**: `Node`
   - **Build Command**: `npm install`
   - **Start Command**: `npm start`
   - **Instance Type**: `Free`
5. Pastroqqa tushib, **"Environment Variables"** bo'limiga quyidagilarni qo'shing:
   - `NODE_ENV` = `production`
   - `PORT` = `10000`
   - `JWT_SECRET` = `cinema_super_secret_key_2024_ijtimoiy` *(yoki ixtiyoriy xavfsiz kalit)*
   - `FRONTEND_URL` = `*` *(frontend deploy qilingandan so'ng Vercel domeningizga o'zgartirishingiz mumkin)*
6. **"Deploy Web Service"** tugmasini bosing.
7. Deploy muvaffaqiyatli tugagach, sizga backend URL manzili beriladi (masalan: `https://cinema-backend-xxxx.onrender.com`).
   - Tekshirish uchun brauzerda: `https://cinema-backend-xxxx.onrender.com/api/health` manzilini oching.
   - Natija: `{"success": true, "message": "Server ishlayapti"}` ko'rinishida bo'lishi kerak.

---

## 📌 3-Qadam: Frontend-ni Vercel-ga deploy qilish

1. [vercel.com](https://vercel.com) ga kiring va GitHub orqali kiring.
2. **"Add New..."** -> **"Project"** tugmasini bosing.
3. GitHub-dagi `cinema-app` repozitoriyasini tanlang va **"Import"** ni bosing.
4. **Configure Project** oynasida:
   - **Root Directory**: Yonidagi **"Edit"** tugmasini bosing va `frontend` papkasini tanlang.
   - **Framework Preset**: `Next.js` (avtomatik aniqlanadi).
5. **"Environment Variables"** bo'limini oching va quyidagi 3 ta o'zgaruvchini qo'shing:
   - `NEXT_PUBLIC_API_URL` = `https://cinema-backend-xxxx.onrender.com/api` *(Render'dagi backend URL + /api)*
   - `NEXT_PUBLIC_WS_URL` = `https://cinema-backend-xxxx.onrender.com` *(Render'dagi backend URL)*
   - `NEXT_PUBLIC_APP_NAME` = `CinemaUz`
6. **"Deploy"** tugmasini bosing.
7. 1-2 daqiqada Next.js build bo'lib, sizga jonli domen beriladi (masalan: `https://cinema-frontend-xxxx.vercel.app`).

---

## 📌 4-Qadam: Backend CORS sozlamasini yangilash (Xavfsizlik)

1. [dashboard.render.com](https://dashboard.render.com) ga qaytib, `cinema-backend` xizmatiga kiring.
2. **Environment** bo'limiga o'ting.
3. `FRONTEND_URL` qiymatini Vercel tomonidan berilgan domenga o'zgartiring:
   - Masalan: `https://cinema-frontend-xxxx.vercel.app`
4. **"Save Changes"** ni bosing — backend avtomatik qayta ishga tushadi.

---

## 🎬 Tizimni tekshirish

Saytga kiring va quyidagi demo foydalanuvchilar orqali tizimni sinab ko'ring:

| Email | Parol | Rol |
|-------|-------|-----|
| `admin@cinema.uz` | `admin123` | Admin |
| `sardor@test.uz` | `test123` | Foydalanuvchi |
| `malika@test.uz` | `test123` | Foydalanuvchi |

### Sinovdan o'tkazish kerak bo'lgan asosiy funksiyalar:
- [x] Ro'yxatdan o'tish va tizimga kirish (JWT token)
- [x] Kinolar katalogini ko'rish va qidirish
- [x] Birga tomosha qilish xonasi ochish (`/watch-together`)
- [x] Ikki xil brauzerda bir xil xonaga kirib, video sinxronlash (Play/Pause/Seek)
- [x] Real vaqtli chat va ovozli suhbat (WebRTC)
