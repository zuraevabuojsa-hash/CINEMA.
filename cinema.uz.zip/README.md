# CinemaUz – Ijtimoiy Kino Platformasi

Do'stlar bilan birga onlayn kino ko'ring. Real vaqtli sinxronlash, ovozli suhbat va chat.

## Ishga tushirish

### Backend (Port: 5000)
```bash
cd backend
npm install
npm run dev
```

### Frontend (Port: 3000)
```bash
cd frontend
npm install
npm run dev
```

## Demo foydalanuvchilar

| Email | Parol | Rol |
|-------|-------|-----|
| admin@cinema.uz | admin123 | Admin |
| sardor@test.uz | test123 | Foydalanuvchi |
| malika@test.uz | test123 | Foydalanuvchi |

## Asosiy sahifalar

- `/` — Bosh sahifa
- `/movies` — Kinolar katalogi
- `/movies/[id]` — Kino tafsiloti
- `/series` — Seriallar
- `/genres` — Janrlar
- `/watch-together` — Birga ko'rish
- `/watch/[roomCode]` — Kino ko'rish xonasi
- `/friends` — Do'stlar
- `/favorites` — Sevimlilar
- `/history` — Ko'rish tarixi
- `/profile` — Profil
- `/settings` — Sozlamalar
- `/admin` — Admin panel (faqat admin)
- `/login` — Kirish
- `/register` — Ro'yxatdan o'tish

## Texnologiyalar

### Frontend
- Next.js 14 (App Router)
- TypeScript
- Tailwind CSS
- Zustand (state management)
- Socket.IO Client
- WebRTC (ovozli suhbat)

### Backend
- Node.js + Express
- Socket.IO (real vaqt WebSocket)
- JWT autentifikatsiya
- bcryptjs (parol xeshlash)
- In-memory ma'lumotlar (demo)

## Asosiy funksiyalar

1. **Kino ko'rish** — Video pleer (HLS/MP4)
2. **Birga ko'rish xonasi** — 2 kishi sinxron
3. **Ovozli suhbat** — WebRTC peer-to-peer
4. **Sinxron video** — Play/Pause/Seek barcha qurilmalarda
5. **Matnli chat** — Real vaqtli xabarlar
6. **Do'stlar tizimi** — So'rov yuborish, qabul qilish
7. **Bildirishnomalar** — Real vaqtli
8. **Admin panel** — Statistika, foydalanuvchilar, kinolar
