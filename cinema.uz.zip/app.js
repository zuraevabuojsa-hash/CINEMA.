// Game State
let score = 0;
let streak = 0;
let highScore = parseInt(localStorage.getItem('football_high_score')) || 0;
let currentPlayer = null;
let currentLevel = 1;
const maxLevels = 10;
let playedPlayerIds = [];
let soundEnabled = true;

// Clue scoring values
let maxRoundPoints = 100;
let penaltyFlag = 30;
let penaltyLetter = 30;

// UI Elements
const clubCard = document.getElementById('club-card');
const flagCard = document.getElementById('flag-card');
const letterCard = document.getElementById('letter-card');
const flagLock = document.getElementById('flag-lock');
const letterLock = document.getElementById('letter-lock');

const clueClub = document.getElementById('clue-club');
const clueFlag = document.getElementById('clue-flag');
const clueCountry = document.getElementById('clue-country');
const clueLetter = document.getElementById('clue-letter');

const playerGuessInput = document.getElementById('player-guess');
const autocompleteList = document.getElementById('autocomplete-list');

const submitBtn = document.getElementById('submit-btn');
const skipBtn = document.getElementById('skip-btn');
const nextBtn = document.getElementById('next-btn');
const soundToggleBtn = document.getElementById('sound-toggle');
const soundIcon = document.getElementById('sound-icon');

const feedbackScreen = document.getElementById('feedback-screen');
const feedbackIcon = document.getElementById('feedback-icon');
const feedbackStatus = document.getElementById('feedback-status');
const feedbackPlayerName = document.getElementById('feedback-player-name');
const feedbackPlayerMeta = document.getElementById('feedback-player-meta');

const scoreVal = document.getElementById('score-val');
const streakVal = document.getElementById('streak-val');
const highScoreVal = document.getElementById('high-score-val');
const levelDisplay = document.getElementById('level-display');

// Web Audio API for Retro Sound Effects
const audioCtx = new (window.AudioContext || window.webkitAudioContext)();

function playSound(type) {
  if (!soundEnabled) return;
  
  // Resume context if suspended (browser security)
  if (audioCtx.state === 'suspended') {
    audioCtx.resume();
  }

  const osc = audioCtx.createOscillator();
  const gain = audioCtx.createGain();
  osc.connect(gain);
  gain.connect(audioCtx.destination);

  const now = audioCtx.currentTime;

  if (type === 'success') {
    // Upward arpeggio
    osc.type = 'triangle';
    osc.frequency.setValueAtTime(330, now); // E4
    osc.frequency.exponentialRampToValueAtTime(660, now + 0.15); // E5
    osc.frequency.exponentialRampToValueAtTime(990, now + 0.3); // B5
    gain.gain.setValueAtTime(0.15, now);
    gain.gain.exponentialRampToValueAtTime(0.01, now + 0.35);
    osc.start(now);
    osc.stop(now + 0.35);
  } else if (type === 'fail') {
    // Low buzzer
    osc.type = 'sawtooth';
    osc.frequency.setValueAtTime(120, now);
    osc.frequency.linearRampToValueAtTime(80, now + 0.25);
    gain.gain.setValueAtTime(0.2, now);
    gain.gain.exponentialRampToValueAtTime(0.01, now + 0.3);
    osc.start(now);
    osc.stop(now + 0.3);
  } else if (type === 'reveal') {
    // Sci-fi reveal blip
    osc.type = 'sine';
    osc.frequency.setValueAtTime(440, now);
    osc.frequency.exponentialRampToValueAtTime(880, now + 0.1);
    gain.gain.setValueAtTime(0.15, now);
    gain.gain.exponentialRampToValueAtTime(0.01, now + 0.15);
    osc.start(now);
    osc.stop(now + 0.15);
  } else if (type === 'click') {
    // Gentle tap
    osc.type = 'sine';
    osc.frequency.setValueAtTime(600, now);
    gain.gain.setValueAtTime(0.05, now);
    gain.gain.exponentialRampToValueAtTime(0.01, now + 0.05);
    osc.start(now);
    osc.stop(now + 0.05);
  }
}

// Confetti Particle System
const canvas = document.getElementById('confetti-canvas');
const ctx = canvas.getContext('2d');
let particles = [];
let animationFrameId = null;

function resizeCanvas() {
  canvas.width = canvas.parentElement.offsetWidth;
  canvas.height = canvas.parentElement.offsetHeight;
}
window.addEventListener('resize', resizeCanvas);
resizeCanvas();

class ConfettiParticle {
  constructor() {
    this.x = Math.random() * canvas.width;
    this.y = -10 - Math.random() * 20;
    this.size = Math.random() * 8 + 4;
    this.color = `hsl(${Math.random() * 360}, 90%, 60%)`;
    this.speedX = Math.random() * 4 - 2;
    this.speedY = Math.random() * 3 + 2;
    this.rotation = Math.random() * 360;
    this.rotationSpeed = Math.random() * 4 - 2;
    this.opacity = 1;
  }
  update() {
    this.x += this.speedX;
    this.y += this.speedY;
    this.rotation += this.rotationSpeed;
    if (this.y > canvas.height) {
      this.y = -10;
      this.opacity = 1;
    }
  }
  draw() {
    ctx.save();
    ctx.translate(this.x, this.y);
    ctx.rotate((this.rotation * Math.PI) / 180);
    ctx.fillStyle = this.color;
    ctx.globalAlpha = this.opacity;
    ctx.fillRect(-this.size / 2, -this.size / 2, this.size, this.size);
    ctx.restore();
  }
}

function startConfetti() {
  particles = [];
  for (let i = 0; i < 80; i++) {
    particles.push(new ConfettiParticle());
  }
  if (animationFrameId) cancelAnimationFrame(animationFrameId);
  animateConfetti();
}

function animateConfetti() {
  ctx.clearRect(0, 0, canvas.width, canvas.height);
  let active = false;
  particles.forEach(p => {
    p.update();
    p.draw();
    if (p.y > 0) active = true;
  });
  if (active) {
    animationFrameId = requestAnimationFrame(animateConfetti);
  }
}

// Helpers
function sanitizeString(str) {
  return str
    .toLowerCase()
    .normalize("NFD")
    .replace(/[\u0300-\u036f]/g, "") // Remove accents/diacritics
    .replace(/[^a-z0-9]/g, "")      // Keep alphanumeric only
    .trim();
}

// Init score display
highScoreVal.textContent = highScore;

// Load New Player
function initGame() {
  score = 0;
  streak = 0;
  currentLevel = 1;
  playedPlayerIds = [];
  scoreVal.textContent = score;
  streakVal.textContent = streak;
  loadNewPlayer();
}

function loadNewPlayer() {
  feedbackScreen.classList.remove('active', 'correct', 'incorrect');
  playerGuessInput.value = '';
  autocompleteList.classList.remove('active');

  // Reset clue cards state
  flagCard.classList.remove('revealed');
  flagLock.style.display = 'flex';
  letterCard.classList.remove('revealed');
  letterLock.style.display = 'flex';

  // Level Display
  levelDisplay.textContent = `${currentLevel} / ${maxLevels}`;

  // Filter out already played players
  let availablePlayers = PLAYERS.filter(p => !playedPlayerIds.includes(p.name));
  
  // If exhausted all players, reset history
  if (availablePlayers.length === 0) {
    playedPlayerIds = [];
    availablePlayers = PLAYERS;
  }

  // Choose a random player
  const randomIndex = Math.floor(Math.random() * availablePlayers.length);
  currentPlayer = availablePlayers[randomIndex];
  playedPlayerIds.push(currentPlayer.name);

  // Set the clues
  clueClub.textContent = currentPlayer.club;
  clueFlag.textContent = currentPlayer.flag;
  clueCountry.textContent = currentPlayer.country;
  clueLetter.textContent = currentPlayer.firstLetter;

  playerGuessInput.focus();
}

// Reveal country clue
function revealFlag() {
  if (flagCard.classList.contains('revealed')) return;
  playSound('reveal');
  flagCard.classList.add('revealed');
  flagLock.style.display = 'none';
}

// Reveal letter clue
function revealLetter() {
  if (letterCard.classList.contains('revealed')) return;
  playSound('reveal');
  letterCard.classList.add('revealed');
  letterLock.style.display = 'none';
}

// Handle Clue Clicks
flagCard.addEventListener('click', revealFlag);
letterCard.addEventListener('click', revealLetter);

// Autocomplete logic
playerGuessInput.addEventListener('input', () => {
  const query = sanitizeString(playerGuessInput.value);
  if (!query) {
    autocompleteList.classList.remove('active');
    return;
  }

  // Search all player names from PLAYERS to provide suggestions
  const matches = PLAYERS.filter(player => {
    return sanitizeString(player.name).includes(query) || 
           player.aliases.some(alias => sanitizeString(alias).includes(query));
  });

  renderAutocomplete(matches);
});

function renderAutocomplete(matches) {
  autocompleteList.innerHTML = '';
  
  if (matches.length === 0) {
    autocompleteList.classList.remove('active');
    return;
  }

  // Show up to 5 matches
  matches.slice(0, 5).forEach((player, index) => {
    const div = document.createElement('div');
    div.classList.add('autocomplete-item');
    if (index === 0) div.classList.add('selected'); // Highlight first suggestion by default
    
    div.innerHTML = `
      <span class="autocomplete-name">${player.name}</span>
      <span class="autocomplete-details">${player.position}</span>
    `;
    
    div.addEventListener('click', () => {
      playerGuessInput.value = player.name;
      autocompleteList.classList.remove('active');
      checkGuess();
    });
    
    autocompleteList.appendChild(div);
  });
  
  autocompleteList.classList.add('active');
}

// Keyboard Navigation for autocomplete
playerGuessInput.addEventListener('keydown', (e) => {
  const items = autocompleteList.querySelectorAll('.autocomplete-item');
  const activeIndex = Array.from(items).findIndex(item => item.classList.contains('selected'));

  if (e.key === 'ArrowDown') {
    e.preventDefault();
    if (items.length === 0) return;
    if (activeIndex >= 0) items[activeIndex].classList.remove('selected');
    const nextIndex = (activeIndex + 1) % items.length;
    items[nextIndex].classList.add('selected');
    items[nextIndex].scrollIntoView({ block: 'nearest' });
  } else if (e.key === 'ArrowUp') {
    e.preventDefault();
    if (items.length === 0) return;
    if (activeIndex >= 0) items[activeIndex].classList.remove('selected');
    const prevIndex = (activeIndex - 1 + items.length) % items.length;
    items[prevIndex].classList.add('selected');
    items[prevIndex].scrollIntoView({ block: 'nearest' });
  } else if (e.key === 'Enter') {
    if (autocompleteList.classList.contains('active') && activeIndex >= 0) {
      e.preventDefault();
      playerGuessInput.value = items[activeIndex].querySelector('.autocomplete-name').textContent;
      autocompleteList.classList.remove('active');
      checkGuess();
    } else {
      checkGuess();
    }
  } else if (e.key === 'Escape') {
    autocompleteList.classList.remove('active');
  }
});

// Click outside to close autocomplete
document.addEventListener('click', (e) => {
  if (e.target !== playerGuessInput && e.target !== autocompleteList) {
    autocompleteList.classList.remove('active');
  }
});

// Check Guess
function checkGuess() {
  const guess = sanitizeString(playerGuessInput.value);
  if (!guess) return;

  // Verify against correct aliases
  const isCorrect = currentPlayer.aliases.some(alias => sanitizeString(alias) === guess);

  if (isCorrect) {
    // Calculate points based on revealed clues
    let pointsEarned = maxRoundPoints;
    if (flagCard.classList.contains('revealed')) pointsEarned -= penaltyFlag;
    if (letterCard.classList.contains('revealed')) pointsEarned -= penaltyLetter;

    score += pointsEarned;
    streak++;
    
    // High Score tracking
    if (score > highScore) {
      highScore = score;
      localStorage.setItem('football_high_score', highScore);
      highScoreVal.textContent = highScore;
      highScoreVal.classList.add('highlight');
      setTimeout(() => highScoreVal.classList.remove('highlight'), 1000);
    }

    scoreVal.textContent = score;
    scoreVal.classList.add('highlight');
    setTimeout(() => scoreVal.classList.remove('highlight'), 1000);

    streakVal.textContent = streak;
    streakVal.classList.add('highlight');
    setTimeout(() => streakVal.classList.remove('highlight'), 1000);

    // Visuals & Sound
    playSound('success');
    startConfetti();

    // Show Feedback screen
    feedbackScreen.classList.add('active', 'correct');
    feedbackIcon.textContent = '🎉';
    feedbackStatus.textContent = "To'g'ri Topdingiz!";
    feedbackPlayerName.textContent = currentPlayer.name;
    feedbackPlayerMeta.textContent = `${currentPlayer.club} | ${currentPlayer.position} | ${currentPlayer.country}`;
  } else {
    // Wrong Guess
    playSound('fail');
    playerGuessInput.classList.add('shake');
    playerGuessInput.style.borderColor = 'var(--incorrect)';
    setTimeout(() => {
      playerGuessInput.classList.remove('shake');
      playerGuessInput.style.borderColor = 'rgba(255, 255, 255, 0.1)';
    }, 500);
  }
}

// Skip Player
function skipPlayer() {
  playSound('click');
  streak = 0;
  streakVal.textContent = streak;

  feedbackScreen.classList.add('active', 'incorrect');
  feedbackIcon.textContent = '😞';
  feedbackStatus.textContent = "Noto'g'ri!";
  feedbackPlayerName.textContent = currentPlayer.name;
  feedbackPlayerMeta.textContent = `${currentPlayer.club} | ${currentPlayer.position} | ${currentPlayer.country}`;
}

// Next Player transition
function nextPlayer() {
  playSound('click');
  if (currentLevel >= maxLevels) {
    // End Game modal/alert
    alert(`O'yin tugadi! Umumiy ochkolaringiz: ${score}. Rekord: ${highScore}`);
    initGame();
  } else {
    currentLevel++;
    loadNewPlayer();
  }
}

// Sound toggle controls
soundToggleBtn.addEventListener('click', () => {
  soundEnabled = !soundEnabled;
  if (soundEnabled) {
    soundIcon.innerHTML = `
      <polygon points="11 5 6 9 2 9 2 15 6 15 11 19 11 5"></polygon>
      <path d="M19.07 4.93a10 10 0 0 1 0 14.14M15.54 8.46a5 5 0 0 1 0 7.07"></path>
    `;
    playSound('click');
  } else {
    soundIcon.innerHTML = `
      <polygon points="11 5 6 9 2 9 2 15 6 15 11 19 11 5"></polygon>
      <line x1="23" y1="9" x2="17" y2="15"></line>
      <line x1="17" y1="9" x2="23" y2="15"></line>
    `;
  }
});

// Hook event listeners
submitBtn.addEventListener('click', checkGuess);
skipBtn.addEventListener('click', skipPlayer);
nextBtn.addEventListener('click', nextPlayer);

// Initialize game on load
initGame();
