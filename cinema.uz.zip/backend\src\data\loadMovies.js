const fs = require('fs');
const path = require('path');

function cleanTitle(title) {
  if (!title) return 'Kino';
  return title
    .replace(/\s*(?:Premyera\s*\d{4}|Uzbek\s*tilida|O'zbekcha\s*tarjima|kino|Full\s*HD|HD\s*skachat|skachat).*/i, '')
    .trim() || title;
}

function loadExternalMovies() {
  const jsonPath = path.join(__dirname, 'movies.json');
  if (!fs.existsSync(jsonPath)) {
    return [];
  }

  try {
    const raw = JSON.parse(fs.readFileSync(jsonPath, 'utf8'));
    if (!Array.isArray(raw)) return [];

    return raw.map((m, idx) => {
      let poster = m.posterImage || m.poster || m.thumbnail || '';
      if (poster.includes('r2.myplaylist.uz')) {
        poster = poster.replace('r2.myplaylist.uz', 'pub-42c7619e0f49402bb099364c0b589eca.r2.dev');
      }
      if (!poster) {
        poster = `https://picsum.photos/seed/${encodeURIComponent(m.id || idx)}/400/600`;
      }

      let videoUrl = m.cdnUrl || m.streamUrl || m.videoUrl;
      if (!videoUrl || !videoUrl.startsWith('http')) {
        videoUrl = m.cdnUrl || '/videos/sample.mp4';
      }

      const rawGenres = m.genre ? m.genre.split(',').map(g => g.trim()).filter(Boolean) : [];
      const genres = rawGenres.length > 0 ? rawGenres : ['Kino'];

      const rating = m.rating > 0 ? parseFloat(m.rating.toFixed(1)) : parseFloat((7.8 + (idx % 18) * 0.1).toFixed(1));

      return {
        id: m.code || m.id || String(idx + 100),
        title: cleanTitle(m.title),
        original_title: m.title || 'Kino',
        description: m.description && m.description.length > 5 ? m.description : `${cleanTitle(m.title)} filmi - yuqori sifatda onlayn tomosha qiling.`,
        year: m.year && m.year > 1950 ? m.year : 2024,
        country: m._country || "O'zbekiston",
        genres,
        duration: m._duration || 90 + (idx % 8) * 5,
        rating,
        director: m._director || 'Rejissyor',
        actors: m._actors || ['Bosh rol ijrochilari'],
        poster,
        backdrop: poster,
        trailer_url: 'https://www.youtube.com/embed/dQw4w9WgXcQ',
        video_url: videoUrl,
        hls_url: videoUrl,
        audio_tracks: ['uzbek'],
        subtitles: ['uzbek'],
        is_featured: idx < 12,
        views: 1200 + ((idx * 383) % 75000),
        created_at: m.createdTime || new Date().toISOString(),
      };
    });
  } catch (err) {
    console.error('Error loading movies.json:', err);
    return [];
  }
}

module.exports = { loadExternalMovies };
