const jwt = require('jsonwebtoken');
const { db } = require('../data/mockData');

const authenticateToken = (req, res, next) => {
  const authHeader = req.headers['authorization'];
  const token = authHeader && authHeader.split(' ')[1];

  if (!token) {
    return res.status(401).json({ success: false, message: 'Token taqdim etilmagan' });
  }

  try {
    const decoded = jwt.verify(token, process.env.JWT_SECRET);
    const user = db.users.find(u => u.id === decoded.userId);
    if (!user) {
      return res.status(401).json({ success: false, message: 'Foydalanuvchi topilmadi' });
    }
    req.user = { id: user.id, username: user.username, role: user.role };
    next();
  } catch (err) {
    return res.status(403).json({ success: false, message: 'Token yaroqsiz' });
  }
};

const requireAdmin = (req, res, next) => {
  if (req.user?.role !== 'admin') {
    return res.status(403).json({ success: false, message: 'Admin huquqi talab etiladi' });
  }
  next();
};

module.exports = { authenticateToken, requireAdmin };
