const express = require('express');
const router = express.Router();
const { v4: uuidv4 } = require('uuid');
const { db } = require('../data/mockData');
const { authenticateToken, requireAdmin } = require('../middleware/auth');

router.use(authenticateToken, requireAdmin);

// Statistika
router.get('/stats', (req, res) => {
  const activeRooms = db.watch_rooms.filter(r => r.status === 'active' || r.status === 'waiting');
  res.json({
    success: true,
    stats: {
      total_users: db.users.filter(u => u.role !== 'admin').length,
      online_users: db.users.filter(u => {
        const lastSeen = new Date(u.last_seen);
        return (Date.now() - lastSeen.getTime()) < 5 * 60 * 1000;
      }).length,
      total_movies: db.movies.length,
      total_series: db.series.length,
      active_rooms: activeRooms.length,
      total_rooms: db.watch_rooms.length,
      total_messages: db.messages.length,
    },
  });
});

// Foydalanuvchilar boshqaruvi
router.get('/users', (req, res) => {
  const users = db.users.map(u => ({
    id: u.id,
    username: u.username,
    email: u.email,
    role: u.role,
    status: u.status,
    created_at: u.created_at,
    last_seen: u.last_seen,
  }));
  res.json({ success: true, users });
});

router.put('/users/:id/status', (req, res) => {
  const { status } = req.body;
  const user = db.users.find(u => u.id === req.params.id);
  if (!user) return res.status(404).json({ success: false, message: 'Topilmadi' });
  user.status = status;
  res.json({ success: true, message: 'Status yangilandi' });
});

// Kinolar boshqaruvi
router.post('/movies', (req, res) => {
  const movie = { id: uuidv4(), ...req.body, views: 0, created_at: new Date().toISOString() };
  db.movies.push(movie);
  res.status(201).json({ success: true, movie });
});

router.put('/movies/:id', (req, res) => {
  const idx = db.movies.findIndex(m => m.id === req.params.id);
  if (idx === -1) return res.status(404).json({ success: false, message: 'Topilmadi' });
  db.movies[idx] = { ...db.movies[idx], ...req.body };
  res.json({ success: true, movie: db.movies[idx] });
});

router.delete('/movies/:id', (req, res) => {
  const idx = db.movies.findIndex(m => m.id === req.params.id);
  if (idx === -1) return res.status(404).json({ success: false, message: 'Topilmadi' });
  db.movies.splice(idx, 1);
  res.json({ success: true, message: 'O\'chirildi' });
});

// Xonalar boshqaruvi
router.get('/rooms', (req, res) => {
  const rooms = db.watch_rooms.map(r => ({
    ...r,
    participants: db.room_participants.filter(p => p.room_id === r.id && !p.left_at).length,
  }));
  res.json({ success: true, rooms });
});

router.delete('/rooms/:id', (req, res) => {
  const idx = db.watch_rooms.findIndex(r => r.id === req.params.id);
  if (idx === -1) return res.status(404).json({ success: false, message: 'Topilmadi' });
  db.watch_rooms[idx].status = 'ended';
  res.json({ success: true, message: 'Xona tugatildi' });
});

module.exports = router;
