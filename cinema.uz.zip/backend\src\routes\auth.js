const express = require('express');
const router = express.Router();
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const { v4: uuidv4 } = require('uuid');
const { db } = require('../data/mockData');
const { authenticateToken } = require('../middleware/auth');

// Ro'yxatdan o'tish
router.post('/register', async (req, res) => {
  try {
    const { username, email, password } = req.body;

    if (!username || !email || !password) {
      return res.status(400).json({ success: false, message: 'Barcha maydonlarni to\'ldiring' });
    }

    const cleanUsername = String(username).trim();
    const cleanEmail = String(email).trim().toLowerCase();

    if (password.length < 6) {
      return res.status(400).json({ success: false, message: 'Parol kamida 6 ta belgidan iborat bo\'lishi kerak' });
    }

    const existingUser = db.users.find(
      u => (u.email && u.email.toLowerCase() === cleanEmail) ||
           (u.username && u.username.toLowerCase() === cleanUsername.toLowerCase())
    );
    if (existingUser) {
      return res.status(400).json({ success: false, message: 'Bu email yoki username allaqachon ro\'yxatdan o\'tgan' });
    }

    const password_hash = await bcrypt.hash(password, 10);
    const newUser = {
      id: uuidv4(),
      username: cleanUsername,
      email: cleanEmail,
      password_hash,
      avatar: `https://api.dicebear.com/7.x/avataaars/svg?seed=${cleanUsername}`,
      role: 'user',
      status: 'active',
      created_at: new Date().toISOString(),
      last_seen: new Date().toISOString(),
    };

    db.users.push(newUser);

    const token = jwt.sign(
      { userId: newUser.id, username: newUser.username },
      process.env.JWT_SECRET,
      { expiresIn: process.env.JWT_EXPIRES_IN }
    );

    res.status(201).json({
      success: true,
      message: 'Ro\'yxatdan muvaffaqiyatli o\'tdingiz!',
      token,
      user: {
        id: newUser.id,
        username: newUser.username,
        email: newUser.email,
        avatar: newUser.avatar,
        role: newUser.role,
      },
    });
  } catch (error) {
    res.status(500).json({ success: false, message: 'Server xatosi' });
  }
});

// Kirish
router.post('/login', async (req, res) => {
  try {
    const { email, password } = req.body;

    if (!email || !password) {
      return res.status(400).json({ success: false, message: 'Email yoki login va parolni kiriting' });
    }

    const cleanIdentifier = String(email).trim().toLowerCase();
    const user = db.users.find(
      u => (u.email && u.email.toLowerCase() === cleanIdentifier) ||
           (u.username && u.username.toLowerCase() === cleanIdentifier)
    );

    if (!user) {
      return res.status(401).json({ success: false, message: 'Email yoki parol noto\'g\'ri' });
    }

    if (user.status === 'blocked') {
      return res.status(403).json({ success: false, message: 'Hisobingiz bloklangan' });
    }

    const isMatch = await bcrypt.compare(password, user.password_hash);
    if (!isMatch) {
      return res.status(401).json({ success: false, message: 'Email yoki parol noto\'g\'ri' });
    }

    user.last_seen = new Date().toISOString();

    const token = jwt.sign(
      { userId: user.id, username: user.username },
      process.env.JWT_SECRET,
      { expiresIn: process.env.JWT_EXPIRES_IN }
    );

    res.json({
      success: true,
      message: 'Muvaffaqiyatli kirildi',
      token,
      user: {
        id: user.id,
        username: user.username,
        email: user.email,
        avatar: user.avatar,
        role: user.role,
      },
    });
  } catch (error) {
    res.status(500).json({ success: false, message: 'Server xatosi' });
  }
});

// Joriy foydalanuvchi
router.get('/me', authenticateToken, (req, res) => {
  const user = db.users.find(u => u.id === req.user.id);
  if (!user) return res.status(404).json({ success: false, message: 'Topilmadi' });

  res.json({
    success: true,
    user: {
      id: user.id,
      username: user.username,
      email: user.email,
      avatar: user.avatar,
      role: user.role,
      status: user.status,
      created_at: user.created_at,
    },
  });
});

// Parolni tiklash (mock)
router.post('/forgot-password', (req, res) => {
  const { email } = req.body;
  const user = db.users.find(u => u.email === email);
  if (!user) {
    return res.status(404).json({ success: false, message: 'Bu email ro\'yxatda yo\'q' });
  }
  res.json({ success: true, message: 'Parolni tiklash havolasi emailga yuborildi (demo rejim)' });
});

// Google OAuth orqali kirish / ro'yxatdan o'tish
router.post('/google', async (req, res) => {
  try {
    const { email, name, avatar, googleId } = req.body;

    if (!email) {
      return res.status(400).json({ success: false, message: 'Email talab qilinadi' });
    }

    const cleanEmail = String(email).trim().toLowerCase();

    // Mavjud foydalanuvchini tekshirish
    let user = db.users.find(u => u.email && u.email.toLowerCase() === cleanEmail);

    if (!user) {
      // Yangi foydalanuvchi yaratish
      const cleanName = (name || cleanEmail.split('@')[0] || 'User').trim();
      const username = cleanName.replace(/\s+/g, '_').toLowerCase() + '_' + Math.random().toString(36).substring(2, 6);

      user = {
        id: uuidv4(),
        username,
        email: cleanEmail,
        password_hash: await bcrypt.hash(uuidv4(), 10),
        avatar: avatar || `https://api.dicebear.com/7.x/avataaars/svg?seed=${username}`,
        role: 'user',
        status: 'active',
        googleId: googleId || ('G-' + Math.random().toString(36).substring(2, 10)),
        created_at: new Date().toISOString(),
        last_seen: new Date().toISOString(),
      };
      db.users.push(user);
    } else {
      user.last_seen = new Date().toISOString();
      if (avatar && !user.avatar) user.avatar = avatar;
      if (googleId) user.googleId = googleId;
    }

    const token = jwt.sign(
      { userId: user.id, username: user.username },
      process.env.JWT_SECRET,
      { expiresIn: process.env.JWT_EXPIRES_IN }
    );

    res.json({
      success: true,
      message: 'Google orqali muvaffaqiyatli kirildi',
      token,
      user: {
        id: user.id,
        username: user.username,
        email: user.email,
        avatar: user.avatar,
        role: user.role,
      },
    });
  } catch (error) {
    console.error('Google auth error:', error);
    res.status(500).json({ success: false, message: 'Server xatosi' });
  }
});

module.exports = router;
