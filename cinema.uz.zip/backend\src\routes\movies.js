const express = require('express');
const router = express.Router();
const { db } = require('../data/mockData');
const { authenticateToken } = require('../middleware/auth');

// Barcha kinolar
router.get('/', (req, res) => {
  const { genre, year, rating, search, country, page = 1, limit = 12 } = req.query;

  let movies = [...db.movies];

  if (search) {
    const q = search.toLowerCase();
    movies = movies.filter(m =>
      m.title.toLowerCase().includes(q) ||
      m.original_title.toLowerCase().includes(q) ||
      m.director.toLowerCase().includes(q) ||
      m.actors.some(a => a.toLowerCase().includes(q))
    );
  }

  if (genre) {
    movies = movies.filter(m => m.genres.some(g => g.toLowerCase() === genre.toLowerCase()));
  }

  if (year) {
    movies = movies.filter(m => m.year === parseInt(year));
  }

  if (country) {
    movies = movies.filter(m => m.country.toLowerCase().includes(country.toLowerCase()));
  }

  if (rating) {
    movies = movies.filter(m => m.rating >= parseFloat(rating));
  }

  const total = movies.length;
  const skip = (parseInt(page) - 1) * parseInt(limit);
  const paginated = movies.slice(skip, skip + parseInt(limit));

  res.json({
    success: true,
    movies: paginated,
    total,
    page: parseInt(page),
    totalPages: Math.ceil(total / parseInt(limit)),
  });
});

// Tanilgan kinolar
router.get('/featured', (req, res) => {
  const featured = db.movies.filter(m => m.is_featured);
  res.json({ success: true, movies: featured });
});

// Janrlar
router.get('/genres', (req, res) => {
  const movieGenres = db.movies.flatMap(m => m.genres);
  const seriesGenres = db.series.flatMap(s => s.genres);
  const allGenres = [...new Set([...movieGenres, ...seriesGenres])].sort();
  res.json({ success: true, genres: allGenres });
});

// Seriallar
router.get('/series', (req, res) => {
  res.json({ success: true, series: db.series });
});

// Bitta kino
router.get('/:id', (req, res) => {
  const movie = db.movies.find(m => m.id === req.params.id);
  if (!movie) {
    return res.status(404).json({ success: false, message: 'Kino topilmadi' });
  }
  movie.views = (movie.views || 0) + 1;
  res.json({ success: true, movie });
});

// Qidiruv
router.get('/search/query', (req, res) => {
  const { q } = req.query;
  if (!q) return res.json({ success: true, results: [] });

  const query = q.toLowerCase();
  const movies = db.movies.filter(m =>
    m.title.toLowerCase().includes(query) ||
    m.original_title.toLowerCase().includes(query) ||
    m.director.toLowerCase().includes(query) ||
    m.actors.some(a => a.toLowerCase().includes(query)) ||
    m.genres.some(g => g.toLowerCase().includes(query))
  );

  const series = db.series.filter(s =>
    s.title.toLowerCase().includes(query) ||
    s.original_title.toLowerCase().includes(query)
  );

  res.json({ success: true, results: { movies, series } });
});

module.exports = router;
