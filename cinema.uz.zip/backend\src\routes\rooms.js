const express = require('express');
const router = express.Router();
const { v4: uuidv4 } = require('uuid');
const { db } = require('../data/mockData');
const { authenticateToken } = require('../middleware/auth');

// Xona yaratish
router.post('/create', authenticateToken, (req, res) => {
  const { movie_id, room_name, is_private = true, max_participants = 2, voice_enabled = true, chat_enabled = true } = req.body;

  const movie = db.movies.find(m => m.id === movie_id);
  if (!movie) {
    return res.status(404).json({ success: false, message: 'Kino topilmadi' });
  }

  const room_code = Math.random().toString(36).substring(2, 8).toUpperCase();
  const newRoom = {
    id: uuidv4(),
    room_code,
    host_id: req.user.id,
    host_username: req.user.username,
    movie_id,
    movie_title: movie.title,
    movie_poster: movie.poster,
    room_name: room_name || `${req.user.username}ning xonasi`,
    is_private,
    is_locked: false,
    max_participants,
    voice_enabled,
    chat_enabled,
    status: 'waiting',
    created_at: new Date().toISOString(),
    expires_at: new Date(Date.now() + 24 * 60 * 60 * 1000).toISOString(),
  };

  db.watch_rooms.push(newRoom);

  // Playback state yaratish
  db.playback_states[newRoom.id] = {
    room_id: newRoom.id,
    movie_id,
    current_time: 0,
    is_playing: false,
    playback_rate: 1,
    updated_at: new Date().toISOString(),
    updated_by: req.user.id,
  };

  res.status(201).json({
    success: true,
    message: 'Xona yaratildi',
    room: newRoom,
    invite_url: `/watch/${newRoom.room_code}`,
  });
});

// Xona ma'lumoti
router.get('/:room_code', (req, res) => {
  const code = (req.params.room_code || '').trim().toUpperCase();
  const room = db.watch_rooms.find(r => r.room_code.toUpperCase() === code || r.id === req.params.room_code);
  if (!room) {
    return res.status(404).json({ success: false, message: 'Xona topilmadi' });
  }

  const participants = db.room_participants.filter(p => p.room_id === room.id && !p.left_at);
  const movie = db.movies.find(m => m.id === room.movie_id);
  const playback = db.playback_states[room.id] || null;

  res.json({
    success: true,
    room: {
      ...room,
      participants,
      participant_count: participants.length,
      movie,
      playback,
    },
  });
});

// Foydalanuvchining xonalari
router.get('/user/my-rooms', authenticateToken, (req, res) => {
  const rooms = db.watch_rooms.filter(r => r.host_id === req.user.id);
  res.json({ success: true, rooms });
});

// Xonaga qo'shilish
router.post('/:room_code/join', authenticateToken, (req, res) => {
  const code = (req.params.room_code || '').trim().toUpperCase();
  const room = db.watch_rooms.find(r => r.room_code.toUpperCase() === code || r.id === req.params.room_code);
  if (!room) {
    return res.status(404).json({ success: false, message: 'Xona topilmadi' });
  }

  if (room.status === 'ended') {
    return res.status(400).json({ success: false, message: 'Xona tugagan' });
  }

  if (room.is_locked && room.host_id !== req.user.id) {
    return res.status(403).json({ success: false, message: 'Xona qulflangan' });
  }

  const existing = db.room_participants.find(
    p => p.room_id === room.id && p.user_id === req.user.id
  );

  const isHost = room.host_id === req.user.id;
  // Faol ishtirokchilar (chiqmagan va boshqa user bo'lganlar)
  const activeParticipants = db.room_participants.filter(
    p => p.room_id === room.id && !p.left_at && p.user_id !== req.user.id && p.connection_status !== 'offline'
  );

  if (!existing && !isHost && activeParticipants.length >= room.max_participants) {
    return res.status(400).json({ success: false, message: 'Xona to\'la (faqat 2 kishi sig\'adi)' });
  }

  if (existing) {
    existing.left_at = null;
    existing.connection_status = 'online';
  } else {
    const participant = {
      id: uuidv4(),
      room_id: room.id,
      user_id: req.user.id,
      username: req.user.username,
      avatar: db.users.find(u => u.id === req.user.id)?.avatar,
      joined_at: new Date().toISOString(),
      left_at: null,
      is_muted: true,
      is_host: isHost,
      connection_status: 'online',
    };
    db.room_participants.push(participant);
  }

  const movie = db.movies.find(m => m.id === room.movie_id);
  const playback = db.playback_states[room.id] || null;
  const participants = db.room_participants.filter(p => p.room_id === room.id && !p.left_at);

  res.json({
    success: true,
    room: { ...room, movie, playback, participants },
    is_host: isHost,
  });
});

// Xonadan chiqish
router.post('/:room_code/leave', authenticateToken, (req, res) => {
  const code = (req.params.room_code || '').trim().toUpperCase();
  const room = db.watch_rooms.find(r => r.room_code.toUpperCase() === code || r.id === req.params.room_code);
  if (!room) return res.status(404).json({ success: false, message: 'Xona topilmadi' });

  const participant = db.room_participants.find(
    p => p.room_id === room.id && p.user_id === req.user.id && !p.left_at
  );

  if (participant) {
    participant.left_at = new Date().toISOString();
    participant.connection_status = 'offline';
  }

  res.json({ success: true, message: 'Xonadan chiqildi' });
});

// Foydalanuvchi xonalari tarixi
router.get('/user/history', authenticateToken, (req, res) => {
  const joined = db.room_participants
    .filter(p => p.user_id === req.user.id)
    .map(p => {
      const room = db.watch_rooms.find(r => r.id === p.room_id);
      return { ...p, room };
    });

  res.json({ success: true, history: joined });
});

module.exports = router;
