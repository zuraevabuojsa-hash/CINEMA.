const express = require('express');
const router = express.Router();
const { v4: uuidv4 } = require('uuid');
const { db } = require('../data/mockData');
const { authenticateToken } = require('../middleware/auth');

// Agar db.tickets bo'lmasa yaratish
if (!db.tickets) {
  db.tickets = [];
}

// Kinoteatrlar ro'yxati
const CINEMAS = [
  {
    id: 'c1',
    name: 'Magic Cinema',
    city: 'Toshkent',
    address: 'Bobur ko\'chasi, 174 (Magic City)',
    phone: '+998 71 200-00-55',
    image: 'https://picsum.photos/seed/magiccinema/600/400',
    halls: ['Zal 1 (IMAX)', 'Zal 2 (VIP)', 'Zal 3 (Dolby Atmos)'],
    rating: 4.9,
  },
  {
    id: 'c2',
    name: 'Cinema Palace (Alisher Navoiy)',
    city: 'Toshkent',
    address: 'Navoiy ko\'chasi, 15',
    phone: '+998 71 245-88-22',
    image: 'https://picsum.photos/seed/palacecinema/600/400',
    halls: ['Katta zal', 'Zal 2 (3D)', 'Kichik zal'],
    rating: 4.8,
  },
  {
    id: 'c3',
    name: 'Compass Cinema',
    city: 'Toshkent',
    address: 'Farg\'ona yo\'li, 17 (Compass Mall)',
    phone: '+998 71 205-11-22',
    image: 'https://picsum.photos/seed/compasscinema/600/400',
    halls: ['Zal 1 (ScreenX)', 'Zal 2', 'Zal 3 (VIP)'],
    rating: 4.7,
  },
  {
    id: 'c4',
    name: 'Riviera Cinema',
    city: 'Toshkent',
    address: 'Nurafshon ko\'chasi, 5 (Riviera Mall)',
    phone: '+998 71 202-33-44',
    image: 'https://picsum.photos/seed/rivieracinema/600/400',
    halls: ['Zal 1 (VIP Laser)', 'Zal 2', 'Zal 3 (3D)'],
    rating: 4.9,
  },
  {
    id: 'c5',
    name: 'Next Cinema',
    city: 'Toshkent',
    address: 'Bobur ko\'chasi, 6 (Next Mall)',
    phone: '+998 71 230-75-30',
    image: 'https://picsum.photos/seed/nextcinema/600/400',
    halls: ['Zal 1', 'Zal 2', 'Zal 3'],
    rating: 4.6,
  },
];

// Seanslar generatori
function generateSessions(movieId) {
  const dates = [];
  const today = new Date();
  for (let i = 0; i < 4; i++) {
    const d = new Date(today);
    d.setDate(today.getDate() + i);
    dates.push(d.toISOString().split('T')[0]);
  }

  const times = [
    { time: '11:00', format: '2D', price: 45000 },
    { time: '13:30', format: '3D', price: 55000 },
    { time: '16:15', format: 'IMAX 3D', price: 65000 },
    { time: '19:00', format: 'VIP Dolby', price: 85000 },
    { time: '21:45', format: '2D', price: 50000 },
    { time: '23:59', format: 'Tungi seans', price: 45000 },
  ];

  const sessions = [];
  CINEMAS.forEach(cinema => {
    dates.forEach(date => {
      times.forEach((t, tIdx) => {
        const sessionId = `${cinema.id}-${movieId || 'all'}-${date}-${t.time.replace(':', '')}`;
        const hallName = cinema.halls[tIdx % cinema.halls.length];
        sessions.push({
          id: sessionId,
          cinema_id: cinema.id,
          cinema_name: cinema.name,
          cinema_address: cinema.address,
          movie_id: movieId,
          date,
          time: t.time,
          format: t.format,
          price: t.price,
          hall: hallName,
        });
      });
    });
  });

  return sessions;
}

// Kinoteatrlar ro'yxati
router.get('/cinemas', (req, res) => {
  res.json({ success: true, cinemas: CINEMAS });
});

// Seanslar ro'yxati (kino yoki sana bo'yicha)
router.get('/sessions', (req, res) => {
  const { movie_id, cinema_id, date } = req.query;
  let sessions = generateSessions(movie_id);

  if (cinema_id) {
    sessions = sessions.filter(s => s.cinema_id === cinema_id);
  }
  if (date) {
    sessions = sessions.filter(s => s.date === date);
  }

  res.json({ success: true, sessions });
});

// Seans tafsilotlari va o'rindiqlar holati
router.get('/session/:sessionId', (req, res) => {
  const { sessionId } = req.params;

  // Band qilingan o'rindiqlarni olish
  const bookedTickets = db.tickets.filter(t => t.session_id === sessionId);
  const occupiedSeats = bookedTickets.flatMap(t => t.seats);

  // Namuna sifatida ba'zi o'rindiqlarni oldindan band qilib qo'yish
  const defaultOccupied = ['B4', 'B5', 'C5', 'C6', 'D4', 'D5', 'D6', 'E5'];
  const allOccupied = Array.from(new Set([...defaultOccupied, ...occupiedSeats]));

  // 7 qator (A-G), har qatorda 10 ta o'rindiq
  const rows = ['A', 'B', 'C', 'D', 'E', 'F', 'G'];
  const seatsLayout = [];

  rows.forEach((row, rIdx) => {
    const rowSeats = [];
    for (let num = 1; num <= 10; num++) {
      const seatId = `${row}${num}`;
      const isOccupied = allOccupied.includes(seatId);
      const isVip = rIdx === rows.length - 1; // Oxirgi qator VIP
      rowSeats.push({
        id: seatId,
        row,
        number: num,
        type: isVip ? 'vip' : 'standard',
        status: isOccupied ? 'occupied' : 'available',
      });
    }
    seatsLayout.push({ row, seats: rowSeats });
  });

  res.json({
    success: true,
    session_id: sessionId,
    occupied_seats: allOccupied,
    layout: seatsLayout,
  });
});

// Click to'lov yaratish
router.post('/click/prepare', (req, res) => {
  const { amount, phone, movie_title, session_id } = req.body;
  const clickTransId = 'CLK' + Math.floor(10000000 + Math.random() * 90000000);
  const clickPayUrl = `https://my.click.uz/services/pay?service_id=32598&merchant_id=24151&amount=${encodeURIComponent(amount || 0)}&transaction_param=${clickTransId}`;
  
  res.json({
    success: true,
    click_trans_id: clickTransId,
    amount: amount || 0,
    phone: phone || '',
    pay_url: clickPayUrl,
    ussd_code: `*880*32598*${amount}#`,
    message: 'Click to\'lov tayyorlandi',
  });
});

// Click to'lovni tasdiqlash
router.post('/click/verify', (req, res) => {
  const { click_trans_id, code } = req.body;
  // SMS kod yoki avtomatik tasdiqlash
  res.json({
    success: true,
    status: 'paid',
    click_trans_id: click_trans_id || ('CLK' + Math.floor(10000000 + Math.random() * 90000000)),
    receipt_id: 'REC-' + Math.floor(100000 + Math.random() * 900000),
    message: 'To\'lov Click orqali muvaffaqiyatli amalga oshirildi!',
  });
});

// Chipta sotib olish / bron qilish
router.post('/book', (req, res) => {
  const {
    movie_id,
    movie_title,
    movie_poster,
    cinema_id,
    cinema_name,
    cinema_address,
    session_id,
    date,
    time,
    hall,
    format,
    seats,
    total_price,
    payment_method,
    click_trans_id,
    card_pan,
    buyer_name,
    buyer_phone,
    buyer_email,
  } = req.body;

  if (!seats || !seats.length) {
    return res.status(400).json({ success: false, message: 'O\'rindiqlar tanlanmagan' });
  }

  // Token bo'lsa foydalanuvchi ID sini olish
  let userId = null;
  const authHeader = req.headers['authorization'];
  if (authHeader) {
    const token = authHeader.split(' ')[1];
    try {
      const jwt = require('jsonwebtoken');
      const decoded = jwt.verify(token, process.env.JWT_SECRET);
      userId = decoded.userId;
    } catch {}
  }

  const ticketNumber = 'TK' + Math.floor(100000 + Math.random() * 900000);
  const clickId = click_trans_id || ('CLK' + Math.floor(10000000 + Math.random() * 90000000));
  const newTicket = {
    id: uuidv4(),
    ticket_number: ticketNumber,
    user_id: userId,
    movie_id,
    movie_title: movie_title || 'Film',
    movie_poster: movie_poster || '',
    cinema_id,
    cinema_name: cinema_name || 'Cinema',
    cinema_address: cinema_address || '',
    session_id,
    date,
    time,
    hall: hall || 'Zal 1',
    format: format || '2D',
    seats,
    seat_count: seats.length,
    total_price: Number(total_price) || 0,
    payment_method: 'CLICK',
    payment_status: 'paid',
    click_trans_id: clickId,
    card_pan: card_pan || '',
    buyer_name: buyer_name || 'Mehmon',
    buyer_phone: buyer_phone || '',
    buyer_email: buyer_email || '',
    qr_data: `CINEMAUZ:${ticketNumber}:${seats.join(',')}:${date}:${time}:CLICK:${clickId}`,
    created_at: new Date().toISOString(),
  };

  db.tickets.push(newTicket);

  res.status(201).json({
    success: true,
    message: 'Chipta Click orqali muvaffaqiyatli xarid qilindi!',
    ticket: newTicket,
  });
});

// Foydalanuvchining chiptalari
router.get('/my-tickets', (req, res) => {
  let userTickets = [];
  const authHeader = req.headers['authorization'];
  if (authHeader) {
    const token = authHeader.split(' ')[1];
    try {
      const jwt = require('jsonwebtoken');
      const decoded = jwt.verify(token, process.env.JWT_SECRET);
      userTickets = db.tickets.filter(t => t.user_id === decoded.userId);
    } catch {}
  }

  // Agar user_id topilmasa yoki bo'sh bo'lsa barcha so'nggi chiptalarni qaytarish (guest fallback)
  if (!userTickets.length) {
    userTickets = db.tickets.slice(-5).reverse();
  } else {
    userTickets.reverse();
  }

  res.json({ success: true, tickets: userTickets });
});

// Chiptani tekshirish / olish
router.get('/:ticketId', (req, res) => {
  const ticket = db.tickets.find(
    t => t.id === req.params.ticketId || t.ticket_number === req.params.ticketId
  );
  if (!ticket) {
    return res.status(404).json({ success: false, message: 'Chipta topilmadi' });
  }
  res.json({ success: true, ticket });
});

module.exports = router;
