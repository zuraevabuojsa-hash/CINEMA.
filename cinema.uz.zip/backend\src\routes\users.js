const express = require('express');
const router = express.Router();
const { v4: uuidv4 } = require('uuid');
const { db } = require('../data/mockData');
const { authenticateToken } = require('../middleware/auth');

// Profil yangilash
router.put('/profile', authenticateToken, (req, res) => {
  const { username, avatar } = req.body;
  const user = db.users.find(u => u.id === req.user.id);
  if (!user) return res.status(404).json({ success: false, message: 'Topilmadi' });

  if (username) user.username = username;
  if (avatar) user.avatar = avatar;
  user.updated_at = new Date().toISOString();

  res.json({
    success: true,
    user: { id: user.id, username: user.username, email: user.email, avatar: user.avatar },
  });
});

// Sevimlilar
router.get('/favorites', authenticateToken, (req, res) => {
  const favs = db.favorites.filter(f => f.user_id === req.user.id);
  const movies = favs.map(f => db.movies.find(m => m.id === f.movie_id)).filter(Boolean);
  res.json({ success: true, favorites: movies });
});

router.post('/favorites/:movie_id', authenticateToken, (req, res) => {
  const { movie_id } = req.params;
  const exists = db.favorites.find(f => f.user_id === req.user.id && f.movie_id === movie_id);
  if (exists) {
    const idx = db.favorites.indexOf(exists);
    db.favorites.splice(idx, 1);
    return res.json({ success: true, message: 'Sevimlilardan olib tashlandi', is_favorite: false });
  }
  db.favorites.push({ id: uuidv4(), user_id: req.user.id, movie_id, created_at: new Date().toISOString() });
  res.json({ success: true, message: 'Sevimlilarga qo\'shildi', is_favorite: true });
});

// Ko'rish tarixi
router.get('/history', authenticateToken, (req, res) => {
  const history = db.watch_history
    .filter(h => h.user_id === req.user.id)
    .map(h => ({ ...h, movie: db.movies.find(m => m.id === h.movie_id) }))
    .filter(h => h.movie);
  res.json({ success: true, history });
});

router.post('/history/:movie_id', authenticateToken, (req, res) => {
  const { movie_id } = req.params;
  const { current_time } = req.body;

  const existing = db.watch_history.find(h => h.user_id === req.user.id && h.movie_id === movie_id);
  if (existing) {
    existing.current_time = current_time || 0;
    existing.updated_at = new Date().toISOString();
  } else {
    db.watch_history.push({
      id: uuidv4(),
      user_id: req.user.id,
      movie_id,
      current_time: current_time || 0,
      created_at: new Date().toISOString(),
      updated_at: new Date().toISOString(),
    });
  }
  res.json({ success: true });
});

// Do'stlar
router.get('/friends', authenticateToken, (req, res) => {
  const friends = db.friends
    .filter(f => f.user_id === req.user.id || f.friend_id === req.user.id)
    .map(f => {
      const friendId = f.user_id === req.user.id ? f.friend_id : f.user_id;
      const friend = db.users.find(u => u.id === friendId);
      return friend ? { id: friend.id, username: friend.username, avatar: friend.avatar, status: friend.status, last_seen: friend.last_seen } : null;
    })
    .filter(Boolean);
  res.json({ success: true, friends });
});

router.get('/friends/requests', authenticateToken, (req, res) => {
  const requests = db.friend_requests
    .filter(r => r.to_id === req.user.id && r.status === 'pending')
    .map(r => {
      const from = db.users.find(u => u.id === r.from_id);
      return from ? { ...r, from_user: { id: from.id, username: from.username, avatar: from.avatar } } : null;
    })
    .filter(Boolean);
  res.json({ success: true, requests });
});

router.post('/friends/request/:target_id', authenticateToken, (req, res) => {
  const { target_id } = req.params;
  const target = db.users.find(u => u.id === target_id);
  if (!target) return res.status(404).json({ success: false, message: 'Foydalanuvchi topilmadi' });
  if (target_id === req.user.id) return res.status(400).json({ success: false, message: 'O\'zingizga so\'rov yubora olmaysiz' });

  const existing = db.friend_requests.find(
    r => ((r.from_id === req.user.id && r.to_id === target_id) || (r.from_id === target_id && r.to_id === req.user.id)) && r.status === 'pending'
  );
  if (existing) return res.status(400).json({ success: false, message: 'So\'rov allaqachon yuborilgan' });

  const alreadyFriends = db.friends.find(
    f => (f.user_id === req.user.id && f.friend_id === target_id) || (f.user_id === target_id && f.friend_id === req.user.id)
  );
  if (alreadyFriends) return res.status(400).json({ success: false, message: 'Siz allaqachon do\'stsiz' });

  const request = { id: uuidv4(), from_id: req.user.id, to_id: target_id, status: 'pending', created_at: new Date().toISOString() };
  db.friend_requests.push(request);

  // Bildirishnoma
  db.notifications.push({
    id: uuidv4(),
    user_id: target_id,
    type: 'friend_request',
    message: `${req.user.username} sizga do'stlik so'rovi yubordi`,
    data: { from_id: req.user.id, request_id: request.id },
    is_read: false,
    created_at: new Date().toISOString(),
  });

  res.json({ success: true, message: 'Do\'stlik so\'rovi yuborildi' });
});

router.post('/friends/accept/:request_id', authenticateToken, (req, res) => {
  const request = db.friend_requests.find(r => r.id === req.params.request_id && r.to_id === req.user.id);
  if (!request) return res.status(404).json({ success: false, message: 'So\'rov topilmadi' });

  request.status = 'accepted';
  db.friends.push({ id: uuidv4(), user_id: request.from_id, friend_id: request.to_id, created_at: new Date().toISOString() });

  db.notifications.push({
    id: uuidv4(),
    user_id: request.from_id,
    type: 'friend_accepted',
    message: `${req.user.username} do'stlik so'rovingizni qabul qildi`,
    data: {},
    is_read: false,
    created_at: new Date().toISOString(),
  });

  res.json({ success: true, message: 'Do\'stlik qabul qilindi' });
});

router.delete('/friends/:friend_id', authenticateToken, (req, res) => {
  const idx = db.friends.findIndex(
    f => (f.user_id === req.user.id && f.friend_id === req.params.friend_id) ||
         (f.user_id === req.params.friend_id && f.friend_id === req.user.id)
  );
  if (idx === -1) return res.status(404).json({ success: false, message: 'Do\'st topilmadi' });
  db.friends.splice(idx, 1);
  res.json({ success: true, message: 'Do\'stdan o\'chirildi' });
});

// Foydalanuvchi qidirish
router.get('/search', authenticateToken, (req, res) => {
  const { q } = req.query;
  if (!q) return res.json({ success: true, users: [] });
  const users = db.users
    .filter(u => u.id !== req.user.id && (u.username.toLowerCase().includes(q.toLowerCase()) || u.email.toLowerCase().includes(q.toLowerCase())))
    .map(u => ({ id: u.id, username: u.username, avatar: u.avatar, status: u.status }));
  res.json({ success: true, users });
});

// Bildirishnomalar
router.get('/notifications', authenticateToken, (req, res) => {
  const notifs = db.notifications
    .filter(n => n.user_id === req.user.id)
    .sort((a, b) => new Date(b.created_at) - new Date(a.created_at));
  res.json({ success: true, notifications: notifs });
});

router.put('/notifications/:id/read', authenticateToken, (req, res) => {
  const notif = db.notifications.find(n => n.id === req.params.id && n.user_id === req.user.id);
  if (notif) notif.is_read = true;
  res.json({ success: true });
});

router.put('/notifications/read-all', authenticateToken, (req, res) => {
  db.notifications.filter(n => n.user_id === req.user.id).forEach(n => (n.is_read = true));
  res.json({ success: true });
});

module.exports = router;
