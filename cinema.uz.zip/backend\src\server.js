require('dotenv').config();
const express = require('express');
const http = require('http');
const { Server } = require('socket.io');
const cors = require('cors');
const helmet = require('helmet');
const rateLimit = require('express-rate-limit');
const jwt = require('jsonwebtoken');
const path = require('path');

const authRoutes = require('./routes/auth');
const movieRoutes = require('./routes/movies');
const roomRoutes = require('./routes/rooms');
const userRoutes = require('./routes/users');
const adminRoutes = require('./routes/admin');
const ticketRoutes = require('./routes/tickets');
const { db } = require('./data/mockData');

const app = express();
app.set('trust proxy', 1);
const server = http.createServer(app);

// CORS sozlamalari
const rawFrontendUrls = process.env.FRONTEND_URL || 'http://localhost:3000';
const allowedOrigins = rawFrontendUrls.split(',').map(u => u.trim().replace(/\/$/, ''));

const corsOptions = {
  origin: (origin, callback) => {
    if (!origin) return callback(null, true);
    const cleanOrigin = origin.replace(/\/$/, '');
    if (allowedOrigins.includes('*') || allowedOrigins.includes(cleanOrigin)) {
      return callback(null, true);
    }
    return callback(null, true);
  },
  credentials: true,
  methods: ['GET', 'POST', 'PUT', 'DELETE', 'OPTIONS'],
};

const io = new Server(server, {
  cors: corsOptions,
});

// Middleware
app.use(helmet({ contentSecurityPolicy: false }));
app.use(cors(corsOptions));
app.use(express.json());
app.use(express.urlencoded({ extended: true }));

// Statik video fayllar
app.use('/videos', express.static(path.join(__dirname, '../public/videos')));

// Rate limiting
const limiter = rateLimit({
  windowMs: 15 * 60 * 1000,
  max: 10000,
  message: { success: false, message: 'Juda ko\'p so\'rov. Keyinroq urinib ko\'ring.' },
});
app.use('/api', limiter);

// Routes
app.use('/api/auth', authRoutes);
app.use('/api/movies', movieRoutes);
app.use('/api/rooms', roomRoutes);
app.use('/api/users', userRoutes);
app.use('/api/admin', adminRoutes);
app.use('/api/tickets', ticketRoutes);

// Health check
app.get('/api/health', (req, res) => {
  res.json({ success: true, message: 'Server ishlayapti', timestamp: new Date().toISOString() });
});

// 404
app.use('*', (req, res) => {
  res.status(404).json({ success: false, message: 'Endpoint topilmadi' });
});

// =============================================
// WEBSOCKET - Real vaqt aloqasi
// =============================================

// Xona foydalanuvchilarini saqlash: roomId -> Set of socket ids
const roomSockets = new Map();
// SocketId -> user info
const socketUsers = new Map();

// Socket autentifikatsiya
io.use((socket, next) => {
  const token = socket.handshake.auth?.token;
  if (!token) {
    // Mehmon sifatida ulanish (faqat ko'rish uchun)
    socket.user = { id: 'guest_' + socket.id, username: 'Mehmon', role: 'guest' };
    return next();
  }
  try {
    const decoded = jwt.verify(token, process.env.JWT_SECRET);
    const user = db.users.find(u => u.id === decoded.userId);
    if (user) {
      socket.user = { id: user.id, username: user.username, avatar: user.avatar, role: user.role };
      user.last_seen = new Date().toISOString();
    }
    next();
  } catch (err) {
    socket.user = { id: 'guest_' + socket.id, username: 'Mehmon', role: 'guest' };
    next();
  }
});

function findRoom(codeOrId) {
  if (!codeOrId) return null;
  const upper = String(codeOrId).trim().toUpperCase();
  return db.watch_rooms.find(r => (r.room_code && r.room_code.toUpperCase() === upper) || r.id === codeOrId);
}

io.on('connection', (socket) => {
  console.log(`[WS] Ulanish: ${socket.user?.username} (${socket.id})`);
  socketUsers.set(socket.id, socket.user);

  // ===== XONAGA KIRISH =====
  socket.on('join_room', ({ room_code }) => {
    const room = findRoom(room_code);
    if (!room) {
      socket.emit('error', { message: 'Xona topilmadi' });
      return;
    }

    socket.join(room.id);
    socket.join(room.room_code);

    if (!roomSockets.has(room.id)) {
      roomSockets.set(room.id, new Set());
    }
    roomSockets.get(room.id).add(socket.id);

    // Participant yangilash
    const participant = db.room_participants.find(
      p => p.room_id === room.id && p.user_id === socket.user?.id && !p.left_at
    );
    if (participant) {
      participant.connection_status = 'online';
    }

    // Joriy playback holat
    const playback = db.playback_states[room.id] || {
      current_time: 0,
      is_playing: false,
      playback_rate: 1,
    };

    // O'ziga joriy holat
    socket.emit('room_state', {
      room_code,
      playback,
      participants: getParticipants(room.id),
    });

    // Qolganlar uchun xabar
    socket.to(room.id).emit('user_joined', {
      user: socket.user,
      timestamp: new Date().toISOString(),
    });

    console.log(`[ROOM] ${socket.user?.username} -> ${room_code}`);
  });

  // ===== XONADAN CHIQISH =====
  socket.on('leave_room', ({ room_code }) => {
    const room = findRoom(room_code);
    if (!room) return;

    socket.leave(room.id);
    socket.leave(room.room_code);
    if (roomSockets.has(room.id)) {
      roomSockets.get(room.id).delete(socket.id);
    }

    socket.to(room.id).emit('user_left', {
      user: socket.user,
      timestamp: new Date().toISOString(),
    });
  });

  // ===== PLAY =====
  socket.on('play', ({ room_code, current_time }) => {
    const room = findRoom(room_code);
    if (!room) return;

    const playback = db.playback_states[room.id];
    if (!playback) return;

    playback.is_playing = true;
    playback.current_time = current_time !== undefined ? current_time : playback.current_time;
    playback.updated_at = new Date().toISOString();
    playback.updated_by = socket.user?.id;

    if (room.status === 'waiting') room.status = 'active';

    // Barcha xona a'zolariga yuborish
    io.to(room.id).emit('sync_play', {
      current_time: playback.current_time,
      timestamp: Date.now(),
      by: socket.user?.username,
      by_id: socket.user?.id,
    });
  });

  // ===== PAUZA =====
  socket.on('pause', ({ room_code, current_time }) => {
    const room = findRoom(room_code);
    if (!room) return;

    const playback = db.playback_states[room.id];
    if (!playback) return;

    playback.is_playing = false;
    playback.current_time = current_time !== undefined ? current_time : playback.current_time;
    playback.updated_at = new Date().toISOString();
    playback.updated_by = socket.user?.id;

    io.to(room.id).emit('sync_pause', {
      current_time: playback.current_time,
      timestamp: Date.now(),
      by: socket.user?.username,
      by_id: socket.user?.id,
    });
  });

  // ===== VAQTNI O'ZGARTIRISH =====
  socket.on('seek', ({ room_code, current_time }) => {
    const room = findRoom(room_code);
    if (!room) return;

    const playback = db.playback_states[room.id];
    if (!playback) return;

    playback.current_time = current_time;
    playback.updated_at = new Date().toISOString();
    playback.updated_by = socket.user?.id;

    io.to(room.id).emit('sync_seek', {
      current_time,
      timestamp: Date.now(),
      by: socket.user?.username,
      by_id: socket.user?.id,
    });
  });

  // ===== SINXRONLASH SO'ROVI =====
  socket.on('request_sync', ({ room_code }) => {
    const room = findRoom(room_code);
    if (!room) return;

    const playback = db.playback_states[room.id];
    if (!playback) return;

    let currentTime = playback.current_time || 0;
    if (playback.is_playing && playback.updated_at) {
      const elapsed = (Date.now() - new Date(playback.updated_at).getTime()) / 1000;
      if (elapsed > 0 && elapsed < 7200) {
        currentTime += elapsed;
      }
    }

    socket.emit('sync_state', {
      current_time: currentTime,
      is_playing: playback.is_playing,
      playback_rate: playback.playback_rate || 1,
      timestamp: Date.now(),
    });
  });

  // ===== CHAT =====
  socket.on('chat_message', ({ room_code, message }) => {
    const room = findRoom(room_code);
    if (!room || !message?.trim()) return;

    const msg = {
      id: Date.now().toString(),
      room_id: room.id,
      user_id: socket.user?.id,
      username: socket.user?.username,
      avatar: socket.user?.avatar,
      message: message.trim().substring(0, 500),
      created_at: new Date().toISOString(),
    };

    db.messages.push(msg);

    io.to(room.id).emit('new_message', msg);
  });

  // ===== MIKROFON =====
  socket.on('mic_on', ({ room_code }) => {
    const room = findRoom(room_code);
    if (!room) return;

    const p = db.room_participants.find(p => p.room_id === room.id && p.user_id === socket.user?.id && !p.left_at);
    if (p) p.is_muted = false;

    socket.to(room.id).emit('participant_mic_changed', {
      user_id: socket.user?.id,
      is_muted: false,
    });
  });

  socket.on('mic_off', ({ room_code }) => {
    const room = findRoom(room_code);
    if (!room) return;

    const p = db.room_participants.find(p => p.room_id === room.id && p.user_id === socket.user?.id && !p.left_at);
    if (p) p.is_muted = true;

    socket.to(room.id).emit('participant_mic_changed', {
      user_id: socket.user?.id,
      is_muted: true,
    });
  });

  // ===== WEBRTC SIGNAL ALMASHISH =====
  socket.on('webrtc_offer', ({ room_code, offer, target_id }) => {
    const room = findRoom(room_code);
    if (!room) return;
    socket.to(room.id).emit('webrtc_offer', {
      offer,
      from_id: socket.user?.id,
      from_username: socket.user?.username,
      target_id,
    });
  });

  socket.on('webrtc_answer', ({ room_code, answer, target_id }) => {
    const room = findRoom(room_code);
    if (!room) return;
    socket.to(room.id).emit('webrtc_answer', {
      answer,
      from_id: socket.user?.id,
      target_id,
    });
  });

  socket.on('webrtc_ice_candidate', ({ room_code, candidate }) => {
    const room = findRoom(room_code);
    if (!room) return;
    socket.to(room.id).emit('webrtc_ice_candidate', {
      candidate,
      from_id: socket.user?.id,
    });
  });

  // ===== XONANI QULFLASH =====
  socket.on('room_lock', ({ room_code }) => {
    const room = findRoom(room_code);
    if (!room || room.host_id !== socket.user?.id) return;
    room.is_locked = true;
    io.to(room.id).emit('room_locked', { by: socket.user?.username });
  });

  socket.on('room_unlock', ({ room_code }) => {
    const room = findRoom(room_code);
    if (!room || room.host_id !== socket.user?.id) return;
    room.is_locked = false;
    io.to(room.id).emit('room_unlocked', { by: socket.user?.username });
  });

  // ===== XONANI TUGATISH =====
  socket.on('room_end', ({ room_code }) => {
    const room = findRoom(room_code);
    if (!room || room.host_id !== socket.user?.id) return;
    room.status = 'ended';
    io.to(room.id).emit('room_ended', { by: socket.user?.username, timestamp: new Date().toISOString() });
  });

  // ===== ISHTIROKCHINI CHIQARISH =====
  socket.on('kick_participant', ({ room_code, target_user_id }) => {
    const room = findRoom(room_code);
    if (!room || room.host_id !== socket.user?.id) return;

    io.to(room.id).emit('participant_kicked', { user_id: target_user_id, by: socket.user?.username });
  });

  // ===== TYPING INDIKATOR =====
  socket.on('typing', ({ room_code }) => {
    const room = findRoom(room_code);
    if (!room) return;
    socket.to(room.id).emit('user_typing', { username: socket.user?.username });
  });

  // ===== UZILIB QOLISH =====
  socket.on('disconnect', () => {
    console.log(`[WS] Uzilish: ${socket.user?.username} (${socket.id})`);
    socketUsers.delete(socket.id);

    // Barcha xonalarda participant holatini yangilash
    db.room_participants
      .filter(p => p.user_id === socket.user?.id && !p.left_at)
      .forEach(p => {
        p.connection_status = 'offline';
        const room = db.watch_rooms.find(r => r.id === p.room_id);
        if (room) {
          socket.to(room.id).emit('user_disconnected', {
            user_id: socket.user?.id,
            username: socket.user?.username,
          });
        }
      });

    // Xona socketlaridan olib tashlash
    roomSockets.forEach((sockets, roomId) => {
      sockets.delete(socket.id);
    });
  });
});

// Xona ishtirokchilarini olish
function getParticipants(roomId) {
  return db.room_participants
    .filter(p => p.room_id === roomId && !p.left_at)
    .map(p => {
      const user = db.users.find(u => u.id === p.user_id);
      return {
        ...p,
        avatar: user?.avatar,
        username: user?.username || p.username,
      };
    });
}

// Server ishga tushirish
const PORT = process.env.PORT || 5000;
server.listen(PORT, () => {
  console.log(`\n🎬 Cinema Backend Server: http://localhost:${PORT}`);
  console.log(`📡 WebSocket tayyor`);
  console.log(`🌍 Frontend: ${process.env.FRONTEND_URL || 'http://localhost:3000'}\n`);
});

module.exports = { app, io };
