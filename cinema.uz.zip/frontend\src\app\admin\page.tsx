'use client';

import { useEffect, useState } from 'react';
import { useRouter } from 'next/navigation';
import {
  Users, Film, Tv, Play, Activity, BarChart3,
  Shield, Trash2, Ban, CheckCircle, Plus, Eye,
  RefreshCw, Hash, Clock
} from 'lucide-react';
import MainLayout from '@/components/layout/MainLayout';
import { adminAPI } from '@/lib/api';
import { useAuthStore } from '@/store/authStore';
import { formatRelativeTime } from '@/lib/utils';
import toast from 'react-hot-toast';

interface Stats {
  total_users: number;
  online_users: number;
  total_movies: number;
  total_series: number;
  active_rooms: number;
  total_rooms: number;
  total_messages: number;
}

interface AdminUser {
  id: string;
  username: string;
  email: string;
  role: string;
  status: string;
  created_at: string;
  last_seen: string;
}

interface AdminRoom {
  id: string;
  room_code: string;
  room_name: string;
  host_id: string;
  movie_title: string;
  status: string;
  participants: number;
  created_at: string;
}

interface AdminMovie {
  id: string;
  title: string;
  poster: string;
  year: number;
  rating: number;
  views: number;
  genres: string[];
}

export default function AdminPage() {
  const router = useRouter();
  const { user, isAuthenticated } = useAuthStore();
  const [stats, setStats] = useState<Stats | null>(null);
  const [users, setUsers] = useState<AdminUser[]>([]);
  const [rooms, setRooms] = useState<AdminRoom[]>([]);
  const [movies, setMovies] = useState<AdminMovie[]>([]);
  const [loading, setLoading] = useState(true);
  const [tab, setTab] = useState<'stats' | 'users' | 'movies' | 'rooms'>('stats');
  const [refreshing, setRefreshing] = useState(false);

  useEffect(() => {
    if (!isAuthenticated) { router.push('/login'); return; }
    if (user?.role !== 'admin') { router.push('/'); return; }
    loadAll();
  }, [isAuthenticated, user]);

  async function loadAll() {
    setLoading(true);
    try {
      const [statsRes, usersRes, roomsRes] = await Promise.all([
        adminAPI.getStats(),
        adminAPI.getUsers(),
        adminAPI.getRooms(),
      ]);
      setStats(statsRes.data.stats);
      setUsers(usersRes.data.users || []);
      setRooms(roomsRes.data.rooms || []);
    } catch {
      toast.error('Ma\'lumotlarni yuklashda xato');
    }
    setLoading(false);
  }

  async function refresh() {
    setRefreshing(true);
    await loadAll();
    setRefreshing(false);
    toast.success('Yangilandi');
  }

  async function updateUserStatus(id: string, status: string, username: string) {
    try {
      await adminAPI.updateUserStatus(id, status);
      setUsers(prev => prev.map(u => u.id === id ? { ...u, status } : u));
      toast.success(`${username} holati o'zgartirildi`);
    } catch {
      toast.error('Xato yuz berdi');
    }
  }

  async function deleteMovie(id: string, title: string) {
    if (!confirm(`"${title}" kinoni o'chirishni xohlaysizmi?`)) return;
    try {
      await adminAPI.deleteMovie(id);
      setMovies(prev => prev.filter(m => m.id !== id));
      toast.success('Kino o\'chirildi');
    } catch {
      toast.error('Xato yuz berdi');
    }
  }

  async function endRoom(id: string) {
    try {
      await adminAPI.endRoom(id);
      setRooms(prev => prev.map(r => r.id === id ? { ...r, status: 'ended' } : r));
      toast.success('Xona tugatildi');
    } catch {
      toast.error('Xato yuz berdi');
    }
  }

  const statCards = stats ? [
    { label: 'Jami foydalanuvchilar', value: stats.total_users, icon: Users, color: 'text-blue-400', bg: 'bg-blue-400/10' },
    { label: 'Onlayn', value: stats.online_users, icon: Activity, color: 'text-green-400', bg: 'bg-green-400/10' },
    { label: 'Kinolar', value: stats.total_movies, icon: Film, color: 'text-[#e50914]', bg: 'bg-[#e50914]/10' },
    { label: 'Seriallar', value: stats.total_series, icon: Tv, color: 'text-purple-400', bg: 'bg-purple-400/10' },
    { label: 'Faol xonalar', value: stats.active_rooms, icon: Play, color: 'text-yellow-400', bg: 'bg-yellow-400/10' },
    { label: 'Jami xonalar', value: stats.total_rooms, icon: Users, color: 'text-pink-400', bg: 'bg-pink-400/10' },
    { label: 'Xabarlar', value: stats.total_messages, icon: BarChart3, color: 'text-cyan-400', bg: 'bg-cyan-400/10' },
  ] : [];

  return (
    <MainLayout>
      <div className="max-w-7xl mx-auto px-4 sm:px-6 py-8">
        {/* Header */}
        <div className="flex items-center justify-between mb-8">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 bg-[#e50914]/20 rounded-xl flex items-center justify-center">
              <Shield className="w-5 h-5 text-[#e50914]" />
            </div>
            <div>
              <h1 className="text-3xl font-bold text-white">Admin Panel</h1>
              <p className="text-[#888] text-sm">Platforma boshqaruvi</p>
            </div>
          </div>
          <button
            onClick={refresh}
            disabled={refreshing}
            className="flex items-center gap-2 px-4 py-2 bg-[#1a1a1a] border border-[#2a2a2a] hover:border-[#444] text-[#888] hover:text-white rounded-xl text-sm transition-colors"
          >
            <RefreshCw className={`w-4 h-4 ${refreshing ? 'animate-spin' : ''}`} />
            Yangilash
          </button>
        </div>

        {/* Tabs */}
        <div className="flex gap-1 mb-6 bg-[#1a1a1a] rounded-2xl p-1 overflow-x-auto no-scrollbar">
          {[
            { id: 'stats', label: 'Statistika', icon: BarChart3 },
            { id: 'users', label: `Foydalanuvchilar (${users.length})`, icon: Users },
            { id: 'movies', label: `Kinolar (${movies.length || stats?.total_movies || 0})`, icon: Film },
            { id: 'rooms', label: `Xonalar (${rooms.length})`, icon: Play },
          ].map(({ id, label, icon: Icon }) => (
            <button
              key={id}
              onClick={() => setTab(id as typeof tab)}
              className={`flex items-center gap-2 px-4 py-2.5 rounded-xl text-sm font-medium whitespace-nowrap transition-colors ${
                tab === id ? 'bg-[#2a2a2a] text-white' : 'text-[#888] hover:text-white'
              }`}
            >
              <Icon className="w-4 h-4" />
              {label}
            </button>
          ))}
        </div>

        {loading ? (
          <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 gap-4">
            {Array.from({ length: 7 }).map((_, i) => (
              <div key={i} className="h-28 rounded-2xl skeleton" />
            ))}
          </div>
        ) : (
          <>
            {/* Stats Tab */}
            {tab === 'stats' && (
              <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 gap-4">
                {statCards.map(({ label, value, icon: Icon, color, bg }) => (
                  <div key={label} className="p-5 bg-[#1a1a1a] rounded-2xl border border-[#2a2a2a]">
                    <div className={`w-10 h-10 ${bg} rounded-xl flex items-center justify-center mb-3`}>
                      <Icon className={`w-5 h-5 ${color}`} />
                    </div>
                    <p className="text-3xl font-bold text-white">{value.toLocaleString()}</p>
                    <p className="text-sm text-[#888] mt-1">{label}</p>
                  </div>
                ))}
              </div>
            )}

            {/* Users Tab */}
            {tab === 'users' && (
              <div className="bg-[#1a1a1a] rounded-2xl border border-[#2a2a2a] overflow-hidden">
                <div className="overflow-x-auto">
                  <table className="w-full">
                    <thead>
                      <tr className="border-b border-[#2a2a2a]">
                        {['Foydalanuvchi', 'Email', 'Rol', 'Holat', 'Oxirgi faollik', 'Amallar'].map(h => (
                          <th key={h} className="text-left text-xs font-medium text-[#888] px-4 py-3">{h}</th>
                        ))}
                      </tr>
                    </thead>
                    <tbody>
                      {users.map((u) => (
                        <tr key={u.id} className="border-b border-[#1a1a1a] hover:bg-white/2 transition-colors">
                          <td className="px-4 py-3">
                            <div className="flex items-center gap-2">
                              <div className="w-8 h-8 rounded-full bg-gradient-to-br from-[#e50914] to-[#831010] flex items-center justify-center text-white text-xs font-bold">
                                {u.username.charAt(0).toUpperCase()}
                              </div>
                              <span className="text-sm text-white font-medium">{u.username}</span>
                            </div>
                          </td>
                          <td className="px-4 py-3 text-sm text-[#888]">{u.email}</td>
                          <td className="px-4 py-3">
                            <span className={`text-xs px-2.5 py-1 rounded-full font-medium ${
                              u.role === 'admin' ? 'bg-[#e50914]/20 text-[#e50914]' : 'bg-[#2a2a2a] text-[#888]'
                            }`}>{u.role}</span>
                          </td>
                          <td className="px-4 py-3">
                            <span className={`text-xs px-2.5 py-1 rounded-full font-medium ${
                              u.status === 'active' ? 'bg-green-500/20 text-green-400'
                                : u.status === 'blocked' ? 'bg-[#e50914]/20 text-[#e50914]'
                                : 'bg-yellow-400/20 text-yellow-400'
                            }`}>
                              {u.status === 'active' ? 'Faol' : u.status === 'blocked' ? 'Bloklangan' : 'Cheklangan'}
                            </span>
                          </td>
                          <td className="px-4 py-3 text-xs text-[#666]">{formatRelativeTime(u.last_seen)}</td>
                          <td className="px-4 py-3">
                            {u.role !== 'admin' && (
                              <div className="flex items-center gap-1">
                                {u.status === 'active' ? (
                                  <button
                                    onClick={() => updateUserStatus(u.id, 'blocked', u.username)}
                                    className="p-1.5 rounded-lg bg-[#e50914]/10 hover:bg-[#e50914]/20 text-[#e50914] transition-colors"
                                    title="Bloklash"
                                  >
                                    <Ban className="w-3.5 h-3.5" />
                                  </button>
                                ) : (
                                  <button
                                    onClick={() => updateUserStatus(u.id, 'active', u.username)}
                                    className="p-1.5 rounded-lg bg-green-500/10 hover:bg-green-500/20 text-green-400 transition-colors"
                                    title="Faollashtirish"
                                  >
                                    <CheckCircle className="w-3.5 h-3.5" />
                                  </button>
                                )}
                              </div>
                            )}
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </div>
            )}

            {/* Movies Tab */}
            {tab === 'movies' && (
              <div className="space-y-4">
                <div className="flex justify-end">
                  <button className="flex items-center gap-2 px-4 py-2.5 bg-[#e50914] hover:bg-[#c0070f] text-white text-sm font-medium rounded-xl transition-colors">
                    <Plus className="w-4 h-4" />
                    Kino qo'shish
                  </button>
                </div>
                <div className="bg-[#1a1a1a] rounded-2xl border border-[#2a2a2a] overflow-hidden">
                  <div className="overflow-x-auto">
                    <table className="w-full">
                      <thead>
                        <tr className="border-b border-[#2a2a2a]">
                          {['Kino', 'Janr', 'Yil', 'Reyting', 'Ko\'rishlar', 'Amallar'].map(h => (
                            <th key={h} className="text-left text-xs font-medium text-[#888] px-4 py-3">{h}</th>
                          ))}
                        </tr>
                      </thead>
                      <tbody>
                        {(movies.length > 0 ? movies : []).map((movie) => (
                          <tr key={movie.id} className="border-b border-[#1a1a1a] hover:bg-white/2 transition-colors">
                            <td className="px-4 py-3">
                              <div className="flex items-center gap-3">
                                {/* eslint-disable-next-line @next/next/no-img-element */}
                                <img src={movie.poster} alt={movie.title} className="w-10 h-14 object-cover rounded-lg" />
                                <span className="text-sm text-white font-medium">{movie.title}</span>
                              </div>
                            </td>
                            <td className="px-4 py-3 text-xs text-[#888]">{movie.genres?.[0]}</td>
                            <td className="px-4 py-3 text-sm text-[#888]">{movie.year}</td>
                            <td className="px-4 py-3 text-sm text-[#f5c518]">★ {movie.rating}</td>
                            <td className="px-4 py-3 text-sm text-[#888]">{movie.views?.toLocaleString()}</td>
                            <td className="px-4 py-3">
                              <div className="flex items-center gap-1">
                                <button className="p-1.5 rounded-lg bg-blue-500/10 hover:bg-blue-500/20 text-blue-400 transition-colors">
                                  <Eye className="w-3.5 h-3.5" />
                                </button>
                                <button
                                  onClick={() => deleteMovie(movie.id, movie.title)}
                                  className="p-1.5 rounded-lg bg-[#e50914]/10 hover:bg-[#e50914]/20 text-[#e50914] transition-colors"
                                >
                                  <Trash2 className="w-3.5 h-3.5" />
                                </button>
                              </div>
                            </td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                    {movies.length === 0 && (
                      <p className="text-center text-[#888] text-sm py-8">
                        Kinolar ro'yxatini ko'rish uchun &quot;Kinolar&quot; bo'limiga o'ting
                      </p>
                    )}
                  </div>
                </div>
              </div>
            )}

            {/* Rooms Tab */}
            {tab === 'rooms' && (
              <div className="space-y-3">
                {rooms.length === 0 ? (
                  <p className="text-center text-[#888] py-8">Xonalar yo'q</p>
                ) : (
                  rooms.map((room) => (
                    <div key={room.id} className="flex items-center gap-4 p-4 bg-[#1a1a1a] rounded-2xl border border-[#2a2a2a]">
                      <div className="flex-1 min-w-0">
                        <div className="flex items-center gap-2">
                          <h3 className="font-medium text-white truncate">{room.room_name}</h3>
                          <span className={`text-[10px] px-2 py-0.5 rounded-full border font-medium ${
                            room.status === 'active' ? 'text-green-400 bg-green-400/10 border-green-400/30'
                              : room.status === 'waiting' ? 'text-yellow-400 bg-yellow-400/10 border-yellow-400/30'
                              : 'text-[#888] bg-[#2a2a2a] border-[#3a3a3a]'
                          }`}>
                            {room.status === 'active' ? 'Faol' : room.status === 'waiting' ? 'Kutilmoqda' : 'Tugagan'}
                          </span>
                        </div>
                        <p className="text-xs text-[#888] mt-0.5">{room.movie_title}</p>
                        <div className="flex items-center gap-3 mt-1 text-xs text-[#666]">
                          <span className="flex items-center gap-1"><Hash className="w-3 h-3" />{room.room_code}</span>
                          <span className="flex items-center gap-1"><Users className="w-3 h-3" />{room.participants} ishtirokchi</span>
                          <span className="flex items-center gap-1"><Clock className="w-3 h-3" />{formatRelativeTime(room.created_at)}</span>
                        </div>
                      </div>
                      {room.status !== 'ended' && (
                        <button
                          onClick={() => endRoom(room.id)}
                          className="px-3 py-1.5 bg-[#e50914]/20 hover:bg-[#e50914]/30 text-[#e50914] rounded-xl text-xs font-medium transition-colors border border-[#e50914]/30 flex-shrink-0"
                        >
                          Tugatish
                        </button>
                      )}
                    </div>
                  ))
                )}
              </div>
            )}
          </>
        )}
      </div>
    </MainLayout>
  );
}
