import NextAuth from 'next-auth';
import GoogleProvider from 'next-auth/providers/google';
import CredentialsProvider from 'next-auth/providers/credentials';

const handler = NextAuth({
  providers: [
    // Google bilan kirish
    GoogleProvider({
      clientId: process.env.GOOGLE_CLIENT_ID || '',
      clientSecret: process.env.GOOGLE_CLIENT_SECRET || '',
    }),

    // Email/parol bilan kirish (mavjud tizim bilan bog'lash)
    CredentialsProvider({
      name: 'credentials',
      credentials: {
        email: { label: 'Email', type: 'email' },
        password: { label: 'Parol', type: 'password' },
      },
      async authorize(credentials) {
        if (!credentials?.email || !credentials?.password) return null;

        try {
          const res = await fetch(`${process.env.NEXTAUTH_URL?.replace(':3000', ':5000') || 'http://localhost:5000'}/api/auth/login`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
              email: credentials.email,
              password: credentials.password,
            }),
          });

          const data = await res.json();
          if (data.success && data.user) {
            return {
              id: data.user.id,
              name: data.user.username,
              email: data.user.email,
              image: data.user.avatar,
              role: data.user.role,
              backendToken: data.token,
            };
          }
          return null;
        } catch {
          return null;
        }
      },
    }),
  ],

  callbacks: {
    async signIn({ user, account }) {
      // Google orqali kirganда backend da hisob yaratish
      if (account?.provider === 'google') {
        try {
          const res = await fetch(`http://localhost:5000/api/auth/google`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
              email: user.email,
              name: user.name,
              avatar: user.image,
              googleId: account.providerAccountId,
            }),
          });
          const data = await res.json();
          if (data.success) {
            (user as any).backendToken = data.token;
            (user as any).backendId = data.user.id;
            (user as any).role = data.user.role;
          }
        } catch {}
      }
      return true;
    },

    async jwt({ token, user }) {
      if (user) {
        token.backendToken = (user as any).backendToken;
        token.role = (user as any).role;
        token.backendId = (user as any).backendId || user.id;
      }
      return token;
    },

    async session({ session, token }) {
      if (session.user) {
        (session.user as any).backendToken = token.backendToken;
        (session.user as any).role = token.role;
        (session.user as any).backendId = token.backendId;
      }
      return session;
    },
  },

  pages: {
    signIn: '/login',
    error: '/login',
  },

  session: {
    strategy: 'jwt',
    maxAge: 7 * 24 * 60 * 60, // 7 kun
  },

  secret: process.env.NEXTAUTH_SECRET || 'cinema-secret-key-2024',
});

export { handler as GET, handler as POST };
