'use client';

import { useEffect, useState } from 'react';
import { useRouter } from 'next/navigation';
import { Heart, Film } from 'lucide-react';
import MainLayout from '@/components/layout/MainLayout';
import MovieCard from '@/components/ui/MovieCard';
import EmptyState from '@/components/ui/EmptyState';
import { MovieGridSkeleton } from '@/components/ui/LoadingSpinner';
import { usersAPI } from '@/lib/api';
import { useAuthStore } from '@/store/authStore';

interface Movie {
  id: string; title: string; original_title?: string;
  poster: string; year: number; genres: string[];
  duration: number; rating: number; audio_tracks: string[];
}

export default function FavoritesPage() {
  const router = useRouter();
  const { isAuthenticated } = useAuthStore();
  const [favorites, setFavorites] = useState<Movie[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (!isAuthenticated) { router.push('/login'); return; }
    loadFavorites();
  }, [isAuthenticated]);

  async function loadFavorites() {
    try {
      const res = await usersAPI.getFavorites();
      setFavorites(res.data.favorites || []);
    } catch {}
    setLoading(false);
  }

  return (
    <MainLayout>
      <div className="max-w-7xl mx-auto px-4 sm:px-6 py-8">
        <div className="flex items-center gap-3 mb-8">
          <Heart className="w-7 h-7 text-[#e50914] fill-[#e50914]" />
          <h1 className="text-3xl font-bold text-white">Sevimlilar</h1>
          {favorites.length > 0 && (
            <span className="px-3 py-1 bg-[#1a1a1a] border border-[#2a2a2a] text-[#888] text-sm rounded-full">
              {favorites.length} ta
            </span>
          )}
        </div>

        {loading ? (
          <MovieGridSkeleton count={8} />
        ) : favorites.length === 0 ? (
          <EmptyState
            icon={Film}
            title="Sevimlilar ro'yxati bo'sh"
            description="Sevimli kinolaringiz shu yerda chiqadi."
            action={
              <button onClick={() => router.push('/movies')}
                className="px-5 py-2.5 bg-[#e50914] text-white rounded-2xl text-sm font-semibold">
                Kinolarni ko'rish
              </button>
            }
          />
        ) : (
          <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 xl:grid-cols-6 gap-4">
            {favorites.map((movie) => (
              <MovieCard key={movie.id} movie={movie} />
            ))}
          </div>
        )}
      </div>
    </MainLayout>
  );
}
