'use client';

import { useState } from 'react';
import Link from 'next/link';
import { Play, Mail, ArrowLeft, CheckCircle2 } from 'lucide-react';
import { authAPI } from '@/lib/api';
import toast from 'react-hot-toast';

export default function ForgotPasswordPage() {
  const [email, setEmail] = useState('');
  const [loading, setLoading] = useState(false);
  const [sent, setSent] = useState(false);

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    if (!email) return toast.error('Email kiriting');
    setLoading(true);
    try {
      await authAPI.forgotPassword(email);
      setSent(true);
    } catch (err: unknown) {
      const error = err as { response?: { data?: { message?: string } } };
      toast.error(error.response?.data?.message || 'Xato yuz berdi');
    }
    setLoading(false);
  }

  return (
    <div className="min-h-screen bg-[#0d0d0d] flex items-center justify-center p-4">
      <div className="absolute inset-0 overflow-hidden pointer-events-none">
        <div className="absolute top-1/3 left-1/3 w-96 h-96 bg-[#e50914]/5 rounded-full blur-3xl" />
      </div>

      <div className="relative w-full max-w-md">
        <div className="text-center mb-8">
          <Link href="/" className="inline-flex items-center gap-2">
            <div className="w-10 h-10 bg-[#e50914] rounded-xl flex items-center justify-center">
              <Play className="w-5 h-5 text-white fill-white" />
            </div>
            <span className="text-2xl font-bold text-white">Cinema<span className="text-[#e50914]">Uz</span></span>
          </Link>
        </div>

        <div className="bg-[#1a1a1a] rounded-3xl border border-[#2a2a2a] p-8">
          {sent ? (
            <div className="text-center">
              <CheckCircle2 className="w-16 h-16 text-green-400 mx-auto mb-4" />
              <h2 className="text-xl font-bold text-white mb-2">Email yuborildi!</h2>
              <p className="text-[#888] text-sm mb-6">
                <span className="text-white">{email}</span> manziliga parolni tiklash havolasi yuborildi.
                (Demo rejimda bu ishlaydi)
              </p>
              <Link
                href="/login"
                className="inline-flex items-center gap-2 px-6 py-3 bg-[#e50914] hover:bg-[#c0070f] text-white font-semibold rounded-2xl transition-colors"
              >
                Kirish sahifasiga qaytish
              </Link>
            </div>
          ) : (
            <>
              <div className="mb-6">
                <h1 className="text-2xl font-bold text-white mb-1">Parolni tiklash</h1>
                <p className="text-[#888] text-sm">Email manzilingizni kiriting, havola yuboramiz</p>
              </div>

              <form onSubmit={handleSubmit} className="space-y-5">
                <div>
                  <label className="text-sm text-[#888] block mb-2">Elektron pochta</label>
                  <div className="relative">
                    <Mail className="absolute left-4 top-1/2 -translate-y-1/2 w-4 h-4 text-[#888]" />
                    <input
                      type="email"
                      value={email}
                      onChange={(e) => setEmail(e.target.value)}
                      placeholder="email@example.com"
                      className="w-full pl-11 pr-4 py-3 bg-[#0d0d0d] border border-[#2a2a2a] rounded-2xl text-white placeholder-[#555] text-sm focus:outline-none focus:border-[#e50914] transition-colors"
                    />
                  </div>
                </div>

                <button
                  type="submit"
                  disabled={loading}
                  className="w-full py-3.5 bg-[#e50914] hover:bg-[#c0070f] disabled:opacity-50 text-white font-bold rounded-2xl transition-colors flex items-center justify-center gap-2"
                >
                  {loading ? (
                    <div className="w-5 h-5 border-2 border-white/30 border-t-white rounded-full animate-spin" />
                  ) : 'Havola yuborish'}
                </button>
              </form>

              <Link
                href="/login"
                className="flex items-center justify-center gap-2 mt-5 text-sm text-[#888] hover:text-white transition-colors"
              >
                <ArrowLeft className="w-4 h-4" />
                Kirishga qaytish
              </Link>
            </>
          )}
        </div>
      </div>
    </div>
  );
}
