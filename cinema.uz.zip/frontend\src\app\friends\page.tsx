'use client';

import { useEffect, useState } from 'react';
import { useRouter } from 'next/navigation';
import {
  Users, UserPlus, Search, Check, X, Trash2,
  MessageSquare, Wifi, WifiOff, Clock, Play
} from 'lucide-react';
import MainLayout from '@/components/layout/MainLayout';
import EmptyState from '@/components/ui/EmptyState';
import { usersAPI } from '@/lib/api';
import { useAuthStore } from '@/store/authStore';
import { formatRelativeTime } from '@/lib/utils';
import toast from 'react-hot-toast';

interface Friend {
  id: string;
  username: string;
  avatar: string;
  status: string;
  last_seen: string;
}

interface FriendRequest {
  id: string;
  from_id: string;
  from_user: { id: string; username: string; avatar: string };
  created_at: string;
}

interface SearchUser {
  id: string;
  username: string;
  avatar: string;
  status: string;
}

export default function FriendsPage() {
  const router = useRouter();
  const { isAuthenticated, user } = useAuthStore();

  const [friends, setFriends] = useState<Friend[]>([]);
  const [requests, setRequests] = useState<FriendRequest[]>([]);
  const [searchQuery, setSearchQuery] = useState('');
  const [searchResults, setSearchResults] = useState<SearchUser[]>([]);
  const [loading, setLoading] = useState(true);
  const [searching, setSearching] = useState(false);
  const [tab, setTab] = useState<'friends' | 'requests' | 'search'>('friends');
  const [searchTimer, setSearchTimer] = useState<ReturnType<typeof setTimeout> | null>(null);

  useEffect(() => {
    if (!isAuthenticated) { router.push('/login'); return; }
    loadData();
  }, [isAuthenticated]);

  async function loadData() {
    try {
      const [friendsRes, reqRes] = await Promise.all([
        usersAPI.getFriends(),
        usersAPI.getFriendRequests(),
      ]);
      setFriends(friendsRes.data.friends || []);
      setRequests(reqRes.data.requests || []);
    } catch {}
    setLoading(false);
  }

  async function handleSearch(q: string) {
    setSearchQuery(q);
    if (searchTimer) clearTimeout(searchTimer);
    if (!q.trim()) { setSearchResults([]); return; }
    const t = setTimeout(async () => {
      setSearching(true);
      try {
        const res = await usersAPI.searchUsers(q);
        setSearchResults(res.data.users || []);
      } catch {}
      setSearching(false);
    }, 400);
    setSearchTimer(t);
  }

  async function sendRequest(targetId: string, username: string) {
    try {
      await usersAPI.sendFriendRequest(targetId);
      toast.success(`${username}ga so'rov yuborildi`);
      setSearchResults(prev => prev.filter(u => u.id !== targetId));
    } catch (err: unknown) {
      const e = err as { response?: { data?: { message?: string } } };
      toast.error(e.response?.data?.message || 'Xato');
    }
  }

  async function acceptRequest(requestId: string, username: string) {
    try {
      await usersAPI.acceptFriendRequest(requestId);
      toast.success(`${username} do'stlar ro'yxatiga qo'shildi`);
      setRequests(prev => prev.filter(r => r.id !== requestId));
      loadData();
    } catch {
      toast.error('Xato yuz berdi');
    }
  }

  async function removeFriend(friendId: string, username: string) {
    if (!confirm(`${username}ni do'stlardan o'chirishni xohlaysizmi?`)) return;
    try {
      await usersAPI.removeFriend(friendId);
      setFriends(prev => prev.filter(f => f.id !== friendId));
      toast.success("Do'stdan o'chirildi");
    } catch {
      toast.error('Xato yuz berdi');
    }
  }

  const statusIcon = (status: string, lastSeen: string) => {
    const isOnline = status === 'active' && (Date.now() - new Date(lastSeen).getTime()) < 5 * 60 * 1000;
    if (isOnline) return <span className="flex items-center gap-1 text-green-400 text-xs"><Wifi className="w-3 h-3" />Onlayn</span>;
    return <span className="flex items-center gap-1 text-[#888] text-xs"><WifiOff className="w-3 h-3" />{formatRelativeTime(lastSeen)}</span>;
  };

  return (
    <MainLayout>
      <div className="max-w-3xl mx-auto px-4 sm:px-6 py-8">
        <div className="flex items-center justify-between mb-6">
          <h1 className="text-3xl font-bold text-white">Do'stlar</h1>
          {requests.length > 0 && (
            <span className="px-2.5 py-1 bg-[#e50914] text-white text-xs font-bold rounded-full">
              {requests.length} so'rov
            </span>
          )}
        </div>

        {/* Tabs */}
        <div className="flex gap-1 mb-6 bg-[#1a1a1a] rounded-2xl p-1">
          {[
            { id: 'friends', label: `Do'stlar (${friends.length})`, icon: Users },
            { id: 'requests', label: `So'rovlar (${requests.length})`, icon: Clock },
            { id: 'search', label: 'Qidiruv', icon: Search },
          ].map(({ id, label, icon: Icon }) => (
            <button
              key={id}
              onClick={() => setTab(id as typeof tab)}
              className={`flex-1 flex items-center justify-center gap-2 py-2.5 rounded-xl text-sm font-medium transition-colors ${
                tab === id ? 'bg-[#2a2a2a] text-white' : 'text-[#888] hover:text-white'
              }`}
            >
              <Icon className="w-4 h-4" />
              <span className="hidden sm:block">{label}</span>
            </button>
          ))}
        </div>

        {/* Friends List */}
        {tab === 'friends' && (
          <div className="space-y-3">
            {loading ? (
              Array.from({ length: 3 }).map((_, i) => (
                <div key={i} className="h-20 rounded-2xl skeleton" />
              ))
            ) : friends.length === 0 ? (
              <EmptyState
                icon={Users}
                title="Do'stlaringiz yo'q"
                description="Do'stlaringizni qo'shing va do'stlar doirangizni kengaytiring."
                action={
                  <button
                    onClick={() => setTab('search')}
                    className="flex items-center gap-2 px-5 py-2.5 bg-[#e50914] text-white rounded-2xl text-sm font-semibold"
                  >
                    <UserPlus className="w-4 h-4" />
                    Do'st qo'shish
                  </button>
                }
              />
            ) : (
              friends.map((friend) => (
                <div key={friend.id} className="flex items-center gap-4 p-4 bg-[#1a1a1a] rounded-2xl border border-[#2a2a2a] hover:border-[#3a3a3a] transition-colors">
                  <div className="relative">
                    {/* eslint-disable-next-line @next/next/no-img-element */}
                    <img src={friend.avatar} alt={friend.username} className="w-12 h-12 rounded-full object-cover" />
                    <div className={`absolute -bottom-0.5 -right-0.5 w-3.5 h-3.5 rounded-full border-2 border-[#1a1a1a] ${
                      (Date.now() - new Date(friend.last_seen).getTime()) < 5 * 60 * 1000 ? 'bg-green-500' : 'bg-[#444]'
                    }`} />
                  </div>
                  <div className="flex-1 min-w-0">
                    <p className="font-semibold text-white">{friend.username}</p>
                    {statusIcon(friend.status, friend.last_seen)}
                  </div>
                  <div className="flex items-center gap-2">
                    <button
                      onClick={() => removeFriend(friend.id, friend.username)}
                      className="p-2 bg-[#2a2a2a] hover:bg-[#e50914]/20 text-[#888] hover:text-[#e50914] rounded-xl transition-colors"
                      title="Do'stlikdan o'chirish"
                    >
                      <Trash2 className="w-4 h-4" />
                    </button>
                  </div>
                </div>
              ))
            )}
          </div>
        )}

        {/* Friend Requests */}
        {tab === 'requests' && (
          <div className="space-y-3">
            {requests.length === 0 ? (
              <EmptyState
                icon={Clock}
                title="So'rovlar yo'q"
                description="Yangi do'stlik so'rovlari bu yerda ko'rsatiladi."
              />
            ) : (
              requests.map((req) => (
                <div key={req.id} className="flex items-center gap-4 p-4 bg-[#1a1a1a] rounded-2xl border border-[#2a2a2a]">
                  {/* eslint-disable-next-line @next/next/no-img-element */}
                  <img src={req.from_user.avatar} alt={req.from_user.username} className="w-12 h-12 rounded-full" />
                  <div className="flex-1">
                    <p className="font-semibold text-white">{req.from_user.username}</p>
                    <p className="text-xs text-[#888]">{formatRelativeTime(req.created_at)}</p>
                  </div>
                  <div className="flex gap-2">
                    <button
                      onClick={() => acceptRequest(req.id, req.from_user.username)}
                      className="p-2 bg-green-500/20 hover:bg-green-500/30 text-green-400 rounded-xl transition-colors"
                    >
                      <Check className="w-4 h-4" />
                    </button>
                    <button className="p-2 bg-[#e50914]/20 hover:bg-[#e50914]/30 text-[#e50914] rounded-xl transition-colors">
                      <X className="w-4 h-4" />
                    </button>
                  </div>
                </div>
              ))
            )}
          </div>
        )}

        {/* Search */}
        {tab === 'search' && (
          <div className="space-y-4">
            <div className="relative">
              <Search className="absolute left-4 top-1/2 -translate-y-1/2 w-4 h-4 text-[#888]" />
              <input
                type="text"
                value={searchQuery}
                onChange={(e) => handleSearch(e.target.value)}
                placeholder="Foydalanuvchi nomi yoki email..."
                className="w-full pl-11 pr-4 py-3 bg-[#1a1a1a] border border-[#2a2a2a] rounded-2xl text-white placeholder-[#555] text-sm focus:outline-none focus:border-[#e50914] transition-colors"
                autoFocus
              />
            </div>

            {searching && (
              <div className="text-center py-4">
                <div className="w-6 h-6 border-2 border-[#2a2a2a] border-t-[#e50914] rounded-full animate-spin mx-auto" />
              </div>
            )}

            <div className="space-y-3">
              {searchResults.map((u) => {
                const isFriend = friends.some(f => f.id === u.id);
                return (
                  <div key={u.id} className="flex items-center gap-4 p-4 bg-[#1a1a1a] rounded-2xl border border-[#2a2a2a]">
                    {/* eslint-disable-next-line @next/next/no-img-element */}
                    <img src={u.avatar} alt={u.username} className="w-12 h-12 rounded-full" />
                    <div className="flex-1">
                      <p className="font-semibold text-white">{u.username}</p>
                      <p className="text-xs text-[#888]">{isFriend ? 'Do\'stingiz' : 'Foydalanuvchi'}</p>
                    </div>
                    {!isFriend && (
                      <button
                        onClick={() => sendRequest(u.id, u.username)}
                        className="flex items-center gap-2 px-4 py-2 bg-[#e50914]/20 hover:bg-[#e50914]/30 text-[#e50914] rounded-xl text-sm font-medium transition-colors border border-[#e50914]/30"
                      >
                        <UserPlus className="w-4 h-4" />
                        So'rov yuborish
                      </button>
                    )}
                    {isFriend && (
                      <span className="flex items-center gap-1.5 text-green-400 text-xs">
                        <Check className="w-3.5 h-3.5" />Do'st
                      </span>
                    )}
                  </div>
                );
              })}
              {searchQuery && !searching && searchResults.length === 0 && (
                <p className="text-center text-[#888] text-sm py-8">Foydalanuvchi topilmadi</p>
              )}
            </div>
          </div>
        )}
      </div>
    </MainLayout>
  );
}
