'use client';

import { useEffect, useState } from 'react';
import Link from 'next/link';
import { Tag, ChevronRight } from 'lucide-react';
import MainLayout from '@/components/layout/MainLayout';
import { moviesAPI } from '@/lib/api';

const GENRE_ICONS: Record<string, string> = {
  'Drama': '🎭', 'Triller': '😰', 'Fantastika': '🚀', 'Harakat': '💥',
  'Romantik': '💕', 'Komediya': '😄', 'Melodrama': '😢', 'Tarixiy': '🏛️',
  'Sarguzasht': '🗺️', 'Boyqush': '🦇', 'Jinoyat': '🔍', 'Superqahramon': '🦸',
  'Fantasy': '⚔️', 'Animatsiya': '🎨',
};

const GENRE_COLORS = [
  'from-blue-600/40 to-blue-900/40 border-blue-500/30',
  'from-purple-600/40 to-purple-900/40 border-purple-500/30',
  'from-[#e50914]/40 to-[#831010]/40 border-[#e50914]/30',
  'from-green-600/40 to-green-900/40 border-green-500/30',
  'from-yellow-600/40 to-yellow-900/40 border-yellow-500/30',
  'from-pink-600/40 to-pink-900/40 border-pink-500/30',
  'from-cyan-600/40 to-cyan-900/40 border-cyan-500/30',
  'from-orange-600/40 to-orange-900/40 border-orange-500/30',
];

export default function GenresPage() {
  const [genres, setGenres] = useState<string[]>([]);

  useEffect(() => {
    moviesAPI.getGenres().then(res => setGenres(res.data.genres || []));
  }, []);

  return (
    <MainLayout>
      <div className="max-w-5xl mx-auto px-4 sm:px-6 py-8">
        <div className="flex items-center gap-3 mb-8">
          <Tag className="w-7 h-7 text-[#e50914]" />
          <h1 className="text-3xl font-bold text-white">Janrlar</h1>
        </div>

        <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 gap-4">
          {genres.map((genre, i) => (
            <Link
              key={genre}
              href={`/movies?genre=${encodeURIComponent(genre)}`}
              className={`group relative p-6 rounded-2xl border bg-gradient-to-br ${GENRE_COLORS[i % GENRE_COLORS.length]} hover:scale-105 transition-all duration-200`}
            >
              <div className="text-3xl mb-3">{GENRE_ICONS[genre] || '🎬'}</div>
              <h3 className="font-bold text-white text-lg">{genre}</h3>
              <div className="flex items-center gap-1 mt-2 text-white/60 text-sm group-hover:text-white/80 transition-colors">
                Kinolarni ko'rish <ChevronRight className="w-4 h-4" />
              </div>
            </Link>
          ))}
        </div>
      </div>
    </MainLayout>
  );
}
