'use client';

import { useEffect, useState } from 'react';
import { useRouter } from 'next/navigation';
import { History, Play, Clock } from 'lucide-react';
import Link from 'next/link';
import MainLayout from '@/components/layout/MainLayout';
import EmptyState from '@/components/ui/EmptyState';
import { usersAPI } from '@/lib/api';
import { useAuthStore } from '@/store/authStore';
import { formatRelativeTime, formatTime } from '@/lib/utils';

interface HistoryItem {
  id: string;
  movie_id: string;
  current_time: number;
  updated_at: string;
  movie: {
    id: string; title: string; poster: string;
    duration: number; year: number; genres: string[];
  };
}

export default function HistoryPage() {
  const router = useRouter();
  const { isAuthenticated } = useAuthStore();
  const [history, setHistory] = useState<HistoryItem[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (!isAuthenticated) { router.push('/login'); return; }
    loadHistory();
  }, [isAuthenticated]);

  async function loadHistory() {
    try {
      const res = await usersAPI.getHistory();
      setHistory(res.data.history || []);
    } catch {}
    setLoading(false);
  }

  return (
    <MainLayout>
      <div className="max-w-4xl mx-auto px-4 sm:px-6 py-8">
        <div className="flex items-center gap-3 mb-8">
          <History className="w-7 h-7 text-blue-400" />
          <h1 className="text-3xl font-bold text-white">Ko'rish tarixi</h1>
        </div>

        {loading ? (
          <div className="space-y-4">
            {Array.from({ length: 5 }).map((_, i) => (
              <div key={i} className="h-24 rounded-2xl skeleton" />
            ))}
          </div>
        ) : history.length === 0 ? (
          <EmptyState
            icon={Clock}
            title="Ko'rish tarixi bo'sh"
            description="Kino ko'rganingizda bu yerda saqlanadi."
            action={
              <button onClick={() => router.push('/movies')}
                className="px-5 py-2.5 bg-[#e50914] text-white rounded-2xl text-sm font-semibold">
                Kinolarni ko'rish
              </button>
            }
          />
        ) : (
          <div className="space-y-3">
            {history.map((item) => {
              const progress = item.movie.duration > 0
                ? (item.current_time / (item.movie.duration * 60)) * 100
                : 0;
              return (
                <div key={item.id} className="flex items-center gap-4 p-4 bg-[#1a1a1a] rounded-2xl border border-[#2a2a2a] hover:border-[#3a3a3a] transition-colors group">
                  <div className="relative w-20 h-28 flex-shrink-0 rounded-xl overflow-hidden">
                    {/* eslint-disable-next-line @next/next/no-img-element */}
                    <img src={item.movie.poster} alt={item.movie.title} className="w-full h-full object-cover" />
                    {/* Progress bar */}
                    <div className="absolute bottom-0 left-0 right-0 h-1 bg-black/50">
                      <div className="h-full bg-[#e50914]" style={{ width: `${Math.min(100, progress)}%` }} />
                    </div>
                  </div>
                  <div className="flex-1 min-w-0">
                    <h3 className="font-semibold text-white truncate">{item.movie.title}</h3>
                    <p className="text-xs text-[#888] mt-1">{item.movie.year} • {item.movie.genres?.[0]}</p>
                    <div className="flex items-center gap-3 mt-2">
                      <span className="text-xs text-[#888] flex items-center gap-1">
                        <Clock className="w-3 h-3" />
                        {formatTime(item.current_time)} / {item.movie.duration} daq
                      </span>
                      <span className="text-xs text-[#666]">{formatRelativeTime(item.updated_at)}</span>
                    </div>
                    {/* Progress text */}
                    <p className="text-xs text-[#e50914] mt-1">
                      {Math.round(progress)}% ko'rildi
                    </p>
                  </div>
                  <Link
                    href={`/movies/${item.movie.id}`}
                    className="flex items-center gap-2 px-4 py-2 bg-[#e50914] hover:bg-[#c0070f] text-white text-sm font-medium rounded-xl opacity-0 group-hover:opacity-100 transition-all"
                  >
                    <Play className="w-4 h-4 fill-white" />
                    Davom ettirish
                  </Link>
                </div>
              );
            })}
          </div>
        )}
      </div>
    </MainLayout>
  );
}
