import type { Metadata } from 'next';
import { Toaster } from 'react-hot-toast';
import ThemeProvider from '@/components/ThemeProvider';
import SessionWrapper from '@/components/SessionWrapper';
import './globals.css';

export const dynamic = 'force-dynamic';

export const metadata: Metadata = {
  title: 'CinemaUz – Onlayn Kino Platformasi',
  description: "Eng sara kinolar va seriallarni onlayn tomosha qiling hamda kinoteatr chiptalarini xarid qiling.",
  keywords: "kino, online, seriallar, chiptalar, uzbek, cinema",
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="uz" className="dark">
      <body className="antialiased" style={{ backgroundColor: 'var(--bg)', color: 'var(--text)' }}>
        <SessionWrapper>
          <ThemeProvider>
            {children}
          </ThemeProvider>
        </SessionWrapper>
        <Toaster
          position="top-right"
          toastOptions={{
            duration: 3500,
            style: {
              background: 'var(--card)',
              color: 'var(--text)',
              border: '1px solid var(--border)',
              borderRadius: '12px',
              fontSize: '14px',
            },
            success: { iconTheme: { primary: '#22c55e', secondary: 'var(--bg)' } },
            error: { iconTheme: { primary: '#e50914', secondary: 'var(--bg)' } },
          }}
        />
      </body>
    </html>
  );
}
