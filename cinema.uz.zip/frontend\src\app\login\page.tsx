'use client';

import { useState, useEffect } from 'react';
import Link from 'next/link';
import { useRouter } from 'next/navigation';
import { signIn, useSession } from 'next-auth/react';
import { Eye, EyeOff, Play, Mail, Lock } from 'lucide-react';
import { useAuthStore } from '@/store/authStore';
import GoogleAuthModal from '@/components/auth/GoogleAuthModal';
import toast from 'react-hot-toast';

export default function LoginPage() {
  const router = useRouter();
  const { login } = useAuthStore();
  const { data: session } = useSession();

  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [showPass, setShowPass] = useState(false);
  const [loading, setLoading] = useState(false);
  const [googleModalOpen, setGoogleModalOpen] = useState(false);

  // NextAuth session orqali kirgan bo'lsa, backendga ham kirish
  useEffect(() => {
    if (session?.user) {
      const backendToken = (session.user as any).backendToken;
      if (backendToken) {
        localStorage.setItem('cinema_token', backendToken);
        localStorage.setItem('cinema_user', JSON.stringify({
          id: (session.user as any).backendId,
          username: session.user.name,
          email: session.user.email,
          avatar: session.user.image,
          role: (session.user as any).role || 'user',
        }));
        router.push('/');
      }
    }
  }, [session]);

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    if (!email || !password) return toast.error("Barcha maydonlarni to'ldiring");
    setLoading(true);
    try {
      await login(email, password);
      toast.success('Xush kelibsiz!');
      router.push('/');
    } catch (err: unknown) {
      const error = err as { response?: { data?: { message?: string } } };
      toast.error(error.response?.data?.message || 'Kirish xatosi');
    }
    setLoading(false);
  }

  function handleGoogleLogin() {
    setGoogleModalOpen(true);
  }

  function fillDemo(role: 'user' | 'admin') {
    if (role === 'admin') {
      setEmail('admin@cinema.uz');
      setPassword('admin123');
    } else {
      setEmail('sardor@test.uz');
      setPassword('test123');
    }
  }

  return (
    <div className="min-h-screen flex items-center justify-center p-4 transition-colors"
      style={{ backgroundColor: 'var(--bg)' }}>

      {/* Background glow */}
      <div className="absolute inset-0 overflow-hidden pointer-events-none">
        <div className="absolute top-1/4 left-1/4 w-96 h-96 bg-[#e50914]/5 rounded-full blur-3xl" />
        <div className="absolute bottom-1/4 right-1/4 w-96 h-96 bg-blue-500/5 rounded-full blur-3xl" />
      </div>

      <div className="relative w-full max-w-md">
        {/* Logo */}
        <div className="text-center mb-8">
          <Link href="/" className="inline-flex items-center gap-2">
            <div className="w-10 h-10 bg-[#e50914] rounded-xl flex items-center justify-center shadow-lg shadow-[#e50914]/30">
              <Play className="w-5 h-5 text-white fill-white" />
            </div>
            <span className="text-2xl font-bold" style={{ color: 'var(--text)' }}>
              Cinema<span className="text-[#e50914]">Uz</span>
            </span>
          </Link>
          <h1 className="text-2xl font-bold mt-6 mb-1" style={{ color: 'var(--text)' }}>
            Xush kelibsiz!
          </h1>
          <p className="text-sm" style={{ color: 'var(--muted)' }}>Hisobingizga kiring</p>
        </div>

        {/* Demo tugmalari */}
        <div className="flex gap-2 mb-4">
          <button onClick={() => fillDemo('user')}
            className="flex-1 py-2 text-xs rounded-xl border transition-colors"
            style={{ backgroundColor: 'var(--card)', borderColor: 'var(--border)', color: 'var(--muted)' }}>
            Demo: Foydalanuvchi
          </button>
          <button onClick={() => fillDemo('admin')}
            className="flex-1 py-2 text-xs rounded-xl border transition-colors"
            style={{ backgroundColor: 'var(--card)', borderColor: 'var(--border)', color: 'var(--muted)' }}>
            Demo: Admin
          </button>
        </div>

        {/* Form card */}
        <div className="rounded-3xl border p-8" style={{ backgroundColor: 'var(--card)', borderColor: 'var(--border)' }}>

          {/* ===== GOOGLE TUGMASI ===== */}
          <button
            onClick={() => setGoogleModalOpen(true)}
            className="w-full flex items-center justify-center gap-3 py-3.5 rounded-2xl border font-semibold text-sm transition-all hover:shadow-lg hover:scale-[1.01] mb-6 shadow-sm"
            style={{ backgroundColor: 'var(--bg)', borderColor: 'var(--border)', color: 'var(--text)' }}
          >
            <svg className="w-5 h-5" viewBox="0 0 24 24">
              <path fill="#4285F4" d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z"/>
              <path fill="#34A853" d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z"/>
              <path fill="#FBBC05" d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.07H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.93l2.85-2.22.81-.62z"/>
              <path fill="#EA4335" d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.07l3.66 2.84c.87-2.6 3.3-4.53 6.16-4.53z"/>
            </svg>
            Google bilan kirish
          </button>

          {/* Ajratuvchi */}
          <div className="flex items-center gap-3 mb-6">
            <div className="flex-1 h-px" style={{ backgroundColor: 'var(--border)' }} />
            <span className="text-xs" style={{ color: 'var(--muted)' }}>yoki login / email bilan</span>
            <div className="flex-1 h-px" style={{ backgroundColor: 'var(--border)' }} />
          </div>

          {/* Email/Parol form */}
          <form onSubmit={handleSubmit} className="space-y-5">
            {/* Email */}
            <div>
              <label className="text-sm block mb-2" style={{ color: 'var(--muted)' }}>Elektron pochta yoki login</label>
              <div className="relative">
                <Mail className="absolute left-4 top-1/2 -translate-y-1/2 w-4 h-4" style={{ color: 'var(--muted)' }} />
                <input
                  type="text"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  placeholder="email@example.com yoki foydalanuvchi nomi"
                  className="w-full pl-11 pr-4 py-3 rounded-2xl text-sm focus:outline-none focus:border-[#e50914] transition-colors border"
                  style={{
                    backgroundColor: 'var(--input-bg)',
                    borderColor: 'var(--border)',
                    color: 'var(--text)',
                  }}
                />
              </div>
            </div>

            {/* Parol */}
            <div>
              <label className="text-sm block mb-2" style={{ color: 'var(--muted)' }}>Parol</label>
              <div className="relative">
                <Lock className="absolute left-4 top-1/2 -translate-y-1/2 w-4 h-4" style={{ color: 'var(--muted)' }} />
                <input
                  type={showPass ? 'text' : 'password'}
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  placeholder="••••••••"
                  className="w-full pl-11 pr-12 py-3 rounded-2xl text-sm focus:outline-none focus:border-[#e50914] transition-colors border"
                  style={{
                    backgroundColor: 'var(--input-bg)',
                    borderColor: 'var(--border)',
                    color: 'var(--text)',
                  }}
                />
                <button type="button" onClick={() => setShowPass(!showPass)}
                  className="absolute right-4 top-1/2 -translate-y-1/2 transition-colors"
                  style={{ color: 'var(--muted)' }}>
                  {showPass ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                </button>
              </div>
            </div>

            <div className="flex justify-end">
              <Link href="/forgot-password" className="text-xs text-[#e50914] hover:underline">
                Parolni unutdingizmi?
              </Link>
            </div>

            <button
              type="submit"
              disabled={loading}
              className="w-full py-3.5 bg-[#e50914] hover:bg-[#c0070f] disabled:opacity-50 text-white font-bold rounded-2xl transition-colors flex items-center justify-center gap-2"
            >
              {loading ? (
                <div className="w-5 h-5 border-2 border-white/30 border-t-white rounded-full animate-spin" />
              ) : 'Kirish'}
            </button>
          </form>

          <p className="text-center text-sm mt-6" style={{ color: 'var(--muted)' }}>
            Hisob yo&apos;qmi?{' '}
            <Link href="/register" className="text-[#e50914] hover:underline font-medium">
              Ro&apos;yxatdan o&apos;ting
            </Link>
          </p>
        </div>
      </div>

      {/* Google Auth Modal */}
      <GoogleAuthModal
        isOpen={googleModalOpen}
        onClose={() => setGoogleModalOpen(false)}
        title="Google bilan kirish"
      />
    </div>
  );
}
