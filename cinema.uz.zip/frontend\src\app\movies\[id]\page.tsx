'use client';

import { useEffect, useState } from 'react';
import { useParams, useRouter } from 'next/navigation';
import {
  Play, Heart, Star, Clock, Calendar, Globe,
  Volume2, ChevronLeft, Share2, Ticket, Captions
} from 'lucide-react';
import MainLayout from '@/components/layout/MainLayout';
import { PageLoader } from '@/components/ui/LoadingSpinner';
import TicketBookingModal from '@/components/ticket/TicketBookingModal';
import VideoPlayer from '@/components/ui/VideoPlayer';
import { moviesAPI, usersAPI } from '@/lib/api';
import { formatDuration, AUDIO_LANG_LABELS, SUBTITLE_LANG_LABELS } from '@/lib/utils';
import { useAuthStore } from '@/store/authStore';
import toast from 'react-hot-toast';

interface Movie {
  id: string;
  title: string;
  original_title: string;
  description: string;
  poster: string;
  backdrop: string;
  year: number;
  country: string;
  genres: string[];
  duration: number;
  rating: number;
  director: string;
  actors: string[];
  audio_tracks: string[];
  subtitles: string[];
  trailer_url?: string;
  video_url?: string;
  views?: number;
}

export default function MovieDetailPage() {
  const { id } = useParams<{ id: string }>();
  const router = useRouter();
  const { isAuthenticated } = useAuthStore();

  const [movie, setMovie] = useState<Movie | null>(null);
  const [loading, setLoading] = useState(true);
  const [isFav, setIsFav] = useState(false);
  const [showTrailer, setShowTrailer] = useState(false);
  const [ticketModalOpen, setTicketModalOpen] = useState(false);

  useEffect(() => {
    loadMovie();
  }, [id]);

  async function loadMovie() {
    try {
      const res = await moviesAPI.getById(id);
      setMovie(res.data.movie);
    } catch {
      toast.error('Kino topilmadi');
      router.push('/movies');
    }
    setLoading(false);
  }

  async function toggleFavorite() {
    if (!isAuthenticated) {
      toast.error('Kirish kerak');
      router.push('/login');
      return;
    }
    try {
      const res = await usersAPI.toggleFavorite(id);
      setIsFav(res.data.is_favorite);
      toast.success(res.data.is_favorite ? 'Sevimlilarga qo\'shildi' : 'Olib tashlandi');
    } catch {
      toast.error('Xato yuz berdi');
    }
  }

  function handleWatch() {
    if (!movie) return;
    router.push(`/player/${movie.id}`);
  }

  function shareMovie() {
    if (navigator.share) {
      navigator.share({ title: movie?.title, url: window.location.href });
    } else {
      navigator.clipboard.writeText(window.location.href);
      toast.success('Havola nusxalandi');
    }
  }

  if (loading) return <PageLoader />;
  if (!movie) return null;

  return (
    <MainLayout>
      {/* Backdrop */}
      <div className="relative min-h-[70vh]">
        <div className="absolute inset-0 h-[70vh]">
          {/* eslint-disable-next-line @next/next/no-img-element */}
          <img src={movie.backdrop} alt={movie.title} className="w-full h-full object-cover" />
          <div className="absolute inset-0 bg-gradient-to-r from-[#0d0d0d] via-[#0d0d0d]/80 to-transparent" />
          <div className="absolute inset-0 bg-gradient-to-t from-[#0d0d0d] via-transparent to-[#0d0d0d]/30" />
        </div>

        <div className="relative max-w-7xl mx-auto px-4 sm:px-6 pt-8 pb-16">
          {/* Back */}
          <button
            onClick={() => router.back()}
            className="flex items-center gap-2 text-[#888] hover:text-white transition-colors mb-8"
          >
            <ChevronLeft className="w-5 h-5" />
            Orqaga
          </button>

          <div className="flex flex-col md:flex-row gap-8">
            {/* Poster */}
            <div className="flex-shrink-0">
              <div className="w-56 h-80 rounded-2xl overflow-hidden shadow-2xl ring-1 ring-white/10">
                {/* eslint-disable-next-line @next/next/no-img-element */}
                <img src={movie.poster} alt={movie.title} className="w-full h-full object-cover" />
              </div>
            </div>

            {/* Info */}
            <div className="flex-1 min-w-0">
              {/* Genres */}
              <div className="flex flex-wrap gap-2 mb-3">
                {movie.genres.map((g) => (
                  <span key={g} className="text-xs px-3 py-1 rounded-full bg-white/10 text-[#ccc] border border-white/10">
                    {g}
                  </span>
                ))}
              </div>

              <h1 className="text-4xl md:text-5xl font-bold text-white mb-1">{movie.title}</h1>
              {movie.original_title !== movie.title && (
                <p className="text-[#888] text-lg mb-4">{movie.original_title}</p>
              )}

              {/* Meta */}
              <div className="flex flex-wrap items-center gap-4 mb-6 text-sm">
                <div className="flex items-center gap-1.5">
                  <Star className="w-4 h-4 text-[#f5c518] fill-[#f5c518]" />
                  <span className="text-white font-semibold">{movie.rating.toFixed(1)}</span>
                  <span className="text-[#888]">/ 10</span>
                </div>
                <div className="flex items-center gap-1.5 text-[#aaa]">
                  <Calendar className="w-4 h-4" />
                  <span>{movie.year}</span>
                </div>
                <div className="flex items-center gap-1.5 text-[#aaa]">
                  <Clock className="w-4 h-4" />
                  <span>{formatDuration(movie.duration)}</span>
                </div>
                <div className="flex items-center gap-1.5 text-[#aaa]">
                  <Globe className="w-4 h-4" />
                  <span>{movie.country}</span>
                </div>
                {movie.views !== undefined && (
                  <div className="text-[#aaa]">{movie.views.toLocaleString()} ta tomosha</div>
                )}
              </div>

              {/* Description */}
              <p className="text-[#bbb] leading-relaxed mb-6 max-w-2xl">{movie.description}</p>

              {/* Audio & Subtitle */}
              <div className="flex flex-wrap gap-4 mb-6">
                <div>
                  <p className="text-xs text-[#888] mb-1.5 flex items-center gap-1.5">
                    <Volume2 className="w-3.5 h-3.5" /> Audio tillari
                  </p>
                  <div className="flex gap-1.5">
                    {movie.audio_tracks.map((t) => (
                      <span key={t} className={`text-xs px-2.5 py-1 rounded-lg font-medium ${
                        t === 'uzbek' ? 'bg-[#e50914]/20 text-[#e50914] border border-[#e50914]/30'
                          : 'bg-[#1a1a1a] text-[#888] border border-[#2a2a2a]'
                      }`}>
                        {AUDIO_LANG_LABELS[t] || t}
                      </span>
                    ))}
                  </div>
                </div>
                <div>
                  <p className="text-xs text-[#888] mb-1.5 flex items-center gap-1.5">
                    <Captions className="w-3.5 h-3.5" /> Subtitrlar
                  </p>
                  <div className="flex gap-1.5">
                    {movie.subtitles.map((s) => (
                      <span key={s} className="text-xs px-2.5 py-1 rounded-lg bg-[#1a1a1a] text-[#888] border border-[#2a2a2a]">
                        {SUBTITLE_LANG_LABELS[s] || s}
                      </span>
                    ))}
                  </div>
                </div>
              </div>

              {/* Actions */}
              <div className="flex flex-wrap gap-3">
                <button
                  onClick={handleWatch}
                  className="flex items-center gap-2 px-6 py-3 bg-[#e50914] hover:bg-[#c0070f] text-white font-semibold rounded-2xl transition-all hover:scale-105"
                >
                  <Play className="w-5 h-5 fill-white" />
                  Tomosha qilish
                </button>
                <button
                  onClick={() => setTicketModalOpen(true)}
                  className="flex items-center gap-2 px-6 py-3 bg-gradient-to-r from-amber-500 to-orange-600 hover:from-amber-600 hover:to-orange-700 text-white font-semibold rounded-2xl transition-all shadow-lg shadow-orange-500/25 hover:scale-105"
                >
                  <Ticket className="w-5 h-5" />
                  Chipta sotib olish
                </button>
                <button
                  onClick={toggleFavorite}
                  className={`flex items-center gap-2 px-4 py-3 rounded-2xl font-medium transition-all border ${
                    isFav
                      ? 'bg-[#e50914]/20 text-[#e50914] border-[#e50914]/40'
                      : 'bg-white/5 text-[#888] border-[#2a2a2a] hover:text-white hover:border-[#444]'
                  }`}
                >
                  <Heart className={`w-5 h-5 ${isFav ? 'fill-[#e50914]' : ''}`} />
                </button>
                <button
                  onClick={shareMovie}
                  className="flex items-center gap-2 px-4 py-3 rounded-2xl bg-white/5 text-[#888] hover:text-white border border-[#2a2a2a] hover:border-[#444] transition-all"
                >
                  <Share2 className="w-5 h-5" />
                </button>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Details Section */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 pb-16">
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Left: Trailer + Cast */}
          <div className="lg:col-span-2 space-y-8">
            {/* Trailer */}
            {movie.trailer_url && (
              <div>
                <h2 className="text-xl font-bold text-white mb-4">Treyler</h2>
                <div className="relative rounded-2xl overflow-hidden bg-[#1a1a1a] aspect-video">
                  {showTrailer ? (
                    <iframe
                      src={movie.trailer_url.replace('watch?v=', 'embed/')}
                      className="w-full h-full"
                      allowFullScreen
                      title="Treyler"
                    />
                  ) : (
                    <div
                      className="w-full h-full flex items-center justify-center cursor-pointer group"
                      onClick={() => setShowTrailer(true)}
                    >
                      {/* eslint-disable-next-line @next/next/no-img-element */}
                      <img src={movie.backdrop} alt="Treyler" className="w-full h-full object-cover absolute inset-0" />
                      <div className="absolute inset-0 bg-black/50 flex items-center justify-center">
                        <div className="w-16 h-16 bg-[#e50914] rounded-full flex items-center justify-center group-hover:scale-110 transition-transform shadow-2xl">
                          <Play className="w-7 h-7 text-white fill-white ml-1" />
                        </div>
                      </div>
                    </div>
                  )}
                </div>
              </div>
            )}

            {/* Cast */}
            <div>
              <h2 className="text-xl font-bold text-white mb-4">Aktyorlar</h2>
              <div className="flex flex-wrap gap-3">
                {movie.actors.map((actor) => (
                  <div key={actor} className="flex items-center gap-2 px-4 py-2.5 bg-[#1a1a1a] rounded-2xl border border-[#2a2a2a]">
                    <div className="w-8 h-8 rounded-full bg-gradient-to-br from-[#e50914] to-[#831010] flex items-center justify-center text-white text-xs font-bold">
                      {actor.charAt(0)}
                    </div>
                    <span className="text-sm text-[#e5e5e5]">{actor}</span>
                  </div>
                ))}
              </div>
            </div>
          </div>

          {/* Right: Movie Info */}
          <div>
            <div className="bg-[#1a1a1a] rounded-2xl border border-[#2a2a2a] p-6 space-y-4">
              <h2 className="text-lg font-bold text-white">Kino haqida</h2>
              {[
                { label: 'Rejissyor', value: movie.director },
                { label: 'Yil', value: movie.year.toString() },
                { label: 'Mamlakat', value: movie.country },
                { label: 'Davomiylik', value: formatDuration(movie.duration) },
                { label: 'Reyting', value: `${movie.rating}/10` },
                { label: 'Janr', value: movie.genres.join(', ') },
              ].map(({ label, value }) => (
                <div key={label} className="flex justify-between items-start gap-4 py-2 border-b border-[#2a2a2a] last:border-0">
                  <span className="text-sm text-[#888] flex-shrink-0">{label}</span>
                  <span className="text-sm text-white text-right">{value}</span>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>

      {/* Ticket Booking Modal */}
      {ticketModalOpen && movie && (
        <TicketBookingModal
          movie={{
            id: movie.id,
            title: movie.title,
            poster: movie.poster,
            duration: movie.duration,
            year: movie.year,
          }}
          onClose={() => setTicketModalOpen(false)}
        />
      )}
    </MainLayout>
  );
}
