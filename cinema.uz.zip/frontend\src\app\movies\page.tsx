'use client';

import { Suspense } from 'react';
import { useEffect, useState, useCallback } from 'react';
import { useSearchParams, useRouter } from 'next/navigation';
import { Search, SlidersHorizontal, X, ChevronLeft, ChevronRight } from 'lucide-react';
import MainLayout from '@/components/layout/MainLayout';
import MovieCard from '@/components/ui/MovieCard';
import { MovieGridSkeleton } from '@/components/ui/LoadingSpinner';
import { moviesAPI } from '@/lib/api';

const GENRES = ['Drama', 'Triller', 'Fantastika', 'Harakat', 'Romantik', 'Komediya', 'Melodrama', 'Tarixiy', 'Sarguzasht', 'Animatsiya'];
const YEARS = ['2024', '2023', '2022', '2021', '2020', '2019', '2018', '2015', '2010', '2000'];
const COUNTRIES = ["O'zbekiston", 'AQSh', 'Rossiya', 'Buyuk Britaniya', 'Fransiya', 'Janubiy Koreya'];

interface Movie {
  id: string;
  title: string;
  original_title?: string;
  poster: string;
  year: number;
  genres: string[];
  duration: number;
  rating: number;
  audio_tracks: string[];
}

function MoviesContent() {
  const searchParams = useSearchParams();

  const [movies, setMovies] = useState<Movie[]>([]);
  const [loading, setLoading] = useState(true);
  const [total, setTotal] = useState(0);
  const [totalPages, setTotalPages] = useState(1);
  const [filtersOpen, setFiltersOpen] = useState(false);

  const [search, setSearch] = useState(searchParams.get('search') || '');
  const [genre, setGenre] = useState(searchParams.get('genre') || '');
  const [year, setYear] = useState(searchParams.get('year') || '');
  const [country, setCountry] = useState(searchParams.get('country') || '');
  const [rating, setRating] = useState(searchParams.get('rating') || '');
  const [page, setPage] = useState(Number(searchParams.get('page')) || 1);

  const loadMovies = useCallback(async () => {
    setLoading(true);
    try {
      const params: Record<string, string | number> = { page, limit: 18 };
      if (search) params.search = search;
      if (genre) params.genre = genre;
      if (year) params.year = year;
      if (country) params.country = country;
      if (rating) params.rating = rating;

      const res = await moviesAPI.getAll(params);
      setMovies(res.data.movies || []);
      setTotal(res.data.total || 0);
      setTotalPages(res.data.totalPages || 1);
    } catch {
      setMovies([]);
    }
    setLoading(false);
  }, [search, genre, year, country, rating, page]);

  useEffect(() => {
    loadMovies();
  }, [loadMovies]);

  function clearFilters() {
    setSearch(''); setGenre(''); setYear('');
    setCountry(''); setRating(''); setPage(1);
  }

  const hasFilters = search || genre || year || country || rating;

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 py-8">
      {/* Header */}
      <div className="flex items-center justify-between mb-6">
        <div>
          <h1 className="text-3xl font-bold text-white">Kinolar</h1>
          {total > 0 && <p className="text-[#888] text-sm mt-1">{total} ta kino topildi</p>}
        </div>
        <button
          onClick={() => setFiltersOpen(!filtersOpen)}
          className={`flex items-center gap-2 px-4 py-2 rounded-xl border text-sm font-medium transition-colors ${
            filtersOpen || hasFilters
              ? 'border-[#e50914] text-[#e50914] bg-[#e50914]/10'
              : 'border-[#2a2a2a] text-[#888] hover:text-white hover:border-[#444]'
          }`}
        >
          <SlidersHorizontal className="w-4 h-4" />
          Filtr
          {hasFilters && (
            <span className="w-5 h-5 bg-[#e50914] text-white text-xs rounded-full flex items-center justify-center">
              {[search, genre, year, country, rating].filter(Boolean).length}
            </span>
          )}
        </button>
      </div>

      {/* Search */}
      <div className="relative mb-4">
        <Search className="absolute left-4 top-1/2 -translate-y-1/2 w-4 h-4 text-[#888]" />
        <input
          type="text"
          value={search}
          onChange={(e) => { setSearch(e.target.value); setPage(1); }}
          placeholder="Kino nomi, aktyor, rejissyor..."
          className="w-full pl-11 pr-4 py-3 bg-[#1a1a1a] border border-[#2a2a2a] rounded-2xl text-white placeholder-[#888] text-sm focus:outline-none focus:border-[#e50914] transition-colors"
        />
        {search && (
          <button onClick={() => setSearch('')} className="absolute right-4 top-1/2 -translate-y-1/2 text-[#888] hover:text-white">
            <X className="w-4 h-4" />
          </button>
        )}
      </div>

      {/* Filters Panel */}
      {filtersOpen && (
        <div className="bg-[#1a1a1a] border border-[#2a2a2a] rounded-2xl p-5 mb-6 animate-slide-down">
          <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4 gap-4">
            <div>
              <label className="text-xs font-medium text-[#888] mb-2 block">Janr</label>
              <div className="flex flex-wrap gap-1.5">
                {GENRES.map((g) => (
                  <button key={g} onClick={() => { setGenre(genre === g ? '' : g); setPage(1); }}
                    className={`text-xs px-2.5 py-1 rounded-lg transition-colors ${genre === g ? 'bg-[#e50914] text-white' : 'bg-[#2a2a2a] text-[#888] hover:text-white'}`}>
                    {g}
                  </button>
                ))}
              </div>
            </div>
            <div>
              <label className="text-xs font-medium text-[#888] mb-2 block">Yil</label>
              <div className="flex flex-wrap gap-1.5">
                {YEARS.map((y) => (
                  <button key={y} onClick={() => { setYear(year === y ? '' : y); setPage(1); }}
                    className={`text-xs px-2.5 py-1 rounded-lg transition-colors ${year === y ? 'bg-[#e50914] text-white' : 'bg-[#2a2a2a] text-[#888] hover:text-white'}`}>
                    {y}
                  </button>
                ))}
              </div>
            </div>
            <div>
              <label className="text-xs font-medium text-[#888] mb-2 block">Mamlakat</label>
              <div className="flex flex-wrap gap-1.5">
                {COUNTRIES.map((c) => (
                  <button key={c} onClick={() => { setCountry(country === c ? '' : c); setPage(1); }}
                    className={`text-xs px-2.5 py-1 rounded-lg transition-colors ${country === c ? 'bg-[#e50914] text-white' : 'bg-[#2a2a2a] text-[#888] hover:text-white'}`}>
                    {c}
                  </button>
                ))}
              </div>
            </div>
            <div>
              <label className="text-xs font-medium text-[#888] mb-2 block">Minimum reyting</label>
              <div className="flex flex-wrap gap-1.5">
                {['6', '7', '7.5', '8', '8.5', '9'].map((r) => (
                  <button key={r} onClick={() => { setRating(rating === r ? '' : r); setPage(1); }}
                    className={`text-xs px-2.5 py-1 rounded-lg transition-colors ${rating === r ? 'bg-[#e50914] text-white' : 'bg-[#2a2a2a] text-[#888] hover:text-white'}`}>
                    {r}+
                  </button>
                ))}
              </div>
            </div>
          </div>
          {hasFilters && (
            <button onClick={clearFilters} className="mt-4 flex items-center gap-2 text-sm text-[#e50914] hover:underline">
              <X className="w-3.5 h-3.5" />Filtrlarni tozalash
            </button>
          )}
        </div>
      )}

      {/* Movies Grid */}
      {loading ? (
        <MovieGridSkeleton count={18} />
      ) : movies.length === 0 ? (
        <div className="text-center py-20">
          <p className="text-[#888] text-lg">Kino topilmadi</p>
          {hasFilters && (
            <button onClick={clearFilters} className="mt-3 text-[#e50914] hover:underline text-sm">
              Filtrlarni tozalash
            </button>
          )}
        </div>
      ) : (
        <>
          <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 xl:grid-cols-6 gap-4">
            {movies.map((movie) => (
              <MovieCard key={movie.id} movie={movie} />
            ))}
          </div>
          {totalPages > 1 && (
            <div className="flex items-center justify-center gap-2 mt-10">
              <button onClick={() => setPage(p => Math.max(1, p - 1))} disabled={page === 1}
                className="p-2 rounded-xl bg-[#1a1a1a] border border-[#2a2a2a] text-[#888] hover:text-white disabled:opacity-30 disabled:cursor-not-allowed transition-colors">
                <ChevronLeft className="w-5 h-5" />
              </button>
              {Array.from({ length: Math.min(5, totalPages) }, (_, i) => {
                const pg = Math.max(1, Math.min(page - 2, totalPages - 4)) + i;
                return (
                  <button key={pg} onClick={() => setPage(pg)}
                    className={`w-10 h-10 rounded-xl text-sm font-medium transition-colors ${pg === page ? 'bg-[#e50914] text-white' : 'bg-[#1a1a1a] border border-[#2a2a2a] text-[#888] hover:text-white'}`}>
                    {pg}
                  </button>
                );
              })}
              <button onClick={() => setPage(p => Math.min(totalPages, p + 1))} disabled={page === totalPages}
                className="p-2 rounded-xl bg-[#1a1a1a] border border-[#2a2a2a] text-[#888] hover:text-white disabled:opacity-30 disabled:cursor-not-allowed transition-colors">
                <ChevronRight className="w-5 h-5" />
              </button>
            </div>
          )}
        </>
      )}
    </div>
  );
}

export default function MoviesPage() {
  return (
    <MainLayout>
      <Suspense fallback={<div className="max-w-7xl mx-auto px-4 py-8"><MovieGridSkeleton count={18} /></div>}>
        <MoviesContent />
      </Suspense>
    </MainLayout>
  );
}
