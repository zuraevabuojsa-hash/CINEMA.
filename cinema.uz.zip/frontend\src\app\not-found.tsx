import Link from 'next/link';
import { Home, Search, Film } from 'lucide-react';

export default function NotFound() {
  return (
    <div className="min-h-screen bg-[#0d0d0d] flex items-center justify-center p-4">
      <div className="text-center max-w-md">
        <div className="text-8xl font-black text-[#e50914] mb-4">404</div>
        <h1 className="text-2xl font-bold text-white mb-3">Sahifa topilmadi</h1>
        <p className="text-[#888] mb-8">
          Siz qidirgan sahifa mavjud emas yoki o&apos;chirib tashlangan.
        </p>
        <div className="flex flex-col sm:flex-row gap-3 justify-center">
          <Link
            href="/"
            className="flex items-center justify-center gap-2 px-6 py-3 bg-[#e50914] hover:bg-[#c0070f] text-white font-semibold rounded-2xl transition-colors"
          >
            <Home className="w-4 h-4" />
            Bosh sahifa
          </Link>
          <Link
            href="/movies"
            className="flex items-center justify-center gap-2 px-6 py-3 bg-[#1a1a1a] hover:bg-[#2a2a2a] text-white font-semibold rounded-2xl transition-colors border border-[#2a2a2a]"
          >
            <Film className="w-4 h-4" />
            Kinolar
          </Link>
        </div>
      </div>
    </div>
  );
}
