'use client';

import { useEffect, useState, useCallback } from 'react';
import Link from 'next/link';
import {
  Play, Star, ChevronRight, ChevronLeft, Clock,
  Zap, Shield, Mic, Film
} from 'lucide-react';
import MainLayout from '@/components/layout/MainLayout';
import MovieCard from '@/components/ui/MovieCard';
import { MovieGridSkeleton } from '@/components/ui/LoadingSpinner';
import { moviesAPI } from '@/lib/api';
import { formatDuration } from '@/lib/utils';

interface Movie {
  id: string;
  title: string;
  original_title?: string;
  description: string;
  poster: string;
  backdrop: string;
  year: number;
  genres: string[];
  duration: number;
  rating: number;
  audio_tracks: string[];
  is_featured?: boolean;
  views?: number;
}

export default function HomePage() {
  const [featured, setFeatured] = useState<Movie[]>([]);
  const [movies, setMovies] = useState<Movie[]>([]);
  const [loading, setLoading] = useState(true);
  const [heroIndex, setHeroIndex] = useState(0);

  useEffect(() => {
    loadData();
  }, []);

  useEffect(() => {
    if (featured.length < 2) return;
    const timer = setInterval(() => {
      setHeroIndex((i) => (i + 1) % featured.length);
    }, 6000);
    return () => clearInterval(timer);
  }, [featured]);

  async function loadData() {
    try {
      const [featRes, allRes] = await Promise.all([
        moviesAPI.getFeatured(),
        moviesAPI.getAll({ limit: 20 }),
      ]);
      setFeatured(featRes.data.movies || []);
      setMovies(allRes.data.movies || []);
    } catch {}
    setLoading(false);
  }

  const hero = featured[heroIndex];

  const sections = [
    { title: 'Mashhur kinolar', movies: movies.slice(0, 8) },
    { title: 'Yangi qo\'shilganlar', movies: [...movies].reverse().slice(0, 8) },
    { title: "O'zbek filmlari", movies: movies.filter(m => m.audio_tracks?.includes('uzbek')).slice(0, 8) },
    { title: 'Top kinolar', movies: [...movies].sort((a, b) => b.rating - a.rating).slice(0, 8) },
  ];

  return (
    <MainLayout>
      {/* Hero Section */}
      {hero && (
        <section className="relative min-h-[90vh] flex items-center overflow-hidden">
          {/* Backdrop */}
          <div className="absolute inset-0">
            {/* eslint-disable-next-line @next/next/no-img-element */}
            <img
              src={hero.backdrop}
              alt={hero.title}
              className="w-full h-full object-cover transition-opacity duration-1000"
            />
            <div className="absolute inset-0 hero-overlay" />
            <div className="absolute inset-0 bg-gradient-to-t from-[#0d0d0d] via-transparent to-transparent" />
          </div>

          {/* Content */}
          <div className="relative max-w-7xl mx-auto px-4 sm:px-6 py-20">
            <div className="max-w-2xl">
              {/* Badges */}
              <div className="flex flex-wrap items-center gap-2 mb-4">
                {hero.genres?.slice(0, 3).map((g) => (
                  <span key={g} className="text-xs font-medium px-3 py-1 rounded-full bg-white/10 text-white border border-white/10">
                    {g}
                  </span>
                ))}
                <span className="flex items-center gap-1 text-xs font-medium px-3 py-1 rounded-full bg-[#f5c518]/20 text-[#f5c518]">
                  <Star className="w-3 h-3 fill-[#f5c518]" />
                  {hero.rating}
                </span>
              </div>

              <h1 className="text-4xl sm:text-5xl md:text-6xl font-bold text-white mb-4 leading-tight">
                {hero.title}
              </h1>

              <div className="flex items-center gap-4 mb-4 text-sm text-[#aaa]">
                <span>{hero.year}</span>
                <span>•</span>
                <span className="flex items-center gap-1">
                  <Clock className="w-3.5 h-3.5" />
                  {formatDuration(hero.duration)}
                </span>
              </div>

              <p className="text-[#bbb] text-base leading-relaxed mb-8 line-clamp-3 max-w-lg">
                {hero.description}
              </p>

              <div className="flex flex-wrap gap-3">
                <Link
                  href={`/movies/${hero.id}`}
                  className="flex items-center gap-2 px-6 py-3 bg-[#e50914] hover:bg-[#c0070f] text-white font-semibold rounded-2xl transition-all hover:scale-105"
                >
                  <Play className="w-5 h-5 fill-white" />
                  Tomosha qilish
                </Link>
                <Link
                  href="/tickets"
                  className="flex items-center gap-2 px-6 py-3 bg-gradient-to-r from-amber-500 to-orange-600 hover:from-amber-600 hover:to-orange-700 text-white font-semibold rounded-2xl transition-all shadow-lg shadow-orange-500/25 hover:scale-105"
                >
                  Chipta sotib olish
                </Link>
              </div>
            </div>
          </div>

          {/* Hero pagination */}
          {featured.length > 1 && (
            <div className="absolute bottom-8 left-1/2 -translate-x-1/2 flex items-center gap-6">
              <button
                onClick={() => setHeroIndex((i) => (i - 1 + featured.length) % featured.length)}
                className="p-2 rounded-full bg-white/10 hover:bg-white/20 text-white transition-colors"
              >
                <ChevronLeft className="w-5 h-5" />
              </button>
              <div className="flex gap-2">
                {featured.map((_, i) => (
                  <button
                    key={i}
                    onClick={() => setHeroIndex(i)}
                    className={`rounded-full transition-all ${i === heroIndex ? 'w-8 h-2 bg-[#e50914]' : 'w-2 h-2 bg-white/30'}`}
                  />
                ))}
              </div>
              <button
                onClick={() => setHeroIndex((i) => (i + 1) % featured.length)}
                className="p-2 rounded-full bg-white/10 hover:bg-white/20 text-white transition-colors"
              >
                <ChevronRight className="w-5 h-5" />
              </button>
            </div>
          )}
        </section>
      )}

      {/* Features Banner */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 py-10">
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
          {[
            { icon: Film, title: 'Keng katalog', desc: 'Eng sara 300+ film', color: 'text-red-400' },
            { icon: Mic, title: "O'zbekcha dublyaj", desc: 'Professional ovoz', color: 'text-green-400' },
            { icon: Zap, title: 'Yuqori sifat', desc: 'Full HD & 4K format', color: 'text-yellow-400' },
            { icon: Shield, title: 'Xavfsiz to\'lov', desc: 'Click orqali to\'lov', color: 'text-purple-400' },
          ].map(({ icon: Icon, title, desc, color }) => (
            <div key={title} className="flex items-center gap-3 p-4 rounded-2xl bg-[#1a1a1a] border border-[#2a2a2a]">
              <div className="w-10 h-10 rounded-xl bg-[#2a2a2a] flex items-center justify-center flex-shrink-0">
                <Icon className={`w-5 h-5 ${color}`} />
              </div>
              <div>
                <p className="text-sm font-semibold text-white">{title}</p>
                <p className="text-xs text-[#888]">{desc}</p>
              </div>
            </div>
          ))}
        </div>
      </section>

      {/* Movie Sections */}
      {loading ? (
        <div className="max-w-7xl mx-auto px-4 sm:px-6 pb-10">
          <MovieGridSkeleton count={8} />
        </div>
      ) : (
        sections.map((section) => (
          section.movies.length > 0 && (
            <MovieSection key={section.title} title={section.title} movies={section.movies} />
          )
        ))
      )}

      {/* CTA Section */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 py-16">
        <div className="relative rounded-3xl overflow-hidden bg-gradient-to-r from-[#e50914] to-[#831010] p-10 text-center">
          <div className="absolute inset-0 opacity-10"
            style={{ backgroundImage: 'radial-gradient(circle at 20% 50%, white 1px, transparent 1px), radial-gradient(circle at 80% 20%, white 1px, transparent 1px)', backgroundSize: '60px 60px' }}
          />
          <div className="relative">
            <Film className="w-12 h-12 text-white mx-auto mb-4 opacity-80" />
            <h2 className="text-3xl font-bold text-white mb-3">Eng sara filmlarni tomosha qiling!</h2>
            <p className="text-white/80 text-base mb-6 max-w-md mx-auto">
              Premera filmlar, qiziqarli seriallar va kinoteatr chiptalarini onlayn xarid qiling.
            </p>
            <div className="flex justify-center gap-3">
              <Link
                href="/movies"
                className="inline-flex items-center gap-2 px-8 py-3 bg-white text-[#e50914] font-bold rounded-2xl hover:scale-105 transition-transform"
              >
                <Play className="w-5 h-5 fill-[#e50914]" />
                Katalogga o&apos;tish
              </Link>
              <Link
                href="/tickets"
                className="inline-flex items-center gap-2 px-8 py-3 bg-black/40 hover:bg-black/60 text-white font-bold rounded-2xl border border-white/20 transition-all hover:scale-105"
              >
                Chiptalar
              </Link>
            </div>
          </div>
        </div>
      </section>
    </MainLayout>
  );
}

function MovieSection({ title, movies }: { title: string; movies: Movie[] }) {
  const [scrollRef, setScrollRef] = useState<HTMLDivElement | null>(null);

  const scroll = useCallback((dir: 'left' | 'right') => {
    if (scrollRef) {
      scrollRef.scrollBy({ left: dir === 'left' ? -400 : 400, behavior: 'smooth' });
    }
  }, [scrollRef]);

  return (
    <section className="max-w-7xl mx-auto px-4 sm:px-6 mb-10">
      <div className="flex items-center justify-between mb-4">
        <h2 className="text-xl font-bold text-white">{title}</h2>
        <div className="flex items-center gap-2">
          <button
            onClick={() => scroll('left')}
            className="p-1.5 rounded-lg bg-[#1a1a1a] hover:bg-[#2a2a2a] text-[#888] hover:text-white transition-colors"
          >
            <ChevronLeft className="w-4 h-4" />
          </button>
          <button
            onClick={() => scroll('right')}
            className="p-1.5 rounded-lg bg-[#1a1a1a] hover:bg-[#2a2a2a] text-[#888] hover:text-white transition-colors"
          >
            <ChevronRight className="w-4 h-4" />
          </button>
          <Link href="/movies" className="text-sm text-[#e50914] hover:underline flex items-center gap-1">
            Barchasi <ChevronRight className="w-4 h-4" />
          </Link>
        </div>
      </div>
      <div
        ref={(el) => setScrollRef(el)}
        className="flex gap-4 overflow-x-auto no-scrollbar pb-2"
      >
        {movies.map((movie) => (
          <div key={movie.id} className="flex-none w-44">
            <MovieCard movie={movie} size="md" />
          </div>
        ))}
      </div>
    </section>
  );
}
