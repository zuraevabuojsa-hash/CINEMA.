'use client';

import { useEffect, useState } from 'react';
import { useParams, useRouter } from 'next/navigation';
import { ArrowLeft, Film } from 'lucide-react';
import VideoPlayer from '@/components/ui/VideoPlayer';
import { moviesAPI } from '@/lib/api';
import { PageLoader } from '@/components/ui/LoadingSpinner';
import toast from 'react-hot-toast';

interface Movie {
  id: string;
  title: string;
  poster: string;
  video_url?: string;
  hls_url?: string;
}

export default function PlayerPage() {
  const { id } = useParams<{ id: string }>();
  const router = useRouter();
  const [movie, setMovie] = useState<Movie | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    loadMovie();
  }, [id]);

  async function loadMovie() {
    try {
      const res = await moviesAPI.getById(id);
      setMovie(res.data.movie);
    } catch {
      toast.error('Kino topilmadi');
      router.push('/movies');
    }
    setLoading(false);
  }

  if (loading) return <PageLoader />;
  if (!movie) return null;

  const videoSrc = movie.video_url || '/videos/sample.mp4';

  return (
    <div className="h-screen w-screen bg-black flex flex-col overflow-hidden relative">
      {/* Top back bar */}
      <div className="absolute top-0 left-0 right-0 z-30 p-4 bg-gradient-to-b from-black/80 to-transparent flex items-center justify-between pointer-events-auto">
        <button
          onClick={() => router.back()}
          className="flex items-center gap-2 px-3 py-2 bg-white/10 hover:bg-white/20 text-white rounded-xl backdrop-blur-md transition-all text-sm font-medium"
        >
          <ArrowLeft className="w-4 h-4" />
          Orqaga
        </button>
        <div className="flex items-center gap-2 text-white/90 text-sm font-semibold truncate max-w-md">
          <Film className="w-4 h-4 text-[#e50914]" />
          <span className="truncate">{movie.title}</span>
        </div>
        <div className="w-16" />
      </div>

      {/* Main player */}
      <div className="flex-1 w-full h-full">
        <VideoPlayer
          src={videoSrc}
          poster={movie.poster}
          title={movie.title}
          autoPlay={true}
        />
      </div>
    </div>
  );
}
