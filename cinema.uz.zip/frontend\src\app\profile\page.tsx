'use client';

import { useEffect, useState } from 'react';
import { useRouter } from 'next/navigation';
import {
  User, Mail, Camera, Save, Film, Users, Heart, History, LogOut
} from 'lucide-react';
import MainLayout from '@/components/layout/MainLayout';
import { useAuthStore } from '@/store/authStore';
import { usersAPI } from '@/lib/api';
import { formatDate } from '@/lib/utils';
import toast from 'react-hot-toast';

export default function ProfilePage() {
  const router = useRouter();
  const { user, isAuthenticated, updateUser, logout } = useAuthStore();

  const [username, setUsername] = useState('');
  const [avatar, setAvatar] = useState('');
  const [saving, setSaving] = useState(false);
  const [stats, setStats] = useState({ favorites: 0, history: 0, friends: 0 });

  useEffect(() => {
    if (!isAuthenticated) { router.push('/login'); return; }
    if (user) {
      setUsername(user.username);
      setAvatar(user.avatar);
    }
    loadStats();
  }, [isAuthenticated, user]);

  async function loadStats() {
    try {
      const [favRes, histRes, friendRes] = await Promise.all([
        usersAPI.getFavorites(),
        usersAPI.getHistory(),
        usersAPI.getFriends(),
      ]);
      setStats({
        favorites: favRes.data.favorites?.length || 0,
        history: histRes.data.history?.length || 0,
        friends: friendRes.data.friends?.length || 0,
      });
    } catch {}
  }

  async function saveProfile() {
    setSaving(true);
    try {
      await usersAPI.updateProfile({ username, avatar });
      updateUser({ username, avatar });
      toast.success('Profil yangilandi');
    } catch (err: unknown) {
      const e = err as { response?: { data?: { message?: string } } };
      toast.error(e.response?.data?.message || 'Xato yuz berdi');
    }
    setSaving(false);
  }

  const avatarSeeds = ['alpha', 'beta', 'gamma', 'delta', 'epsilon', 'zeta', 'eta', 'theta'];

  return (
    <MainLayout>
      <div className="max-w-2xl mx-auto px-4 sm:px-6 py-8">
        <h1 className="text-3xl font-bold text-white mb-8">Profil</h1>

        {/* Stats */}
        <div className="grid grid-cols-3 gap-4 mb-8">
          {[
            { label: 'Sevimlilar', value: stats.favorites, icon: Heart, href: '/favorites', color: 'text-pink-400' },
            { label: 'Ko\'rganlar', value: stats.history, icon: History, href: '/history', color: 'text-blue-400' },
            { label: "Do'stlar", value: stats.friends, icon: Users, href: '/friends', color: 'text-green-400' },
          ].map(({ label, value, icon: Icon, href, color }) => (
            <button
              key={label}
              onClick={() => router.push(href)}
              className="flex flex-col items-center p-4 bg-[#1a1a1a] rounded-2xl border border-[#2a2a2a] hover:border-[#3a3a3a] transition-colors"
            >
              <Icon className={`w-6 h-6 ${color} mb-2`} />
              <span className="text-2xl font-bold text-white">{value}</span>
              <span className="text-xs text-[#888] mt-1">{label}</span>
            </button>
          ))}
        </div>

        {/* Profile Form */}
        <div className="bg-[#1a1a1a] rounded-3xl border border-[#2a2a2a] p-6 space-y-6">
          {/* Avatar */}
          <div>
            <label className="text-sm text-[#888] block mb-3">Profil rasmi</label>
            <div className="flex items-center gap-4 mb-4">
              {/* eslint-disable-next-line @next/next/no-img-element */}
              <img
                src={avatar}
                alt={username}
                className="w-20 h-20 rounded-2xl object-cover bg-[#2a2a2a]"
              />
              <div>
                <p className="text-sm text-white mb-1">Avatar tanlang</p>
                <p className="text-xs text-[#888]">yoki URL kiriting</p>
              </div>
            </div>
            {/* Avatar presets */}
            <div className="flex gap-2 flex-wrap mb-3">
              {avatarSeeds.map((seed) => {
                const url = `https://api.dicebear.com/7.x/avataaars/svg?seed=${seed}`;
                return (
                  <button
                    key={seed}
                    onClick={() => setAvatar(url)}
                    className={`w-10 h-10 rounded-xl overflow-hidden border-2 transition-all ${
                      avatar === url ? 'border-[#e50914] scale-110' : 'border-[#2a2a2a] hover:border-[#444]'
                    }`}
                  >
                    {/* eslint-disable-next-line @next/next/no-img-element */}
                    <img src={url} alt={seed} className="w-full h-full" />
                  </button>
                );
              })}
            </div>
            <input
              type="url"
              value={avatar}
              onChange={(e) => setAvatar(e.target.value)}
              placeholder="Rasm URL manzili"
              className="w-full bg-[#0d0d0d] border border-[#2a2a2a] rounded-xl px-4 py-2.5 text-sm text-white placeholder-[#555] focus:outline-none focus:border-[#e50914] transition-colors"
            />
          </div>

          {/* Username */}
          <div>
            <label className="text-sm text-[#888] block mb-2">Foydalanuvchi nomi</label>
            <div className="relative">
              <User className="absolute left-4 top-1/2 -translate-y-1/2 w-4 h-4 text-[#888]" />
              <input
                type="text"
                value={username}
                onChange={(e) => setUsername(e.target.value)}
                className="w-full pl-11 pr-4 py-3 bg-[#0d0d0d] border border-[#2a2a2a] rounded-2xl text-white text-sm focus:outline-none focus:border-[#e50914] transition-colors"
              />
            </div>
          </div>

          {/* Email (read-only) */}
          <div>
            <label className="text-sm text-[#888] block mb-2">Elektron pochta</label>
            <div className="relative">
              <Mail className="absolute left-4 top-1/2 -translate-y-1/2 w-4 h-4 text-[#888]" />
              <input
                type="email"
                value={user?.email || ''}
                readOnly
                className="w-full pl-11 pr-4 py-3 bg-[#0d0d0d]/50 border border-[#2a2a2a] rounded-2xl text-[#888] text-sm cursor-not-allowed"
              />
            </div>
            <p className="text-xs text-[#666] mt-1">Email o'zgartirilmaydi</p>
          </div>

          {/* Account Info */}
          {user && (
            <div className="p-4 bg-[#0d0d0d] rounded-2xl border border-[#2a2a2a]">
              <div className="flex justify-between items-center">
                <div>
                  <p className="text-xs text-[#888]">Ro'yxatdan o'tgan sana</p>
                  <p className="text-sm text-white mt-0.5">{formatDate(new Date().toISOString())}</p>
                </div>
                <span className={`text-xs px-3 py-1 rounded-full font-medium ${
                  user.role === 'admin' ? 'bg-[#e50914]/20 text-[#e50914]' : 'bg-green-500/20 text-green-400'
                }`}>
                  {user.role === 'admin' ? 'Administrator' : 'Foydalanuvchi'}
                </span>
              </div>
            </div>
          )}

          <button
            onClick={saveProfile}
            disabled={saving}
            className="w-full flex items-center justify-center gap-2 py-3.5 bg-[#e50914] hover:bg-[#c0070f] disabled:opacity-50 text-white font-bold rounded-2xl transition-colors"
          >
            {saving ? (
              <div className="w-5 h-5 border-2 border-white/30 border-t-white rounded-full animate-spin" />
            ) : (
              <>
                <Save className="w-4 h-4" />
                Saqlash
              </>
            )}
          </button>
        </div>

        {/* Logout */}
        <button
          onClick={() => { logout(); router.push('/'); }}
          className="w-full flex items-center justify-center gap-2 py-3 mt-4 bg-[#1a1a1a] hover:bg-[#e50914]/10 text-[#e50914] font-medium rounded-2xl transition-colors border border-[#2a2a2a] hover:border-[#e50914]/30"
        >
          <LogOut className="w-4 h-4" />
          Chiqish
        </button>
      </div>
    </MainLayout>
  );
}
