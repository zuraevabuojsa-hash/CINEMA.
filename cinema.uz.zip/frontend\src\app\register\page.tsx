'use client';

import { useState } from 'react';
import Link from 'next/link';
import { useRouter } from 'next/navigation';
import { Eye, EyeOff, Play, Mail, Lock, User, CheckCircle2, Sparkles } from 'lucide-react';
import { useAuthStore } from '@/store/authStore';
import GoogleAuthModal from '@/components/auth/GoogleAuthModal';
import toast from 'react-hot-toast';

export default function RegisterPage() {
  const router = useRouter();
  const { register } = useAuthStore();

  const [username, setUsername] = useState('');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [confirm, setConfirm] = useState('');
  const [showPass, setShowPass] = useState(false);
  const [showConfirm, setShowConfirm] = useState(false);
  const [loading, setLoading] = useState(false);
  const [googleModalOpen, setGoogleModalOpen] = useState(false);

  const checks = [
    { ok: password.length >= 6, label: 'Kamida 6 ta belgi' },
    { ok: password === confirm && confirm.length > 0, label: 'Parollar mos' },
  ];

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    const cleanUser = username.trim();
    const cleanEmail = email.trim();

    if (!cleanUser) return toast.error("Foydalanuvchi nomini kiriting");
    if (!cleanEmail || !cleanEmail.includes('@')) {
      return toast.error("To'g'ri elektron pochta manzilini kiriting (masalan: ismingiz@gmail.com)");
    }
    if (!password) return toast.error("Parolni kiriting");
    if (password.length < 6) return toast.error("Parol kamida 6 ta belgidan iborat bo'lishi kerak");
    if (password !== confirm) return toast.error("Kiritilgan parollar bir-biriga mos kelmadi");

    setLoading(true);
    try {
      await register(cleanUser, cleanEmail, password);
      toast.success('Muvaffaqiyatli ro\'yxatdan o\'tdingiz! Xush kelibsiz!');
      router.push('/');
    } catch (err: unknown) {
      const error = err as { response?: { data?: { message?: string } } };
      toast.error(error.response?.data?.message || "Ro'yxatdan o'tishda xatolik yuz berdi");
    }
    setLoading(false);
  }

  return (
    <div className="min-h-screen flex items-center justify-center p-4 transition-colors"
      style={{ backgroundColor: 'var(--bg)' }}>

      {/* Background glow */}
      <div className="absolute inset-0 overflow-hidden pointer-events-none">
        <div className="absolute top-1/4 right-1/4 w-96 h-96 bg-[#e50914]/5 rounded-full blur-3xl" />
        <div className="absolute bottom-1/3 left-1/3 w-96 h-96 bg-blue-500/5 rounded-full blur-3xl" />
      </div>

      <div className="relative w-full max-w-md">
        {/* Logo */}
        <div className="text-center mb-8">
          <Link href="/" className="inline-flex items-center gap-2">
            <div className="w-10 h-10 bg-[#e50914] rounded-xl flex items-center justify-center shadow-lg shadow-[#e50914]/30">
              <Play className="w-5 h-5 text-white fill-white" />
            </div>
            <span className="text-2xl font-bold" style={{ color: 'var(--text)' }}>
              Cinema<span className="text-[#e50914]">Uz</span>
            </span>
          </Link>
          <h1 className="text-2xl font-bold mt-6 mb-1" style={{ color: 'var(--text)' }}>
            Hisob yarating
          </h1>
          <p className="text-sm" style={{ color: 'var(--muted)' }}>
            Eng sara kinolar va seriallar olamiga xush kelibsiz
          </p>
        </div>

        <div className="rounded-3xl border p-8" style={{ backgroundColor: 'var(--card)', borderColor: 'var(--border)' }}>

          {/* ===== GOOGLE TUGMASI ===== */}
          <button
            onClick={() => setGoogleModalOpen(true)}
            className="w-full flex items-center justify-center gap-3 py-3.5 rounded-2xl border font-semibold text-sm transition-all hover:shadow-lg hover:scale-[1.01] mb-6 shadow-sm"
            style={{ backgroundColor: 'var(--bg)', borderColor: 'var(--border)', color: 'var(--text)' }}
          >
            <svg className="w-5 h-5" viewBox="0 0 24 24">
              <path fill="#4285F4" d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z"/>
              <path fill="#34A853" d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z"/>
              <path fill="#FBBC05" d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.07H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.93l2.85-2.22.81-.62z"/>
              <path fill="#EA4335" d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.07l3.66 2.84c.87-2.6 3.3-4.53 6.16-4.53z"/>
            </svg>
            Google bilan ro&apos;yxatdan o&apos;tish
          </button>

          {/* Ajratuvchi */}
          <div className="flex items-center gap-3 mb-6">
            <div className="flex-1 h-px" style={{ backgroundColor: 'var(--border)' }} />
            <span className="text-xs" style={{ color: 'var(--muted)' }}>yoki email bilan</span>
            <div className="flex-1 h-px" style={{ backgroundColor: 'var(--border)' }} />
          </div>

          {/* Form */}
          <form onSubmit={handleSubmit} className="space-y-4">
            {/* Username */}
            <div>
              <label className="text-sm block mb-2" style={{ color: 'var(--muted)' }}>Foydalanuvchi nomi (login)</label>
              <div className="relative">
                <User className="absolute left-4 top-1/2 -translate-y-1/2 w-4 h-4" style={{ color: 'var(--muted)' }} />
                <input
                  type="text"
                  value={username}
                  onChange={(e) => setUsername(e.target.value)}
                  placeholder="masalan: sardorbek"
                  required
                  className="w-full pl-11 pr-4 py-3 rounded-2xl text-sm focus:outline-none focus:border-[#e50914] transition-colors border"
                  style={{ backgroundColor: 'var(--input-bg)', borderColor: 'var(--border)', color: 'var(--text)' }}
                />
              </div>
            </div>

            {/* Email */}
            <div>
              <label className="text-sm block mb-2" style={{ color: 'var(--muted)' }}>Elektron pochta</label>
              <div className="relative">
                <Mail className="absolute left-4 top-1/2 -translate-y-1/2 w-4 h-4" style={{ color: 'var(--muted)' }} />
                <input
                  type="email"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  placeholder="ismingiz@example.com"
                  required
                  className="w-full pl-11 pr-4 py-3 rounded-2xl text-sm focus:outline-none focus:border-[#e50914] transition-colors border"
                  style={{ backgroundColor: 'var(--input-bg)', borderColor: 'var(--border)', color: 'var(--text)' }}
                />
              </div>
            </div>

            {/* Parol */}
            <div>
              <label className="text-sm block mb-2" style={{ color: 'var(--muted)' }}>Parol (kamida 6 ta belgi)</label>
              <div className="relative">
                <Lock className="absolute left-4 top-1/2 -translate-y-1/2 w-4 h-4" style={{ color: 'var(--muted)' }} />
                <input
                  type={showPass ? 'text' : 'password'}
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  placeholder="••••••••"
                  required
                  className="w-full pl-11 pr-12 py-3 rounded-2xl text-sm focus:outline-none focus:border-[#e50914] transition-colors border"
                  style={{ backgroundColor: 'var(--input-bg)', borderColor: 'var(--border)', color: 'var(--text)' }}
                />
                <button type="button" onClick={() => setShowPass(!showPass)}
                  className="absolute right-4 top-1/2 -translate-y-1/2" style={{ color: 'var(--muted)' }}>
                  {showPass ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                </button>
              </div>
            </div>

            {/* Tasdiqlash */}
            <div>
              <label className="text-sm block mb-2" style={{ color: 'var(--muted)' }}>Parolni tasdiqlang</label>
              <div className="relative">
                <Lock className="absolute left-4 top-1/2 -translate-y-1/2 w-4 h-4" style={{ color: 'var(--muted)' }} />
                <input
                  type={showConfirm ? 'text' : 'password'}
                  value={confirm}
                  onChange={(e) => setConfirm(e.target.value)}
                  placeholder="••••••••"
                  required
                  className="w-full pl-11 pr-12 py-3 rounded-2xl text-sm focus:outline-none focus:border-[#e50914] transition-colors border"
                  style={{ backgroundColor: 'var(--input-bg)', borderColor: 'var(--border)', color: 'var(--text)' }}
                />
                <button type="button" onClick={() => setShowConfirm(!showConfirm)}
                  className="absolute right-4 top-1/2 -translate-y-1/2" style={{ color: 'var(--muted)' }}>
                  {showConfirm ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                </button>
              </div>
            </div>

            {/* Parol tekshiruvi */}
            {password && (
              <div className="space-y-1.5">
                {checks.map(({ ok, label }) => (
                  <div key={label} className={`flex items-center gap-2 text-xs ${ok ? 'text-green-400' : ''}`}
                    style={!ok ? { color: 'var(--muted)' } : {}}>
                    <CheckCircle2 className={`w-3.5 h-3.5 ${ok ? 'text-green-400' : ''}`}
                      style={!ok ? { color: 'var(--border2)' } : {}} />
                    {label}
                  </div>
                ))}
              </div>
            )}

            <button
              type="submit"
              disabled={loading}
              className="w-full py-3.5 bg-[#e50914] hover:bg-[#c0070f] disabled:opacity-50 text-white font-bold rounded-2xl transition-all shadow-lg shadow-[#e50914]/25 flex items-center justify-center gap-2 mt-2"
            >
              {loading ? (
                <div className="w-5 h-5 border-2 border-white/30 border-t-white rounded-full animate-spin" />
              ) : (
                <>
                  <Sparkles className="w-4 h-4" />
                  Ro&apos;yxatdan o&apos;tish
                </>
              )}
            </button>
          </form>

          <p className="text-center text-sm mt-6" style={{ color: 'var(--muted)' }}>
            Allaqachon hisobingiz bormi?{' '}
            <Link href="/login" className="text-[#e50914] hover:underline font-medium">
              Kirish
            </Link>
          </p>
        </div>
      </div>

      {/* Google Auth Modal */}
      <GoogleAuthModal
        isOpen={googleModalOpen}
        onClose={() => setGoogleModalOpen(false)}
        title="Google bilan ro'yxatdan o'tish"
      />
    </div>
  );
}
