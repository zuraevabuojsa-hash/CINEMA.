'use client';

import { useEffect, useState } from 'react';
import { useRouter } from 'next/navigation';
import { Tv, Star, Play, Users } from 'lucide-react';
import MainLayout from '@/components/layout/MainLayout';
import { moviesAPI } from '@/lib/api';

interface Series {
  id: string;
  title: string;
  original_title: string;
  description: string;
  poster: string;
  backdrop: string;
  year: number;
  genres: string[];
  rating: number;
  seasons_count: number;
  episodes_count: number;
  audio_tracks: string[];
}

export default function SeriesPage() {
  const router = useRouter();
  const [series, setSeries] = useState<Series[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    moviesAPI.getSeries()
      .then(res => setSeries(res.data.series || []))
      .finally(() => setLoading(false));
  }, []);

  return (
    <MainLayout>
      <div className="max-w-7xl mx-auto px-4 sm:px-6 py-8">
        <div className="flex items-center gap-3 mb-8">
          <Tv className="w-7 h-7 text-purple-400" />
          <h1 className="text-3xl font-bold text-white">Seriallar</h1>
        </div>

        {loading ? (
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
            {Array.from({ length: 6 }).map((_, i) => (
              <div key={i} className="h-72 rounded-2xl skeleton" />
            ))}
          </div>
        ) : (
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
            {series.map((s) => (
              <div key={s.id} className="group bg-[#1a1a1a] rounded-2xl border border-[#2a2a2a] hover:border-[#3a3a3a] overflow-hidden transition-all hover:-translate-y-1">
                {/* Backdrop */}
                <div className="relative h-44 overflow-hidden">
                  {/* eslint-disable-next-line @next/next/no-img-element */}
                  <img src={s.backdrop} alt={s.title} className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500" />
                  <div className="absolute inset-0 bg-gradient-to-t from-[#1a1a1a] to-transparent" />
                  <div className="absolute top-3 left-3 flex gap-2">
                    {s.audio_tracks?.includes('uzbek') && (
                      <span className="text-[10px] font-bold px-2 py-0.5 bg-[#e50914] text-white rounded">UZ</span>
                    )}
                  </div>
                  <div className="absolute top-3 right-3 flex items-center gap-1 bg-black/70 rounded-lg px-2 py-1">
                    <Star className="w-3 h-3 text-[#f5c518] fill-[#f5c518]" />
                    <span className="text-xs font-semibold text-white">{s.rating}</span>
                  </div>
                  {/* Poster overlay */}
                  <div className="absolute bottom-3 left-3">
                    {/* eslint-disable-next-line @next/next/no-img-element */}
                    <img src={s.poster} alt={s.title} className="w-12 h-16 object-cover rounded-lg shadow-lg" />
                  </div>
                </div>

                <div className="p-4">
                  <h3 className="font-bold text-white text-lg mb-0.5">{s.title}</h3>
                  <p className="text-sm text-[#888] mb-2">{s.original_title}</p>
                  <p className="text-xs text-[#666] line-clamp-2 mb-3">{s.description}</p>

                  <div className="flex items-center justify-between text-xs text-[#888] mb-4">
                    <span>{s.seasons_count} fasl</span>
                    <span>{s.episodes_count} qism</span>
                    <span>{s.year}</span>
                  </div>

                  <div className="flex gap-2">
                    <button className="flex-1 flex items-center justify-center gap-1.5 py-2 bg-[#e50914] hover:bg-[#c0070f] text-white text-xs font-semibold rounded-xl transition-colors">
                      <Play className="w-3.5 h-3.5 fill-white" />
                      Ko'rish
                    </button>
                    <button className="flex items-center gap-1.5 px-3 py-2 bg-[#2a2a2a] hover:bg-[#3a3a3a] text-[#888] hover:text-white text-xs rounded-xl transition-colors">
                      <Users className="w-3.5 h-3.5" />
                    </button>
                  </div>
                </div>
              </div>
            ))}
          </div>
        )}

        {!loading && series.length === 0 && (
          <div className="text-center py-20">
            <Tv className="w-16 h-16 text-[#888] mx-auto mb-4" />
            <p className="text-[#888] text-lg">Seriallar hali qo'shilmagan</p>
          </div>
        )}
      </div>
    </MainLayout>
  );
}
