'use client';

import { useState } from 'react';
import { useRouter } from 'next/navigation';
import { Settings, Bell, Shield, Monitor, Globe, ChevronRight, Sun, Moon } from 'lucide-react';
import MainLayout from '@/components/layout/MainLayout';
import { useAuthStore } from '@/store/authStore';
import { useThemeStore } from '@/store/themeStore';
import toast from 'react-hot-toast';

export const dynamic = 'force-dynamic';

export default function SettingsPage() {
  const router = useRouter();
  const { isAuthenticated } = useAuthStore();
  const { isDark, toggleTheme } = useThemeStore();

  const [notifications, setNotifications] = useState({
    friendRequest: true,
    roomInvite: true,
    watchStart: true,
    email: false,
  });

  const [playback, setPlayback] = useState({
    autoplay: true,
  });

  const [privacy, setPrivacy] = useState({
    showOnline: true,
    allowFriendRequests: true,
    showHistory: false,
  });

  if (!isAuthenticated) {
    router.push('/login');
    return null;
  }

  function Toggle({ value, onChange }: { value: boolean; onChange: (v: boolean) => void }) {
    return (
      <button
        onClick={() => onChange(!value)}
        className={`w-11 h-6 rounded-full transition-colors relative flex-shrink-0 ${value ? 'bg-[#e50914]' : 'bg-[var(--border2)]'}`}
      >
        <div className={`absolute top-1 w-4 h-4 rounded-full bg-white transition-transform ${value ? 'translate-x-6' : 'translate-x-1'}`} />
      </button>
    );
  }

  return (
    <MainLayout>
      <div className="max-w-2xl mx-auto px-4 sm:px-6 py-8">
        {/* Header */}
        <div className="flex items-center gap-3 mb-8">
          <Settings className="w-7 h-7" style={{ color: 'var(--muted)' }} />
          <h1 className="text-3xl font-bold" style={{ color: 'var(--text)' }}>Sozlamalar</h1>
        </div>

        <div className="space-y-6">

          {/* ===== TEMA SOZLAMASI ===== */}
          <div className="rounded-2xl border overflow-hidden" style={{ backgroundColor: 'var(--card)', borderColor: 'var(--border)' }}>
            <div className="flex items-center gap-3 px-5 py-4 border-b" style={{ borderColor: 'var(--border)' }}>
              {isDark ? <Moon className="w-5 h-5" style={{ color: 'var(--muted)' }} /> : <Sun className="w-5 h-5" style={{ color: 'var(--muted)' }} />}
              <h2 className="font-semibold" style={{ color: 'var(--text)' }}>Ko'rinish</h2>
            </div>

            {/* Theme switcher */}
            <div className="p-5">
              <p className="text-sm font-medium mb-3" style={{ color: 'var(--text)' }}>Interfeys rejimi</p>
              <div className="grid grid-cols-2 gap-3">
                {/* Dark mode */}
                <button
                  onClick={() => !isDark && toggleTheme()}
                  className={`flex flex-col items-center gap-3 p-4 rounded-2xl border-2 transition-all ${
                    isDark ? 'border-[#e50914]' : 'border-transparent hover:border-[var(--border2)]'
                  }`}
                  style={{ backgroundColor: isDark ? '#1a1a1a' : 'var(--card2)', borderColor: isDark ? '#e50914' : 'var(--border)' }}
                >
                  {/* Dark preview */}
                  <div className="w-full h-16 rounded-xl bg-[#0d0d0d] border border-[#2a2a2a] overflow-hidden flex flex-col">
                    <div className="h-3 bg-[#1a1a1a] flex items-center gap-1 px-1.5">
                      <div className="w-3 h-1.5 rounded bg-[#e50914]" />
                      <div className="w-4 h-1 rounded bg-[#2a2a2a] ml-auto" />
                    </div>
                    <div className="flex-1 p-1 flex gap-1">
                      <div className="flex-1 bg-[#1a1a1a] rounded" />
                      <div className="flex-1 bg-[#1a1a1a] rounded" />
                      <div className="flex-1 bg-[#1a1a1a] rounded" />
                    </div>
                  </div>
                  <div className="flex items-center gap-2">
                    <Moon className="w-4 h-4 text-blue-400" />
                    <span className="text-sm font-medium" style={{ color: 'var(--text)' }}>Qorong'i</span>
                    {isDark && <span className="text-[10px] px-1.5 py-0.5 bg-[#e50914]/20 text-[#e50914] rounded-full">Faol</span>}
                  </div>
                </button>

                {/* Light mode */}
                <button
                  onClick={() => isDark && toggleTheme()}
                  className={`flex flex-col items-center gap-3 p-4 rounded-2xl border-2 transition-all`}
                  style={{ backgroundColor: !isDark ? '#f5f5f5' : 'var(--card2)', borderColor: !isDark ? '#e50914' : 'var(--border)' }}
                >
                  {/* Light preview */}
                  <div className="w-full h-16 rounded-xl bg-[#f0f0f0] border border-[#ddd] overflow-hidden flex flex-col">
                    <div className="h-3 bg-white flex items-center gap-1 px-1.5">
                      <div className="w-3 h-1.5 rounded bg-[#e50914]" />
                      <div className="w-4 h-1 rounded bg-[#ddd] ml-auto" />
                    </div>
                    <div className="flex-1 p-1 flex gap-1">
                      <div className="flex-1 bg-white rounded shadow-sm" />
                      <div className="flex-1 bg-white rounded shadow-sm" />
                      <div className="flex-1 bg-white rounded shadow-sm" />
                    </div>
                  </div>
                  <div className="flex items-center gap-2">
                    <Sun className="w-4 h-4 text-yellow-500" />
                    <span className="text-sm font-medium" style={{ color: 'var(--text)' }}>Yorug'</span>
                    {!isDark && <span className="text-[10px] px-1.5 py-0.5 bg-[#e50914]/20 text-[#e50914] rounded-full">Faol</span>}
                  </div>
                </button>
              </div>

              {/* Quick toggle */}
              <button
                onClick={toggleTheme}
                className="mt-3 w-full flex items-center justify-between px-4 py-3 rounded-xl transition-colors border"
                style={{ backgroundColor: 'var(--bg)', borderColor: 'var(--border)', color: 'var(--text)' }}
              >
                <div className="flex items-center gap-2">
                  {isDark ? <Moon className="w-4 h-4 text-blue-400" /> : <Sun className="w-4 h-4 text-yellow-500" />}
                  <span className="text-sm">
                    Hozir: <strong>{isDark ? "Qorong'i rejim" : "Yorug' rejim"}</strong>
                  </span>
                </div>
                <div className="text-xs px-3 py-1 bg-[#e50914] text-white rounded-lg font-medium">
                  {isDark ? "Yorug'ga o'tish" : "Qorong'iga o'tish"}
                </div>
              </button>
            </div>
          </div>

          {/* ===== BILDIRISHNOMALAR ===== */}
          <div className="rounded-2xl border overflow-hidden" style={{ backgroundColor: 'var(--card)', borderColor: 'var(--border)' }}>
            <div className="flex items-center gap-3 px-5 py-4 border-b" style={{ borderColor: 'var(--border)' }}>
              <Bell className="w-5 h-5" style={{ color: 'var(--muted)' }} />
              <h2 className="font-semibold" style={{ color: 'var(--text)' }}>Bildirishnomalar</h2>
            </div>
            <div className="divide-y" style={{ borderColor: 'var(--border)' }}>
              {[
                { label: "Do'stlik so'rovlari", desc: "Yangi do'stlik so'rovlarida xabar", value: notifications.friendRequest, set: (v: boolean) => setNotifications(p => ({ ...p, friendRequest: v })) },
                { label: 'Yangi premeralar', desc: "Katalogga yangi film qo'shilganda", value: notifications.roomInvite, set: (v: boolean) => setNotifications(p => ({ ...p, roomInvite: v })) },
                { label: 'Aksiya va chegirmalar', desc: 'Chiptalar uchun maxsus takliflar', value: notifications.watchStart, set: (v: boolean) => setNotifications(p => ({ ...p, watchStart: v })) },
                { label: 'Email xabarlari', desc: 'Muhim yangiliklar emailga', value: notifications.email, set: (v: boolean) => setNotifications(p => ({ ...p, email: v })) },
              ].map(({ label, desc, value, set }) => (
                <div key={label} className="flex items-center justify-between px-5 py-4" style={{ borderColor: 'var(--border)' }}>
                  <div>
                    <p className="text-sm font-medium" style={{ color: 'var(--text)' }}>{label}</p>
                    <p className="text-xs mt-0.5" style={{ color: 'var(--muted)' }}>{desc}</p>
                  </div>
                  <Toggle value={value} onChange={set} />
                </div>
              ))}
            </div>
          </div>

          {/* ===== VIDEO PLEER ===== */}
          <div className="rounded-2xl border overflow-hidden" style={{ backgroundColor: 'var(--card)', borderColor: 'var(--border)' }}>
            <div className="flex items-center gap-3 px-5 py-4 border-b" style={{ borderColor: 'var(--border)' }}>
              <Monitor className="w-5 h-5" style={{ color: 'var(--muted)' }} />
              <h2 className="font-semibold" style={{ color: 'var(--text)' }}>Video pleer</h2>
            </div>
            <div className="px-5 py-4">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium" style={{ color: 'var(--text)' }}>Avtomatik ijro</p>
                  <p className="text-xs mt-0.5" style={{ color: 'var(--muted)' }}>Keyingi qismni avtomatik boshlash</p>
                </div>
                <Toggle value={playback.autoplay} onChange={(v) => setPlayback(p => ({ ...p, autoplay: v }))} />
              </div>
            </div>
          </div>

          {/* ===== MAXFIYLIK ===== */}
          <div className="rounded-2xl border overflow-hidden" style={{ backgroundColor: 'var(--card)', borderColor: 'var(--border)' }}>
            <div className="flex items-center gap-3 px-5 py-4 border-b" style={{ borderColor: 'var(--border)' }}>
              <Shield className="w-5 h-5" style={{ color: 'var(--muted)' }} />
              <h2 className="font-semibold" style={{ color: 'var(--text)' }}>Maxfiylik</h2>
            </div>
            <div className="divide-y" style={{ borderColor: 'var(--border)' }}>
              {[
                { label: "Onlayn holatni ko'rsatish", desc: "Do'stlaringiz sizni ko'rishi", value: privacy.showOnline, set: (v: boolean) => setPrivacy(p => ({ ...p, showOnline: v })) },
                { label: "Do'stlik so'rovlarini qabul qilish", desc: "Boshqalar so'rov yuborishi", value: privacy.allowFriendRequests, set: (v: boolean) => setPrivacy(p => ({ ...p, allowFriendRequests: v })) },
                { label: "Ko'rish tarixini yashirish", desc: 'Tarixingizni maxfiy saqlash', value: privacy.showHistory, set: (v: boolean) => setPrivacy(p => ({ ...p, showHistory: v })) },
              ].map(({ label, desc, value, set }) => (
                <div key={label} className="flex items-center justify-between px-5 py-4" style={{ borderColor: 'var(--border)' }}>
                  <div>
                    <p className="text-sm font-medium" style={{ color: 'var(--text)' }}>{label}</p>
                    <p className="text-xs mt-0.5" style={{ color: 'var(--muted)' }}>{desc}</p>
                  </div>
                  <Toggle value={value} onChange={set} />
                </div>
              ))}
            </div>
          </div>

          {/* ===== TIL SOZLAMALARI ===== */}
          <div className="rounded-2xl border overflow-hidden" style={{ backgroundColor: 'var(--card)', borderColor: 'var(--border)' }}>
            <div className="flex items-center gap-3 px-5 py-4 border-b" style={{ borderColor: 'var(--border)' }}>
              <Globe className="w-5 h-5" style={{ color: 'var(--muted)' }} />
              <h2 className="font-semibold" style={{ color: 'var(--text)' }}>Til sozlamalari</h2>
            </div>
            <div className="divide-y" style={{ borderColor: 'var(--border)' }}>
              {[
                { label: 'Audio tili', options: ["O'zbekcha", 'Ruscha', 'Inglizcha'], selected: "O'zbekcha" },
                { label: 'Subtitr tili', options: ["O'zbekcha", 'Ruscha', 'Inglizcha', "O'chirish"], selected: "O'zbekcha" },
                { label: 'Video sifati', options: ['Auto', '1080p', '720p', '480p', '360p'], selected: 'Auto' },
              ].map(({ label, options, selected }) => (
                <div key={label} className="flex items-center justify-between px-5 py-4">
                  <p className="text-sm font-medium" style={{ color: 'var(--text)' }}>{label}</p>
                  <select
                    defaultValue={selected}
                    className="text-sm rounded-xl px-3 py-1.5 focus:outline-none focus:border-[#e50914] transition-colors border"
                    style={{ backgroundColor: 'var(--input-bg)', borderColor: 'var(--border)', color: 'var(--text)' }}
                  >
                    {options.map(o => <option key={o} value={o}>{o}</option>)}
                  </select>
                </div>
              ))}
            </div>
          </div>

          {/* Saqlash */}
          <button
            onClick={() => toast.success('Sozlamalar saqlandi')}
            className="w-full py-3.5 bg-[#e50914] hover:bg-[#c0070f] text-white font-bold rounded-2xl transition-colors"
          >
            Saqlash
          </button>

          {/* Xavfli zona */}
          <div className="rounded-2xl border overflow-hidden" style={{ borderColor: '#e50914' + '33' }}>
            <div className="px-5 py-4 border-b" style={{ borderColor: 'var(--border)' }}>
              <h2 className="font-semibold text-[#e50914]">Xavfli zona</h2>
            </div>
            <div className="p-5 space-y-3">
              <button
                className="w-full flex items-center justify-between px-4 py-3 rounded-xl text-sm transition-colors border"
                style={{ backgroundColor: 'var(--bg)', borderColor: 'var(--border)', color: 'var(--muted)' }}
              >
                <span>Ko'rish tarixini tozalash</span>
                <ChevronRight className="w-4 h-4" />
              </button>
              <button className="w-full flex items-center justify-between px-4 py-3 rounded-xl text-sm text-[#e50914] transition-colors border border-[#e50914]/20"
                style={{ backgroundColor: 'var(--bg)' }}>
                <span>Hisobni o'chirish</span>
                <ChevronRight className="w-4 h-4" />
              </button>
            </div>
          </div>

        </div>
      </div>
    </MainLayout>
  );
}
