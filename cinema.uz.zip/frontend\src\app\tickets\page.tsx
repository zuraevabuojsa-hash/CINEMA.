'use client';

import { useState, useEffect } from 'react';
import Link from 'next/link';
import {
  Ticket, Calendar, Clock, MapPin, Film,
  Search, CheckCircle2, ChevronRight, Printer,
  Sparkles, QrCode, Tag
} from 'lucide-react';
import MainLayout from '@/components/layout/MainLayout';
import TicketBookingModal from '@/components/ticket/TicketBookingModal';
import { moviesAPI, ticketsAPI } from '@/lib/api';
import { useAuthStore } from '@/store/authStore';
import toast from 'react-hot-toast';

interface Movie {
  id: string;
  title: string;
  poster: string;
  duration?: number;
  year?: number;
  rating?: number;
  genres?: string[];
  description?: string;
}

interface Cinema {
  id: string;
  name: string;
  address: string;
  phone: string;
  halls: string[];
  rating: number;
}

export default function TicketsPage() {
  const { user } = useAuthStore();
  const [tab, setTab] = useState<'sessions' | 'my-tickets'>('sessions');

  const [movies, setMovies] = useState<Movie[]>([]);
  const [cinemas, setCinemas] = useState<Cinema[]>([]);
  const [selectedCinema, setSelectedCinema] = useState<string>('all');
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedMovieForBooking, setSelectedMovieForBooking] = useState<Movie | null>(null);

  // My Tickets
  const [myTickets, setMyTickets] = useState<any[]>([]);
  const [loadingTickets, setLoadingTickets] = useState(false);

  useEffect(() => {
    async function loadData() {
      try {
        const [moviesRes, cinemasRes] = await Promise.all([
          moviesAPI.getAll({ limit: 18 }),
          ticketsAPI.getCinemas(),
        ]);
        setMovies(moviesRes.data.movies || []);
        setCinemas(cinemasRes.data.cinemas || []);
      } catch (e) {
        console.error(e);
      }
    }
    loadData();
  }, []);

  useEffect(() => {
    if (tab === 'my-tickets') {
      loadMyTickets();
    }
  }, [tab]);

  async function loadMyTickets() {
    setLoadingTickets(true);
    try {
      const res = await ticketsAPI.getMyTickets();
      setMyTickets(res.data.tickets || []);
    } catch {
      toast.error('Chiptalarni yuklab bo\'lmadi');
    }
    setLoadingTickets(false);
  }

  // Filter movies
  const filteredMovies = movies.filter(m => {
    if (!searchQuery.trim()) return true;
    return m.title.toLowerCase().includes(searchQuery.toLowerCase());
  });

  return (
    <MainLayout>
      <div className="min-h-screen bg-[#0c0c14] pt-24 pb-16 px-4 sm:px-6">
        <div className="max-w-7xl mx-auto space-y-8">

          {/* Hero Banner */}
          <div className="relative rounded-3xl overflow-hidden bg-gradient-to-r from-amber-600 via-orange-600 to-red-600 p-8 sm:p-12 shadow-2xl">
            <div className="absolute inset-0 bg-black/30 backdrop-blur-[2px]" />
            <div className="relative z-10 max-w-2xl space-y-4">
              <div className="inline-flex items-center gap-2 px-3 py-1.5 rounded-full bg-white/20 backdrop-blur-md text-white text-xs font-bold uppercase tracking-wider">
                <Ticket className="w-4 h-4 text-amber-300" />
                Kinoteatr Chiptalari Online
              </div>
              <h1 className="text-3xl sm:text-5xl font-black text-white tracking-tight leading-tight">
                Sevimli kinolaringizga chiptalarni navbatsiz oling
              </h1>
              <p className="text-white/80 text-sm sm:text-base leading-relaxed">
                Toshkentning eng yaxshi kinoteatrlaridan (Magic Cinema, Cinema Palace, Compass, Riviera) o&apos;rindiqlarni tanlang va to&apos;g&apos;ridan-to&apos;g&apos;ri xarid qiling.
              </p>
            </div>
          </div>

          {/* Navigation Tabs */}
          <div className="flex gap-2 p-1.5 bg-[#161624] border border-[#26263d] rounded-2xl max-w-md">
            <button
              onClick={() => setTab('sessions')}
              className={`flex-1 py-2.5 rounded-xl font-bold text-xs sm:text-sm transition-all flex items-center justify-center gap-2 ${
                tab === 'sessions'
                  ? 'bg-gradient-to-r from-orange-500 to-amber-600 text-white shadow-lg shadow-orange-500/20'
                  : 'text-[#888] hover:text-white'
              }`}
            >
              <Film className="w-4 h-4" />
              Kinolar va Seanslar
            </button>
            <button
              onClick={() => setTab('my-tickets')}
              className={`flex-1 py-2.5 rounded-xl font-bold text-xs sm:text-sm transition-all flex items-center justify-center gap-2 ${
                tab === 'my-tickets'
                  ? 'bg-gradient-to-r from-orange-500 to-amber-600 text-white shadow-lg shadow-orange-500/20'
                  : 'text-[#888] hover:text-white'
              }`}
            >
              <Ticket className="w-4 h-4" />
              Mening chiptalarim
              {myTickets.length > 0 && (
                <span className="w-5 h-5 rounded-full bg-white/20 text-white text-[10px] flex items-center justify-center">
                  {myTickets.length}
                </span>
              )}
            </button>
          </div>

          {/* TAB 1: SESSIONS & MOVIES */}
          {tab === 'sessions' && (
            <div className="space-y-6">
              {/* Search & Cinema filter */}
              <div className="flex flex-col sm:flex-row gap-4 justify-between items-center bg-[#141422] p-4 rounded-2xl border border-[#232338]">
                <div className="relative w-full sm:w-80">
                  <Search className="absolute left-3.5 top-1/2 -translate-y-1/2 w-4 h-4 text-[#777]" />
                  <input
                    type="text"
                    value={searchQuery}
                    onChange={e => setSearchQuery(e.target.value)}
                    placeholder="Film nomini qidiring..."
                    className="w-full pl-10 pr-4 py-2.5 bg-[#1b1b2d] border border-[#2c2c46] rounded-xl text-white text-xs placeholder-[#666] focus:outline-none focus:border-orange-500"
                  />
                </div>

                {/* Cinemas tags */}
                <div className="flex flex-wrap items-center gap-2 w-full sm:w-auto">
                  <span className="text-xs text-[#888] mr-1 hidden md:inline">Kinoteatr:</span>
                  <button
                    onClick={() => setSelectedCinema('all')}
                    className={`px-3 py-1.5 rounded-xl text-xs font-semibold transition-all ${
                      selectedCinema === 'all'
                        ? 'bg-orange-500 text-white'
                        : 'bg-[#1b1b2d] text-[#888] hover:text-white'
                    }`}
                  >
                    Barchasi
                  </button>
                  {cinemas.map(c => (
                    <button
                      key={c.id}
                      onClick={() => setSelectedCinema(c.id)}
                      className={`px-3 py-1.5 rounded-xl text-xs font-semibold transition-all ${
                        selectedCinema === c.id
                          ? 'bg-orange-500 text-white'
                          : 'bg-[#1b1b2d] text-[#888] hover:text-white'
                      }`}
                    >
                      {c.name.replace(' (Alisher Navoiy)', '')}
                    </button>
                  ))}
                </div>
              </div>

              {/* Movies Grid */}
              <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-6 gap-4">
                {filteredMovies.map(movie => (
                  <div
                    key={movie.id}
                    className="group bg-[#151524] rounded-2xl border border-[#232338] overflow-hidden hover:border-orange-500/50 hover:shadow-xl hover:shadow-orange-500/10 transition-all flex flex-col"
                  >
                    <div className="relative aspect-[2/3] overflow-hidden bg-[#1f1f33]">
                      {/* eslint-disable-next-line @next/next/no-img-element */}
                      <img
                        src={movie.poster}
                        alt={movie.title}
                        className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
                      />
                      <div className="absolute inset-0 bg-gradient-to-t from-black/90 via-black/20 to-transparent opacity-0 group-hover:opacity-100 transition-opacity flex flex-col justify-end p-3">
                        <button
                          onClick={() => setSelectedMovieForBooking(movie)}
                          className="w-full py-2 bg-gradient-to-r from-orange-500 to-amber-500 text-white text-xs font-bold rounded-xl shadow-lg flex items-center justify-center gap-1.5 hover:scale-102 transition-all"
                        >
                          <Ticket className="w-3.5 h-3.5" />
                          Chipta olish
                        </button>
                      </div>
                      <span className="absolute top-2 left-2 px-2 py-0.5 rounded-md bg-black/60 backdrop-blur-md text-[10px] font-bold text-amber-400">
                        ⭐ {movie.rating?.toFixed(1) || '8.5'}
                      </span>
                    </div>

                    <div className="p-3 flex-1 flex flex-col justify-between space-y-2">
                      <div>
                        <h3 className="font-bold text-white text-xs line-clamp-1 group-hover:text-orange-400 transition-colors">
                          {movie.title}
                        </h3>
                        <p className="text-[10px] text-[#777] line-clamp-1 mt-0.5">
                          {movie.genres?.join(', ') || 'Kino'}
                        </p>
                      </div>

                      <button
                        onClick={() => setSelectedMovieForBooking(movie)}
                        className="w-full py-2 bg-[#202033] hover:bg-orange-500 hover:text-white text-orange-400 text-xs font-bold rounded-xl transition-all border border-[#2e2e46] flex items-center justify-center gap-1.5"
                      >
                        <Ticket className="w-3.5 h-3.5" />
                        Chipta olish
                      </button>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* TAB 2: MY TICKETS */}
          {tab === 'my-tickets' && (
            <div className="space-y-6">
              {loadingTickets ? (
                <div className="p-12 text-center text-[#888]">
                  Chiptalar yuklanmoqda...
                </div>
              ) : myTickets.length === 0 ? (
                <div className="p-12 bg-[#141422] rounded-3xl border border-[#242438] text-center max-w-md mx-auto space-y-4">
                  <div className="w-16 h-16 rounded-3xl bg-orange-500/10 text-orange-400 flex items-center justify-center mx-auto">
                    <Ticket className="w-8 h-8" />
                  </div>
                  <h3 className="text-lg font-bold text-white">Sizda hali chiptalar yo&apos;q</h3>
                  <p className="text-xs text-[#888]">
                    Kinolar bo&apos;limiga o&apos;tib o&apos;zingizga ma&apos;qul seansga chipta sotib oling.
                  </p>
                  <button
                    onClick={() => setTab('sessions')}
                    className="px-6 py-2.5 bg-gradient-to-r from-orange-500 to-amber-600 text-white font-bold text-xs rounded-xl shadow-lg shadow-orange-500/20"
                  >
                    Seanslarni ko&apos;rish
                  </button>
                </div>
              ) : (
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  {myTickets.map(ticket => (
                    <div
                      key={ticket.id}
                      className="bg-[#161626] border border-[#272740] rounded-3xl p-5 shadow-xl relative overflow-hidden flex flex-col justify-between"
                    >
                      <div className="flex items-start justify-between border-b border-[#232338] pb-3 mb-3">
                        <div>
                          <span className="text-[10px] font-bold text-orange-400 tracking-wider">
                            № {ticket.ticket_number}
                          </span>
                          <h4 className="text-base font-bold text-white">{ticket.movie_title}</h4>
                          <p className="text-xs text-[#888]">{ticket.cinema_name} • {ticket.hall}</p>
                        </div>
                        <span className="px-2.5 py-1 rounded-full bg-green-500/10 text-green-400 border border-green-500/20 text-[10px] font-bold">
                          To&apos;langan
                        </span>
                      </div>

                      <div className="grid grid-cols-3 gap-2 text-xs py-2">
                        <div>
                          <span className="text-[#666] block text-[10px]">Sana:</span>
                          <span className="font-bold text-white">{ticket.date}</span>
                        </div>
                        <div>
                          <span className="text-[#666] block text-[10px]">Vaqt:</span>
                          <span className="font-bold text-white">{ticket.time}</span>
                        </div>
                        <div>
                          <span className="text-[#666] block text-[10px]">O&apos;rindiqlar:</span>
                          <span className="font-bold text-amber-400">{ticket.seats.join(', ')}</span>
                        </div>
                      </div>

                      <div className="flex items-center justify-between pt-3 border-t border-[#232338] mt-2">
                        <div className="text-xs">
                          <span className="text-[#666] block text-[10px]">Summa:</span>
                          <span className="font-bold text-white">{ticket.total_price.toLocaleString()} so&apos;m</span>
                        </div>

                        <div className="flex items-center gap-2">
                          {/* QR preview */}
                          <div className="w-10 h-10 bg-white p-0.5 rounded-lg">
                            <img
                              src={`https://api.qrserver.com/v1/create-qr-code/?size=100x100&data=${encodeURIComponent(ticket.qr_data)}`}
                              alt="QR"
                              className="w-full h-full object-contain"
                            />
                          </div>
                          <button
                            onClick={() => window.print()}
                            className="p-2 bg-[#232338] hover:bg-[#30304c] text-white rounded-xl text-xs transition-colors"
                            title="Chop etish"
                          >
                            <Printer className="w-4 h-4" />
                          </button>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>
          )}

        </div>
      </div>

      {/* Booking Modal */}
      {selectedMovieForBooking && (
        <TicketBookingModal
          movie={selectedMovieForBooking}
          onClose={() => setSelectedMovieForBooking(null)}
        />
      )}
    </MainLayout>
  );
}
