'use client';

import { useEffect } from 'react';
import { useRouter } from 'next/navigation';

export default function WatchTogetherPage() {
  const router = useRouter();

  useEffect(() => {
    router.replace('/movies');
  }, [router]);

  return null;
}
