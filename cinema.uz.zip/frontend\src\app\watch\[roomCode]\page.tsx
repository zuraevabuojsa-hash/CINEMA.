'use client';

import { useEffect, useState, useRef, useCallback } from 'react';
import { useParams, useRouter } from 'next/navigation';
import {
  Play, Pause, Volume2, VolumeX, Maximize, Minimize,
  SkipBack, SkipForward, Settings, Mic, MicOff,
  Users, MessageSquare, X, Send, Copy, LogOut,
  Wifi, WifiOff, Lock, Radio, Plus, List,
  ChevronRight, Hash, Film, Trash2, Search
} from 'lucide-react';
import { roomsAPI, moviesAPI } from '@/lib/api';
import { getSocket } from '@/lib/socket';
import { useAuthStore } from '@/store/authStore';
import { formatTime, copyToClipboard, generateRoomInviteUrl, formatRelativeTime } from '@/lib/utils';
import { PageLoader } from '@/components/ui/LoadingSpinner';
import VoiceChat from '@/components/room/VoiceChat';
import toast from 'react-hot-toast';

interface Participant {
  id: string;
  user_id: string;
  username: string;
  avatar: string;
  is_host: boolean;
  is_muted: boolean;
  connection_status: string;
}

interface ChatMessage {
  id: string;
  user_id: string;
  username: string;
  avatar: string;
  message: string;
  created_at: string;
}

interface PlaylistItem {
  id: string;
  title: string;
  poster: string;
  duration: number;
  video_url: string;
  added_by: string;
}

interface RoomData {
  id: string;
  room_code: string;
  room_name: string;
  host_id: string;
  movie: {
    id: string;
    title: string;
    video_url: string;
    poster: string;
    audio_tracks: string[];
    subtitles: string[];
    duration: number;
  };
  voice_enabled: boolean;
  chat_enabled: boolean;
  is_locked: boolean;
  status: string;
}

export default function WatchRoomPage() {
  const { roomCode } = useParams<{ roomCode: string }>();
  const router = useRouter();
  const { user, isAuthenticated, loadUser } = useAuthStore();

  const videoRef = useRef<HTMLVideoElement>(null);
  const chatEndRef = useRef<HTMLDivElement>(null);

  const [room, setRoom] = useState<RoomData | null>(null);
  const [participants, setParticipants] = useState<Participant[]>([]);
  const [messages, setMessages] = useState<ChatMessage[]>([]);
  const [playlist, setPlaylist] = useState<PlaylistItem[]>([]);
  const [loading, setLoading] = useState(true);
  const [isHost, setIsHost] = useState(false);
  const [error, setError] = useState('');

  // Video state
  const [isPlaying, setIsPlaying] = useState(false);
  const [currentTime, setCurrentTime] = useState(0);
  const [duration, setDuration] = useState(0);
  const [volume, setVolume] = useState(0.8);
  const [isMuted, setIsMuted] = useState(false);
  const [isFullscreen, setIsFullscreen] = useState(false);
  const [showControls, setShowControls] = useState(true);
  const [syncStatus, setSyncStatus] = useState('');
  const [isConnected, setIsConnected] = useState(false);
  const [isSeeking, setIsSeeking] = useState(false);
  const controlsTimerRef = useRef<ReturnType<typeof setTimeout> | null>(null);

  // UI state
  const [rightTab, setRightTab] = useState<'chat' | 'participants' | 'playlist'>('chat');
  const [chatInput, setChatInput] = useState('');
  const [micEnabled, setMicEnabled] = useState(false);
  const [showAddVideo, setShowAddVideo] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');
  const [searchResults, setSearchResults] = useState<{ id: string; title: string; poster: string; duration: number; video_url: string }[]>([]);

  const normalizedCode = (roomCode || '').trim().toUpperCase();

  useEffect(() => {
    let mounted = true;

    async function checkAuthAndJoin() {
      const token = typeof window !== 'undefined' ? localStorage.getItem('cinema_token') : null;
      if (!token) {
        router.push(`/login?redirect=/watch/${normalizedCode}`);
        return;
      }

      if (!isAuthenticated) {
        try {
          await loadUser();
        } catch {
          router.push(`/login?redirect=/watch/${normalizedCode}`);
          return;
        }
      }

      if (mounted) {
        joinRoom();
      }
    }

    checkAuthAndJoin();

    return () => {
      mounted = false;
      leaveRoom();
    };
  }, [normalizedCode]);

  async function joinRoom() {
    setLoading(true);
    setError('');
    try {
      const res = await roomsAPI.join(normalizedCode);
      const { room: roomData, is_host: hostStatus } = res.data;
      setRoom(roomData);
      setIsHost(hostStatus);
      setParticipants(roomData.participants || []);
      // Playlist ga joriy kinoni qo'shish
      if (roomData.movie) {
        setPlaylist([{
          id: roomData.movie.id,
          title: roomData.movie.title,
          poster: roomData.movie.poster,
          duration: (roomData.movie.duration || 120) * 60,
          video_url: roomData.movie.video_url,
          added_by: roomData.host_id,
        }]);
      }
      setLoading(false);
      initSocket(roomData, hostStatus);
      if (roomData.playback) {
        setCurrentTime(roomData.playback.current_time || 0);
        setIsPlaying(roomData.playback.is_playing || false);
      }
    } catch (err: unknown) {
      const e = err as { response?: { status?: number; data?: { message?: string } } };
      if (e.response?.status === 401) {
        router.push(`/login?redirect=/watch/${normalizedCode}`);
        return;
      }
      setError(e.response?.data?.message || 'Xonaga kirib bo\'lmadi');
      setLoading(false);
    }
  }

  function initSocket(roomData: RoomData, hostStatus: boolean) {
    const socket = getSocket();
    setIsConnected(socket.connected);
    socket.on('connect', () => setIsConnected(true));
    socket.on('disconnect', () => setIsConnected(false));
    socket.emit('join_room', { room_code: normalizedCode });

    socket.on('room_state', ({ playback }: { playback: { current_time: number; is_playing: boolean } }) => {
      if (playback && videoRef.current) {
        videoRef.current.currentTime = playback.current_time;
      }
    });

    socket.on('sync_play', ({ current_time, by_id, by }: { current_time: number; by_id?: string; by?: string }) => {
      if (videoRef.current) {
        if (by_id !== user?.id) {
          const diff = Math.abs(videoRef.current.currentTime - current_time);
          if (diff > 1.5) {
            videoRef.current.currentTime = current_time;
          }
          const playPromise = videoRef.current.play();
          if (playPromise !== undefined) {
            playPromise.catch((err) => {
              console.log('Autoplay prevented:', err);
              setSyncStatus(`${by || 'Hamrohingiz'} videoni boshladi. Ekranni bosing!`);
            });
          }
        }
        setIsPlaying(true);
        setSyncStatus('');
      }
    });

    socket.on('sync_pause', ({ current_time, by_id, by }: { current_time: number; by_id?: string; by?: string }) => {
      if (videoRef.current) {
        if (by_id !== user?.id) {
          videoRef.current.pause();
          if (current_time !== undefined) {
            videoRef.current.currentTime = current_time;
          }
        }
        setIsPlaying(false);
      }
    });

    socket.on('sync_seek', ({ current_time, by_id, by }: { current_time: number; by_id?: string; by?: string }) => {
      if (videoRef.current) {
        if (by_id !== user?.id) {
          videoRef.current.currentTime = current_time;
          setSyncStatus(`${by || 'Hamroh'} videoni o'tkazdi`);
          setTimeout(() => setSyncStatus(''), 2000);
        }
      }
    });

    socket.on('sync_state', ({ current_time, is_playing }: { current_time: number; is_playing: boolean }) => {
      if (videoRef.current) {
        const diff = Math.abs(videoRef.current.currentTime - current_time);
        if (diff > 1.5) videoRef.current.currentTime = current_time;
        if (is_playing && videoRef.current.paused) {
          videoRef.current.play().catch(() => {});
          setIsPlaying(true);
        }
        if (!is_playing && !videoRef.current.paused) {
          videoRef.current.pause();
          setIsPlaying(false);
        }
      }
    });

    socket.on('new_message', (msg: ChatMessage) => {
      setMessages(prev => [...prev, msg]);
      setTimeout(() => chatEndRef.current?.scrollIntoView({ behavior: 'smooth' }), 100);
    });

    socket.on('user_joined', ({ user: u }: { user: { id: string; username: string; avatar: string } }) => {
      toast.success(`${u.username} xonaga kirdi`);
      setParticipants(prev => {
        if (prev.find(p => p.user_id === u.id)) return prev;
        return [...prev, { id: u.id, user_id: u.id, username: u.username, avatar: u.avatar, is_host: false, is_muted: true, connection_status: 'online' }];
      });
    });

    socket.on('user_left', ({ user: u }: { user: { id: string; username: string } }) => {
      toast(`${u.username} chiqdi`, { icon: '👋' });
      setParticipants(prev => prev.filter(p => p.user_id !== u.id));
    });

    socket.on('participant_mic_changed', ({ user_id, is_muted }: { user_id: string; is_muted: boolean }) => {
      setParticipants(prev => prev.map(p => p.user_id === user_id ? { ...p, is_muted } : p));
    });

    socket.on('participant_kicked', ({ user_id }: { user_id: string }) => {
      if (user_id === user?.id) { toast.error('Siz xonadan chiqarildingiz'); router.push('/'); }
    });

    socket.on('room_ended', () => { toast('Xona tugatildi', { icon: '🎬' }); router.push('/'); });

    setTimeout(() => socket.emit('request_sync', { room_code: normalizedCode }), 1000);
  }

  async function leaveRoom() {
    try {
      await roomsAPI.leave(normalizedCode);
      const socket = getSocket();
      socket.emit('leave_room', { room_code: normalizedCode });
      ['connect','disconnect','sync_play','sync_pause','sync_seek','new_message',
       'user_joined','user_left','room_state','sync_state','room_ended',
       'participant_kicked','participant_mic_changed'].forEach(e => socket.off(e));
    } catch {}
  }

  function togglePlay() {
    if (!videoRef.current) return;
    const socket = getSocket();
    if (isPlaying) {
      videoRef.current.pause();
      setIsPlaying(false);
      socket.emit('pause', { room_code: normalizedCode, current_time: videoRef.current.currentTime });
    } else {
      const playPromise = videoRef.current.play();
      if (playPromise !== undefined) {
        playPromise.then(() => {
          setIsPlaying(true);
          socket.emit('play', { room_code: normalizedCode, current_time: videoRef.current?.currentTime || 0 });
        }).catch((err) => {
          console.error('Play error:', err);
        });
      }
    }
  }

  function handleSeek(e: React.ChangeEvent<HTMLInputElement>) {
    const time = parseFloat(e.target.value);
    setCurrentTime(time);
    if (videoRef.current) videoRef.current.currentTime = time;
  }

  function handleSeekEnd() {
    setIsSeeking(false);
    if (videoRef.current) {
      getSocket().emit('seek', { room_code: normalizedCode, current_time: videoRef.current.currentTime });
    }
  }

  function skip(sec: number) {
    if (!videoRef.current) return;
    const t = Math.max(0, Math.min(duration, currentTime + sec));
    videoRef.current.currentTime = t;
    setCurrentTime(t);
    getSocket().emit('seek', { room_code: normalizedCode, current_time: t });
  }

  function handleVolumeChange(e: React.ChangeEvent<HTMLInputElement>) {
    const v = parseFloat(e.target.value);
    setVolume(v);
    if (videoRef.current) videoRef.current.volume = v;
    setIsMuted(v === 0);
  }

  function toggleMute() {
    if (!videoRef.current) return;
    const m = !isMuted;
    setIsMuted(m);
    videoRef.current.volume = m ? 0 : volume;
  }

  function toggleFullscreen() {
    const el = document.getElementById('video-container');
    if (!el) return;
    if (!document.fullscreenElement) { el.requestFullscreen(); setIsFullscreen(true); }
    else { document.exitFullscreen(); setIsFullscreen(false); }
  }

  function showControlsTemporarily() {
    setShowControls(true);
    if (controlsTimerRef.current) clearTimeout(controlsTimerRef.current);
    controlsTimerRef.current = setTimeout(() => {
      if (isPlaying) setShowControls(false);
    }, 3000);
  }

  function sendMessage() {
    if (!chatInput.trim()) return;
    getSocket().emit('chat_message', { room_code: normalizedCode, message: chatInput.trim() });
    setChatInput('');
  }

  async function toggleMic() {
    if (!micEnabled) {
      try {
        await navigator.mediaDevices.getUserMedia({ audio: true });
        setMicEnabled(true);
        getSocket().emit('mic_on', { room_code: normalizedCode });
        toast.success('Mikrofon yoqildi');
      } catch { toast.error('Mikrofon ruxsati berilmadi'); }
    } else {
      setMicEnabled(false);
      getSocket().emit('mic_off', { room_code: normalizedCode });
    }
  }

  async function searchMovies(q: string) {
    setSearchQuery(q);
    if (!q.trim()) { setSearchResults([]); return; }
    try {
      const res = await moviesAPI.search(q);
      const movies = (res.data.results?.movies || []).map((m: { id: string; title: string; poster: string; duration: number; video_url: string }) => ({
        id: m.id, title: m.title, poster: m.poster, duration: m.duration * 60, video_url: m.video_url
      }));
      setSearchResults(movies);
    } catch {}
  }

  function addToPlaylist(movie: { id: string; title: string; poster: string; duration: number; video_url: string }) {
    const item: PlaylistItem = { ...movie, added_by: user?.username || '' };
    setPlaylist(prev => {
      if (prev.find(p => p.id === movie.id)) { toast('Allaqachon qo\'shilgan'); return prev; }
      toast.success(`${movie.title} qo'shildi`);
      return [...prev, item];
    });
    setShowAddVideo(false);
    setSearchQuery('');
    setSearchResults([]);
  }

  function getVideoSrc(url?: string) {
    if (!url) return '/videos/sample.mp4';
    if (url.startsWith('http://') || url.startsWith('https://')) return url;
    if (url.startsWith('/')) return url;
    return `/${url}`;
  }

  function playFromPlaylist(item: PlaylistItem) {
    if (videoRef.current) {
      videoRef.current.src = getVideoSrc(item.video_url);
      videoRef.current.load();
      videoRef.current.play().catch(() => {});
      setIsPlaying(true);
      getSocket().emit('play', { room_code: normalizedCode, current_time: 0 });
    }
  }

  function removeFromPlaylist(id: string) {
    setPlaylist(prev => prev.filter(p => p.id !== id));
  }

  if (loading) return <PageLoader />;

  if (error) {
    return (
      <div className="min-h-screen bg-[#0f0f23] flex items-center justify-center p-4">
        <div className="text-center max-w-md bg-[#1a1a2e] border border-[#2a2a4a] rounded-3xl p-8 shadow-2xl">
          <WifiOff className="w-16 h-16 text-[#e50914] mx-auto mb-4" />
          <h2 className="text-2xl font-bold text-white mb-2">Xonaga kirib bo'lmadi</h2>
          <p className="text-[#888] mb-6 text-sm">{error}</p>
          <div className="flex flex-col sm:flex-row gap-3 justify-center">
            <button
              onClick={() => joinRoom()}
              className="px-6 py-3 bg-[#e50914] hover:bg-[#c0070f] text-white rounded-2xl font-semibold transition-colors"
            >
              Qaytadan urinish
            </button>
            <button
              onClick={() => router.push('/watch-together')}
              className="px-6 py-3 bg-white/10 hover:bg-white/15 text-white rounded-2xl font-semibold transition-colors border border-white/10"
            >
              Yangi xona yaratish
            </button>
          </div>
        </div>
      </div>
    );
  }

  if (!room) return null;

  const progress = duration > 0 ? (currentTime / duration) * 100 : 0;

  return (
    <div className="h-screen bg-[#0f0f23] flex flex-col overflow-hidden">

      {/* ===== TOP BAR ===== */}
      <div className="flex items-center justify-between px-4 py-2.5 bg-[#1a1a2e] border-b border-[#2a2a4a] flex-shrink-0">
        <div className="flex items-center gap-3">
          <button onClick={() => { leaveRoom(); router.push('/'); }}
            className="p-1.5 rounded-lg hover:bg-white/10 text-[#888] hover:text-white transition-colors">
            <LogOut className="w-4 h-4" />
          </button>
          <div className="flex items-center gap-2">
            <div className="w-7 h-7 bg-[#e50914] rounded-lg flex items-center justify-center">
              <Film className="w-4 h-4 text-white" />
            </div>
            <div>
              <h1 className="text-sm font-bold text-white leading-none">{room.room_name}</h1>
              <p className="text-[10px] text-[#888]">{room.movie?.title}</p>
            </div>
          </div>
        </div>

        <div className="flex items-center gap-3">
          {/* Sync status */}
          {syncStatus && (
            <div className="flex items-center gap-1.5 text-xs text-yellow-400">
              <Radio className="w-3.5 h-3.5 animate-pulse" />
              {syncStatus}
            </div>
          )}

          {/* Connection */}
          <div className={`flex items-center gap-1.5 text-xs ${isConnected ? 'text-green-400' : 'text-red-400'}`}>
            {isConnected ? <Wifi className="w-3.5 h-3.5" /> : <WifiOff className="w-3.5 h-3.5" />}
            <span>{isConnected ? 'Ulangan' : 'Uzilgan'}</span>
          </div>

          {/* Room code + copy */}
          <div className="flex items-center gap-1.5 px-3 py-1.5 bg-[#2a2a4a] rounded-xl">
            <Hash className="w-3.5 h-3.5 text-[#888]" />
            <span className="text-xs font-bold text-white tracking-wider">{normalizedCode}</span>
            <button onClick={() => { copyToClipboard(generateRoomInviteUrl(normalizedCode)); toast.success('Havola nusxalandi!'); }}
              className="ml-1 text-[#e50914] hover:text-red-400 transition-colors">
              <Copy className="w-3 h-3" />
            </button>
          </div>

          {/* Participants count */}
          <div className="flex items-center gap-1.5 text-xs text-[#888]">
            <Users className="w-3.5 h-3.5" />
            <span>{participants.length} kishi</span>
          </div>

          {/* Mic */}
          {room.voice_enabled && (
            <button onClick={toggleMic}
              className={`flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs font-medium transition-all ${
                micEnabled ? 'bg-[#e50914]/20 text-[#e50914] border border-[#e50914]/40 mic-active' : 'bg-[#2a2a4a] text-[#888] hover:text-white'
              }`}>
              {micEnabled ? <Mic className="w-3.5 h-3.5" /> : <MicOff className="w-3.5 h-3.5" />}
              {micEnabled ? 'Yoqiq' : 'Mikrofon'}
            </button>
          )}

          {/* End room */}
          {isHost && (
            <button onClick={() => { getSocket().emit('room_end', { room_code: normalizedCode }); }}
              className="px-3 py-1.5 bg-[#e50914]/20 hover:bg-[#e50914]/30 text-[#e50914] text-xs font-medium rounded-xl transition-colors border border-[#e50914]/30">
              Tugatish
            </button>
          )}
        </div>
      </div>

      {/* ===== MAIN CONTENT ===== */}
      <div className="flex flex-1 overflow-hidden">

        {/* ===== LEFT: VIDEO + CONTROLS ===== */}
        <div className="flex-1 flex flex-col min-w-0 bg-black">

          {/* Video */}
          <div
            id="video-container"
            className="relative flex-1 bg-black cursor-pointer group"
            onMouseMove={showControlsTemporarily}
            onClick={togglePlay}
          >
            <video
              ref={videoRef}
              src={getVideoSrc(room.movie?.video_url)}
              className="w-full h-full object-contain"
              playsInline
              preload="auto"
              onTimeUpdate={() => { if (!isSeeking && videoRef.current) setCurrentTime(videoRef.current.currentTime); }}
              onLoadedMetadata={() => {
                if (videoRef.current) {
                  setDuration(videoRef.current.duration);
                  if (currentTime > 0) videoRef.current.currentTime = currentTime;
                  videoRef.current.volume = volume;
                }
              }}
              onPlay={() => setIsPlaying(true)}
              onPause={() => setIsPlaying(false)}
              onClick={e => e.stopPropagation()}
            />

            {/* Sync badge */}
            {syncStatus && (
              <div className="absolute top-4 left-1/2 -translate-x-1/2 px-4 py-2 bg-black/80 backdrop-blur-sm rounded-full text-sm text-white flex items-center gap-2 z-10">
                <Radio className="w-4 h-4 text-[#e50914] animate-pulse" />
                {syncStatus}
              </div>
            )}

            {/* Play/Pause center icon */}
            {!isPlaying && (
              <div className="absolute inset-0 flex items-center justify-center pointer-events-none">
                <div className="w-20 h-20 bg-black/60 rounded-full flex items-center justify-center backdrop-blur-sm">
                  <Play className="w-10 h-10 text-white fill-white ml-1" />
                </div>
              </div>
            )}

            {/* Controls overlay */}
            <div className={`absolute bottom-0 left-0 right-0 transition-opacity duration-300 ${showControls ? 'opacity-100' : 'opacity-0'}`}
              onClick={e => e.stopPropagation()}>
              <div className="video-controls px-4 pb-4 pt-12">

                {/* Progress */}
                <div className="flex items-center gap-2 mb-3">
                  <span className="text-xs text-white font-mono w-12">{formatTime(currentTime)}</span>
                  <div className="flex-1">
                    <input
                      type="range" min={0} max={duration || 100} value={currentTime}
                      onChange={handleSeek}
                      onMouseDown={() => setIsSeeking(true)}
                      onMouseUp={handleSeekEnd}
                      onTouchEnd={handleSeekEnd}
                      className="w-full progress-bar cursor-pointer"
                      style={{ background: `linear-gradient(to right, #e50914 ${progress}%, rgba(255,255,255,0.2) ${progress}%)` }}
                    />
                  </div>
                  <span className="text-xs text-white font-mono w-12 text-right">{formatTime(duration)}</span>
                </div>

                {/* Buttons */}
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-1">
                    <button onClick={togglePlay} className="p-2 hover:bg-white/10 rounded-xl text-white transition-colors">
                      {isPlaying ? <Pause className="w-5 h-5 fill-white" /> : <Play className="w-5 h-5 fill-white" />}
                    </button>
                    <button onClick={() => skip(-10)} className="p-2 hover:bg-white/10 rounded-xl text-white transition-colors">
                      <SkipBack className="w-4 h-4" />
                    </button>
                    <button onClick={() => skip(10)} className="p-2 hover:bg-white/10 rounded-xl text-white transition-colors">
                      <SkipForward className="w-4 h-4" />
                    </button>

                    {/* Volume */}
                    <div className="flex items-center gap-2 group/vol">
                      <button onClick={toggleMute} className="p-2 hover:bg-white/10 rounded-xl text-white transition-colors">
                        {isMuted || volume === 0 ? <VolumeX className="w-4 h-4" /> : <Volume2 className="w-4 h-4" />}
                      </button>
                      <div className="w-0 overflow-hidden group-hover/vol:w-20 transition-all duration-200">
                        <input type="range" min={0} max={1} step={0.05}
                          value={isMuted ? 0 : volume}
                          onChange={handleVolumeChange}
                          className="w-20"
                          style={{ background: `linear-gradient(to right, white ${(isMuted ? 0 : volume) * 100}%, rgba(255,255,255,0.2) ${(isMuted ? 0 : volume) * 100}%)` }}
                        />
                      </div>
                    </div>

                    {/* Time */}
                    <span className="text-xs text-white/60 ml-2 font-mono">
                      {formatTime(currentTime)} / {formatTime(duration)}
                    </span>
                  </div>

                  <div className="flex items-center gap-1">
                    <button onClick={toggleFullscreen} className="p-2 hover:bg-white/10 rounded-xl text-white transition-colors">
                      {isFullscreen ? <Minimize className="w-4 h-4" /> : <Maximize className="w-4 h-4" />}
                    </button>
                  </div>
                </div>
              </div>
            </div>
          </div>

          {/* ===== BOTTOM: ADD VIDEO ===== */}
          <div className="bg-[#1a1a2e] border-t border-[#2a2a4a] px-4 py-2.5 flex-shrink-0">
            {showAddVideo ? (
              <div className="flex items-center gap-2">
                <div className="relative flex-1">
                  <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-[#888]" />
                  <input
                    type="text"
                    value={searchQuery}
                    onChange={e => searchMovies(e.target.value)}
                    placeholder="Kino qidiring..."
                    autoFocus
                    className="w-full pl-9 pr-4 py-2 bg-[#0f0f23] border border-[#2a2a4a] rounded-xl text-white text-sm placeholder-[#555] focus:outline-none focus:border-[#e50914] transition-colors"
                  />
                </div>
                <button onClick={() => { setShowAddVideo(false); setSearchResults([]); setSearchQuery(''); }}
                  className="p-2 text-[#888] hover:text-white transition-colors">
                  <X className="w-4 h-4" />
                </button>
              </div>
            ) : (
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2 text-sm text-[#888]">
                  <Film className="w-4 h-4" />
                  <span>Playlistdagi: <span className="text-white font-medium">{playlist.length} ta video</span></span>
                </div>
                <button onClick={() => setShowAddVideo(true)}
                  className="flex items-center gap-1.5 px-3 py-1.5 bg-[#e50914] hover:bg-[#c0070f] text-white text-xs font-medium rounded-xl transition-colors">
                  <Plus className="w-3.5 h-3.5" />
                  Video qo'shish
                </button>
              </div>
            )}

            {/* Search results */}
            {searchResults.length > 0 && (
              <div className="mt-2 bg-[#0f0f23] border border-[#2a2a4a] rounded-xl overflow-hidden max-h-40 overflow-y-auto">
                {searchResults.map(m => (
                  <button key={m.id} onClick={() => addToPlaylist(m)}
                    className="w-full flex items-center gap-3 px-3 py-2 hover:bg-white/5 transition-colors text-left">
                    {/* eslint-disable-next-line @next/next/no-img-element */}
                    <img src={m.poster} alt={m.title} className="w-8 h-11 object-cover rounded-lg" />
                    <span className="text-sm text-white">{m.title}</span>
                    <Plus className="w-4 h-4 text-[#e50914] ml-auto flex-shrink-0" />
                  </button>
                ))}
              </div>
            )}
          </div>
        </div>

        {/* ===== RIGHT SIDEBAR ===== */}
        <div className="w-80 flex flex-col bg-[#1a1a2e] border-l border-[#2a2a4a] flex-shrink-0">

          {/* Tabs */}
          <div className="flex border-b border-[#2a2a4a] flex-shrink-0">
            {[
              { id: 'chat', icon: MessageSquare, label: 'Chat' },
              { id: 'participants', icon: Users, label: `(${participants.length})` },
              { id: 'playlist', icon: List, label: `(${playlist.length})` },
            ].map(({ id, icon: Icon, label }) => (
              <button key={id} onClick={() => setRightTab(id as typeof rightTab)}
                className={`flex-1 flex items-center justify-center gap-1.5 py-3 text-xs font-medium transition-colors border-b-2 ${
                  rightTab === id ? 'border-[#e50914] text-white bg-[#e50914]/5' : 'border-transparent text-[#888] hover:text-white'
                }`}>
                <Icon className="w-3.5 h-3.5" />
                {label}
              </button>
            ))}
          </div>

          {/* ===== CHAT ===== */}
          {rightTab === 'chat' && (
            <>
              <div className="flex-1 overflow-y-auto p-3 space-y-3">
                {messages.length === 0 && (
                  <div className="text-center text-[#555] text-sm py-10">
                    <MessageSquare className="w-8 h-8 mx-auto mb-2 opacity-30" />
                    <p>Birinchi xabar yuboring!</p>
                  </div>
                )}
                {messages.map(msg => {
                  const isOwn = msg.user_id === user?.id;
                  return (
                    <div key={msg.id} className={`flex gap-2 ${isOwn ? 'flex-row-reverse' : ''}`}>
                      {/* eslint-disable-next-line @next/next/no-img-element */}
                      <img src={msg.avatar || `https://api.dicebear.com/7.x/avataaars/svg?seed=${msg.username}`}
                        alt={msg.username} className="w-7 h-7 rounded-full flex-shrink-0 mt-1" />
                      <div className={`max-w-[75%] flex flex-col ${isOwn ? 'items-end' : 'items-start'}`}>
                        {!isOwn && <span className="text-[10px] text-[#888] mb-1 ml-1">{msg.username}</span>}
                        <div className={`px-3 py-2 text-sm text-white leading-relaxed ${isOwn ? 'chat-bubble-own' : 'chat-bubble-other'}`}>
                          {msg.message}
                        </div>
                        <span className="text-[10px] text-[#555] mt-1 mx-1">{formatRelativeTime(msg.created_at)}</span>
                      </div>
                    </div>
                  );
                })}
                <div ref={chatEndRef} />
              </div>

              {room.chat_enabled && (
                <div className="p-3 border-t border-[#2a2a4a] flex-shrink-0">
                  <div className="flex gap-2">
                    <input
                      type="text" value={chatInput}
                      onChange={e => setChatInput(e.target.value)}
                      onKeyDown={e => e.key === 'Enter' && sendMessage()}
                      placeholder="Xabar yozing..."
                      maxLength={500}
                      className="flex-1 bg-[#0f0f23] border border-[#2a2a4a] rounded-xl px-3 py-2.5 text-sm text-white placeholder-[#555] focus:outline-none focus:border-[#e50914] transition-colors"
                    />
                    <button onClick={sendMessage} disabled={!chatInput.trim()}
                      className="p-2.5 bg-[#e50914] hover:bg-[#c0070f] disabled:opacity-40 text-white rounded-xl transition-colors">
                      <Send className="w-4 h-4" />
                    </button>
                  </div>
                </div>
              )}
            </>
          )}

          {/* ===== ISHTIROKCHILAR ===== */}
          {rightTab === 'participants' && (
            <div className="flex-1 overflow-y-auto p-3 space-y-2">
              {participants.length === 0 && (
                <div className="text-center text-[#555] text-sm py-10">
                  <Users className="w-8 h-8 mx-auto mb-2 opacity-30" />
                  <p>Hali hech kim yo'q</p>
                </div>
              )}
              {participants.map(p => (
                <div key={p.id} className="flex items-center gap-3 p-3 rounded-2xl bg-[#0f0f23] hover:bg-white/3 transition-colors">
                  <div className="relative">
                    {/* eslint-disable-next-line @next/next/no-img-element */}
                    <img src={p.avatar || `https://api.dicebear.com/7.x/avataaars/svg?seed=${p.username}`}
                      alt={p.username} className="w-10 h-10 rounded-full" />
                    <div className={`absolute -bottom-0.5 -right-0.5 w-3.5 h-3.5 rounded-full border-2 border-[#1a1a2e] ${
                      p.connection_status === 'online' ? 'bg-green-500' : 'bg-[#444]'
                    }`} />
                  </div>
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-1.5">
                      <span className="text-sm font-medium text-white truncate">{p.username}</span>
                      {p.is_host && (
                        <span className="text-[10px] px-1.5 py-0.5 bg-[#e50914]/20 text-[#e50914] rounded-full">Ega</span>
                      )}
                    </div>
                    <p className="text-xs text-[#555]">{p.connection_status === 'online' ? 'Onlayn' : 'Oflayn'}</p>
                  </div>
                  <div className="flex items-center gap-2">
                    {p.is_muted ? (
                      <MicOff className="w-3.5 h-3.5 text-[#555]" />
                    ) : (
                      <div className="flex items-end gap-0.5 h-4">
                        <div className="speaking-bar w-1 bg-green-400 rounded-full" />
                        <div className="speaking-bar w-1 bg-green-400 rounded-full" />
                        <div className="speaking-bar w-1 bg-green-400 rounded-full" />
                      </div>
                    )}
                    {isHost && p.user_id !== user?.id && (
                      <button onClick={() => getSocket().emit('kick_participant', { room_code: roomCode, target_user_id: p.user_id })}
                        className="p-1 rounded-lg hover:bg-[#e50914]/20 text-[#555] hover:text-[#e50914] transition-colors">
                        <X className="w-3 h-3" />
                      </button>
                    )}
                  </div>
                </div>
              ))}
            </div>
          )}

          {/* ===== PLAYLIST ===== */}
          {rightTab === 'playlist' && (
            <div className="flex-1 overflow-y-auto p-3 space-y-2">
              {playlist.length === 0 && (
                <div className="text-center text-[#555] text-sm py-10">
                  <List className="w-8 h-8 mx-auto mb-2 opacity-30" />
                  <p>Playlist bo'sh</p>
                  <button onClick={() => { setRightTab('chat'); setShowAddVideo(true); }}
                    className="mt-3 text-[#e50914] text-xs hover:underline">
                    Video qo'shish
                  </button>
                </div>
              )}
              {playlist.map((item, idx) => (
                <div key={item.id}
                  className="flex items-center gap-3 p-2.5 rounded-2xl bg-[#0f0f23] hover:bg-white/3 transition-colors group cursor-pointer"
                  onClick={() => playFromPlaylist(item)}>
                  <div className="relative flex-shrink-0">
                    {/* eslint-disable-next-line @next/next/no-img-element */}
                    <img src={item.poster} alt={item.title} className="w-14 h-20 object-cover rounded-xl" />
                    <div className="absolute inset-0 bg-black/50 rounded-xl opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center">
                      <Play className="w-6 h-6 text-white fill-white" />
                    </div>
                    <span className="absolute top-1 left-1 text-[10px] bg-black/70 text-white px-1.5 rounded font-mono">
                      {idx + 1}
                    </span>
                  </div>
                  <div className="flex-1 min-w-0">
                    <p className="text-sm font-medium text-white line-clamp-2 leading-tight">{item.title}</p>
                    <p className="text-[10px] text-[#555] mt-1">{formatTime(item.duration)}</p>
                  </div>
                  {isHost && (
                    <button onClick={e => { e.stopPropagation(); removeFromPlaylist(item.id); }}
                      className="p-1.5 rounded-xl opacity-0 group-hover:opacity-100 hover:bg-[#e50914]/20 text-[#555] hover:text-[#e50914] transition-all">
                      <Trash2 className="w-3.5 h-3.5" />
                    </button>
                  )}
                </div>
              ))}
            </div>
          )}
        </div>
      </div>

      {/* Voice Chat */}
      {room.voice_enabled && (
        <VoiceChat roomCode={normalizedCode} userId={user?.id || ''} participants={participants} micEnabled={micEnabled} />
      )}
    </div>
  );
}
