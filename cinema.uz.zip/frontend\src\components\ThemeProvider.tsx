'use client';

import { useEffect } from 'react';
import { useThemeStore } from '@/store/themeStore';

export default function ThemeProvider({ children }: { children: React.ReactNode }) {
  const { setTheme } = useThemeStore();

  useEffect(() => {
    // Saqlangan temani yuklash
    const saved = localStorage.getItem('cinema_theme');
    if (saved === 'light') {
      setTheme(false);
    } else {
      setTheme(true); // default: qorong'i
    }
  }, []);

  return <>{children}</>;
}
