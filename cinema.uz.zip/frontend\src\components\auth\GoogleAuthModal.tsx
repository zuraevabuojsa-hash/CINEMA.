'use client';

import { useState } from 'react';
import { useRouter } from 'next/navigation';
import { X, User, Mail, ShieldCheck, ArrowRight, Sparkles } from 'lucide-react';
import { useAuthStore } from '@/store/authStore';
import toast from 'react-hot-toast';

interface GoogleAuthModalProps {
  isOpen: boolean;
  onClose: () => void;
  title?: string;
}

export default function GoogleAuthModal({ isOpen, onClose, title = "Google bilan kirish" }: GoogleAuthModalProps) {
  const router = useRouter();
  const { googleLogin } = useAuthStore();
  const [email, setEmail] = useState('');
  const [name, setName] = useState('');
  const [loading, setLoading] = useState(false);

  if (!isOpen) return null;

  async function handleDirectGoogle(selectedEmail: string, selectedName: string) {
    if (!selectedEmail || !selectedEmail.includes('@')) {
      toast.error('To\'g\'ri Google email manzilini kiriting');
      return;
    }
    setLoading(true);
    try {
      await googleLogin({
        email: selectedEmail.trim().toLowerCase(),
        name: selectedName || selectedEmail.split('@')[0],
        avatar: `https://api.dicebear.com/7.x/avataaars/svg?seed=${encodeURIComponent(selectedName || selectedEmail)}`,
      });
      toast.success('Google orqali muvaffaqiyatli kirdingiz!');
      onClose();
      router.push('/');
    } catch (err: any) {
      toast.error(err.response?.data?.message || 'Google orqali kirishda xato yuz berdi');
    }
    setLoading(false);
  }

  function handleSubmitCustom(e: React.FormEvent) {
    e.preventDefault();
    handleDirectGoogle(email, name);
  }

  const quickGoogleAccounts = [
    {
      name: 'Sardor Qodirov',
      email: 'sardor@gmail.com',
      avatar: 'https://api.dicebear.com/7.x/avataaars/svg?seed=Sardor',
    },
    {
      name: 'Malika Karimova',
      email: 'malika@gmail.com',
      avatar: 'https://api.dicebear.com/7.x/avataaars/svg?seed=Malika',
    },
  ];

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm animate-fadeIn">
      <div
        className="relative w-full max-w-md rounded-3xl border shadow-2xl overflow-hidden p-6 sm:p-8 animate-scaleUp"
        style={{ backgroundColor: 'var(--card, #161626)', borderColor: 'var(--border, #2a2a44)' }}
      >
        {/* Close button */}
        <button
          onClick={onClose}
          className="absolute right-4 top-4 p-2 rounded-full hover:bg-white/10 text-[#888] hover:text-white transition-colors"
        >
          <X className="w-5 h-5" />
        </button>

        {/* Google Header */}
        <div className="text-center space-y-2 mb-6">
          <div className="w-14 h-14 rounded-2xl bg-white p-3 shadow-lg mx-auto flex items-center justify-center">
            <svg className="w-8 h-8" viewBox="0 0 24 24">
              <path fill="#4285F4" d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z"/>
              <path fill="#34A853" d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z"/>
              <path fill="#FBBC05" d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.07H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.93l2.85-2.22.81-.62z"/>
              <path fill="#EA4335" d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.07l3.66 2.84c.87-2.6 3.3-4.53 6.16-4.53z"/>
            </svg>
          </div>
          <h3 className="text-xl font-black text-white">{title}</h3>
          <p className="text-xs text-[#888]">
            CinemaUz hisobingizga Google orqali bir zumda kiring
          </p>
        </div>

        {/* One-click accounts */}
        <div className="space-y-2 mb-4">
          <p className="text-[11px] font-bold uppercase tracking-wider text-[#777] mb-1">
            Tezkor hisoblar:
          </p>
          {quickGoogleAccounts.map(acc => (
            <button
              key={acc.email}
              disabled={loading}
              onClick={() => handleDirectGoogle(acc.email, acc.name)}
              className="w-full flex items-center justify-between p-3 rounded-2xl bg-[#1b1b2d] hover:bg-[#25253d] border border-[#2b2b48] transition-all hover:scale-[1.01] text-left group disabled:opacity-50"
            >
              <div className="flex items-center gap-3">
                <img src={acc.avatar} alt={acc.name} className="w-9 h-9 rounded-full bg-white/10" />
                <div>
                  <h4 className="text-sm font-bold text-white group-hover:text-blue-400 transition-colors">
                    {acc.name}
                  </h4>
                  <p className="text-xs text-[#888]">{acc.email}</p>
                </div>
              </div>
              <ArrowRight className="w-4 h-4 text-[#777] group-hover:text-white transition-colors" />
            </button>
          ))}
        </div>

        {/* Divider */}
        <div className="flex items-center gap-3 my-4">
          <div className="flex-1 h-px bg-white/10" />
          <span className="text-[11px] text-[#666] uppercase font-semibold">yoki o&apos;z Google emailingiz</span>
          <div className="flex-1 h-px bg-white/10" />
        </div>

        {/* Custom Google account form */}
        <form onSubmit={handleSubmitCustom} className="space-y-3">
          <div>
            <label className="text-xs text-[#aaa] font-medium block mb-1">Ism va familiyangiz</label>
            <div className="relative">
              <User className="absolute left-3.5 top-1/2 -translate-y-1/2 w-4 h-4 text-[#777]" />
              <input
                type="text"
                value={name}
                onChange={e => setName(e.target.value)}
                placeholder="Azizbek Rahimov"
                className="w-full pl-10 pr-4 py-2.5 bg-[#121220] border border-[#2a2a44] rounded-xl text-white placeholder-[#555] text-xs focus:outline-none focus:border-blue-500"
              />
            </div>
          </div>

          <div>
            <label className="text-xs text-[#aaa] font-medium block mb-1">Google Email</label>
            <div className="relative">
              <Mail className="absolute left-3.5 top-1/2 -translate-y-1/2 w-4 h-4 text-[#777]" />
              <input
                type="email"
                value={email}
                onChange={e => setEmail(e.target.value)}
                placeholder="foydalanuvchi@gmail.com"
                required
                className="w-full pl-10 pr-4 py-2.5 bg-[#121220] border border-[#2a2a44] rounded-xl text-white placeholder-[#555] text-xs focus:outline-none focus:border-blue-500"
              />
            </div>
          </div>

          <button
            type="submit"
            disabled={loading}
            className="w-full py-3 bg-[#4285F4] hover:bg-[#3367D6] text-white font-bold rounded-xl transition-all shadow-lg shadow-blue-500/25 flex items-center justify-center gap-2 text-sm disabled:opacity-50 mt-2"
          >
            {loading ? (
              <div className="w-5 h-5 border-2 border-white/30 border-t-white rounded-full animate-spin" />
            ) : (
              <>
                <Sparkles className="w-4 h-4" />
                Google orqali kirish
              </>
            )}
          </button>
        </form>

        {/* Security badge */}
        <div className="mt-4 pt-3 border-t border-white/5 flex items-center justify-center gap-1.5 text-[11px] text-[#777]">
          <ShieldCheck className="w-4 h-4 text-emerald-400" />
          <span>Google xavfsizlik protokollari bilan himoyalangan</span>
        </div>
      </div>
    </div>
  );
}
