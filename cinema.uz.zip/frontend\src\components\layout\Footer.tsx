import Link from 'next/link';
import { Play, Github, Send, Instagram } from 'lucide-react';

export default function Footer() {
  return (
    <footer className="bg-[#0d0d0d] border-t border-[#1a1a1a] mt-16">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 py-12">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
          {/* Brand */}
          <div className="md:col-span-1">
            <Link href="/" className="flex items-center gap-2 mb-4">
              <div className="w-8 h-8 bg-[#e50914] rounded-lg flex items-center justify-center">
                <Play className="w-4 h-4 text-white fill-white" />
              </div>
              <span className="text-lg font-bold text-white">Cinema<span className="text-[#e50914]">Uz</span></span>
            </Link>
            <p className="text-sm text-[#888] leading-relaxed">
              Eng sara kinolar va seriallar. Yuqori sifat va qulay tomosha qilish imkoniyati.
            </p>
            <div className="flex gap-3 mt-4">
              <a href="#" className="p-2 rounded-xl bg-[#1a1a1a] text-[#888] hover:text-white hover:bg-[#2a2a2a] transition-colors">
                <Send className="w-4 h-4" />
              </a>
              <a href="#" className="p-2 rounded-xl bg-[#1a1a1a] text-[#888] hover:text-white hover:bg-[#2a2a2a] transition-colors">
                <Instagram className="w-4 h-4" />
              </a>
              <a href="#" className="p-2 rounded-xl bg-[#1a1a1a] text-[#888] hover:text-white hover:bg-[#2a2a2a] transition-colors">
                <Github className="w-4 h-4" />
              </a>
            </div>
          </div>

          {/* Navigation */}
          <div>
            <h4 className="font-semibold text-white mb-4">Sayt</h4>
            <ul className="space-y-2">
              {[
                { label: 'Bosh sahifa', href: '/' },
                { label: 'Kinolar', href: '/movies' },
                { label: 'Seriallar', href: '/series' },
                { label: 'Janrlar', href: '/genres' },
                { label: 'Chiptalar', href: '/tickets' },
              ].map((item) => (
                <li key={item.href}>
                  <Link href={item.href} className="text-sm text-[#888] hover:text-white transition-colors">
                    {item.label}
                  </Link>
                </li>
              ))}
            </ul>
          </div>

          {/* Account */}
          <div>
            <h4 className="font-semibold text-white mb-4">Hisob</h4>
            <ul className="space-y-2">
              {[
                { label: 'Profil', href: '/profile' },
                { label: 'Sevimlilar', href: '/favorites' },
                { label: 'Ko\'rish tarixi', href: '/history' },
                { label: 'Do\'stlar', href: '/friends' },
                { label: 'Obuna', href: '/subscription' },
              ].map((item) => (
                <li key={item.href}>
                  <Link href={item.href} className="text-sm text-[#888] hover:text-white transition-colors">
                    {item.label}
                  </Link>
                </li>
              ))}
            </ul>
          </div>

          {/* Legal */}
          <div>
            <h4 className="font-semibold text-white mb-4">Qonuniy</h4>
            <ul className="space-y-2">
              {['Foydalanish shartlari', 'Maxfiylik siyosati', 'Mualliflik huquqi', 'Aloqa'].map((item, i) => (
                <li key={i}>
                  <Link href="#" className="text-sm text-[#888] hover:text-white transition-colors">
                    {item}
                  </Link>
                </li>
              ))}
            </ul>
          </div>
        </div>

        <div className="border-t border-[#1a1a1a] mt-10 pt-6 flex flex-col sm:flex-row items-center justify-between gap-3">
          <p className="text-sm text-[#888]">
            © {new Date().getFullYear()} CinemaUz. Barcha huquqlar himoyalangan.
          </p>
          <p className="text-sm text-[#888]">
            Faqat litsenziyalangan kontent &bull; HLS/DASH/CDN
          </p>
        </div>
      </div>
    </footer>
  );
}
