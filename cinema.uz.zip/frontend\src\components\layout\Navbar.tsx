'use client';

import { useState, useEffect, useRef } from 'react';
import Link from 'next/link';
import { useRouter, usePathname } from 'next/navigation';
import {
  Film, Tv, Tag, Users, Search, Bell, User, LogOut,
  ChevronDown, Heart, History, Settings, Shield, Menu, X, Play,
  Sun, Moon, Ticket
} from 'lucide-react';
import { useAuthStore } from '@/store/authStore';
import { useThemeStore } from '@/store/themeStore';
import { usersAPI, moviesAPI } from '@/lib/api';
import { formatRelativeTime } from '@/lib/utils';
import toast from 'react-hot-toast';

export default function Navbar() {
  const router = useRouter();
  const pathname = usePathname();
  const { user, isAuthenticated, logout } = useAuthStore();
  const { isDark, toggleTheme } = useThemeStore();
  const [scrolled, setScrolled] = useState(false);
  const [searchOpen, setSearchOpen] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');
  const [searchResults, setSearchResults] = useState<{ movies: unknown[]; series: unknown[] }>({ movies: [], series: [] });
  const [profileOpen, setProfileOpen] = useState(false);
  const [notifOpen, setNotifOpen] = useState(false);
  const [notifications, setNotifications] = useState<unknown[]>([]);
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [unreadCount, setUnreadCount] = useState(0);
  const searchRef = useRef<HTMLDivElement>(null);
  const profileRef = useRef<HTMLDivElement>(null);
  const notifRef = useRef<HTMLDivElement>(null);
  const searchTimer = useRef<ReturnType<typeof setTimeout> | null>(null);

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 20);
    window.addEventListener('scroll', onScroll);
    return () => window.removeEventListener('scroll', onScroll);
  }, []);

  useEffect(() => {
    if (isAuthenticated) loadNotifications();
  }, [isAuthenticated]);

  useEffect(() => {
    const handleClick = (e: MouseEvent) => {
      if (searchRef.current && !searchRef.current.contains(e.target as Node)) setSearchOpen(false);
      if (profileRef.current && !profileRef.current.contains(e.target as Node)) setProfileOpen(false);
      if (notifRef.current && !notifRef.current.contains(e.target as Node)) setNotifOpen(false);
    };
    document.addEventListener('mousedown', handleClick);
    return () => document.removeEventListener('mousedown', handleClick);
  }, []);

  async function loadNotifications() {
    try {
      const res = await usersAPI.getNotifications();
      const notifs = res.data.notifications || [];
      setNotifications(notifs);
      setUnreadCount(notifs.filter((n: { is_read: boolean }) => !n.is_read).length);
    } catch {}
  }

  async function handleSearch(q: string) {
    setSearchQuery(q);
    if (searchTimer.current) clearTimeout(searchTimer.current);
    if (!q.trim()) { setSearchResults({ movies: [], series: [] }); return; }
    searchTimer.current = setTimeout(async () => {
      try {
        const res = await moviesAPI.search(q);
        setSearchResults(res.data.results || { movies: [], series: [] });
      } catch {}
    }, 300);
  }

  function handleLogout() {
    logout();
    toast.success('Chiqildi');
    router.push('/');
  }

  async function markAllRead() {
    try {
      await usersAPI.markAllRead();
      setNotifications(prev => (prev as { is_read: boolean }[]).map(n => ({ ...n, is_read: true })));
      setUnreadCount(0);
    } catch {}
  }

  const navLinks = [
    { href: '/movies', label: 'Kinolar', icon: Film },
    { href: '/series', label: 'Seriallar', icon: Tv },
    { href: '/genres', label: 'Janrlar', icon: Tag },
    { href: '/tickets', label: 'Chiptalar', icon: Ticket },
  ];

  return (
    <nav className={`fixed top-0 left-0 right-0 z-50 transition-all duration-300 ${
      scrolled ? 'backdrop-blur-md border-b' : 'bg-transparent'
    }`} style={scrolled ? { backgroundColor: 'var(--nav-bg)', borderColor: 'var(--border)' } : {}}>
      <div className="max-w-7xl mx-auto px-4 sm:px-6">
        <div className="flex items-center justify-between h-16">
          {/* Logo */}
          <Link href="/" className="flex items-center gap-2 flex-shrink-0">
            <div className="w-8 h-8 bg-[#e50914] rounded-lg flex items-center justify-center">
              <Play className="w-4 h-4 text-white fill-white" />
            </div>
            <span className="text-xl font-bold text-white">Cinema<span className="text-[#e50914]">Uz</span></span>
          </Link>

          {/* Desktop Nav Links */}
          <div className="hidden md:flex items-center gap-1">
            {navLinks.map(({ href, label, icon: Icon }) => (
              <Link
                key={href}
                href={href}
                className={`flex items-center gap-1.5 px-3 py-2 rounded-lg text-sm font-medium transition-colors ${
                  pathname?.startsWith(href)
                    ? 'text-white bg-white/10'
                    : 'text-[#888] hover:text-white hover:bg-white/5'
                }`}
              >
                <Icon className="w-4 h-4" />
                {label}
              </Link>
            ))}
          </div>

          {/* Right Side */}
          <div className="flex items-center gap-2">
            {/* Search */}
            <div ref={searchRef} className="relative">
              <button
                onClick={() => setSearchOpen(!searchOpen)}
                className="p-2 rounded-lg text-[#888] hover:text-white hover:bg-white/5 transition-colors"
              >
                <Search className="w-5 h-5" />
              </button>
              {searchOpen && (
                <div className="absolute right-0 top-12 w-80 glass-dark rounded-2xl p-3 shadow-2xl animate-slide-down">
                  <input
                    autoFocus
                    type="text"
                    value={searchQuery}
                    onChange={(e) => handleSearch(e.target.value)}
                    placeholder="Kino, aktyor, rejissyor..."
                    className="w-full bg-white/5 border border-[#2a2a2a] rounded-xl px-4 py-2.5 text-sm text-white placeholder-[#888] outline-none focus:border-[#e50914]"
                  />
                  {(searchResults.movies.length > 0 || searchResults.series.length > 0) && (
                    <div className="mt-2 max-h-72 overflow-y-auto">
                      {searchResults.movies.slice(0, 5).map((movie: unknown) => {
                        const m = movie as { id: string; poster: string; title: string; year: number; genres: string[] };
                        return (
                          <Link
                            key={m.id}
                            href={`/movies/${m.id}`}
                            onClick={() => setSearchOpen(false)}
                            className="flex items-center gap-3 p-2 rounded-xl hover:bg-white/5 transition-colors"
                          >
                            {/* eslint-disable-next-line @next/next/no-img-element */}
                            <img src={m.poster} alt={m.title} className="w-10 h-14 object-cover rounded-lg" />
                            <div>
                              <p className="text-sm font-medium text-white line-clamp-1">{m.title}</p>
                              <p className="text-xs text-[#888]">{m.year} • {m.genres?.[0]}</p>
                            </div>
                          </Link>
                        );
                      })}
                    </div>
                  )}
                  {searchQuery && searchResults.movies.length === 0 && (
                    <p className="text-center text-[#888] text-sm py-4">Natija topilmadi</p>
                  )}
                </div>
              )}
            </div>

          {/* Theme toggle */}
              <button
                onClick={toggleTheme}
                className="p-2 rounded-lg text-[var(--muted)] hover:text-[var(--text)] hover:bg-[var(--hover)] transition-colors"
                title={isDark ? "Yorug' rejim" : "Qorong'i rejim"}
              >
                {isDark ? <Sun className="w-5 h-5" /> : <Moon className="w-5 h-5" />}
              </button>

            {isAuthenticated ? (
              <>
                {/* Notifications */}
                <div ref={notifRef} className="relative">
                  <button
                    onClick={() => { setNotifOpen(!notifOpen); if (!notifOpen) loadNotifications(); }}
                    className="relative p-2 rounded-lg text-[#888] hover:text-white hover:bg-white/5 transition-colors"
                  >
                    <Bell className="w-5 h-5" />
                    {unreadCount > 0 && (
                      <span className="absolute top-1 right-1 w-4 h-4 bg-[#e50914] rounded-full text-[10px] font-bold text-white flex items-center justify-center">
                        {unreadCount > 9 ? '9+' : unreadCount}
                      </span>
                    )}
                  </button>
                  {notifOpen && (
                    <div className="absolute right-0 top-12 w-80 glass-dark rounded-2xl shadow-2xl overflow-hidden animate-slide-down">
                      <div className="flex items-center justify-between p-4 border-b border-[#2a2a2a]">
                        <h3 className="font-semibold text-white">Bildirishnomalar</h3>
                        {unreadCount > 0 && (
                          <button onClick={markAllRead} className="text-xs text-[#e50914] hover:underline">
                            Barchasini o&apos;qi
                          </button>
                        )}
                      </div>
                      <div className="max-h-80 overflow-y-auto">
                        {notifications.length === 0 ? (
                          <p className="text-center text-[#888] text-sm py-6">Bildirishnoma yo&apos;q</p>
                        ) : (
                          (notifications as { id: string; is_read: boolean; message: string; created_at: string }[]).map((n) => (
                            <div
                              key={n.id}
                              className={`p-4 border-b border-[#1a1a1a] ${!n.is_read ? 'bg-white/3' : ''}`}
                            >
                              <p className="text-sm text-[#e5e5e5]">{n.message}</p>
                              <p className="text-xs text-[#888] mt-1">{formatRelativeTime(n.created_at)}</p>
                            </div>
                          ))
                        )}
                      </div>
                    </div>
                  )}
                </div>

                {/* Profile */}
                <div ref={profileRef} className="relative">
                  <button
                    onClick={() => setProfileOpen(!profileOpen)}
                    className="flex items-center gap-2 p-1.5 rounded-xl hover:bg-white/5 transition-colors"
                  >
                    {/* eslint-disable-next-line @next/next/no-img-element */}
                    <img
                      src={user?.avatar || `https://api.dicebear.com/7.x/avataaars/svg?seed=${user?.username}`}
                      alt={user?.username}
                      className="w-8 h-8 rounded-full object-cover bg-[#2a2a2a]"
                    />
                    <ChevronDown className="w-3.5 h-3.5 text-[#888] hidden sm:block" />
                  </button>
                  {profileOpen && (
                    <div className="absolute right-0 top-12 w-56 glass-dark rounded-2xl shadow-2xl overflow-hidden animate-slide-down">
                      <div className="p-4 border-b border-[#2a2a2a]">
                        <p className="font-semibold text-white">{user?.username}</p>
                        <p className="text-xs text-[#888]">{user?.email}</p>
                      </div>
                      <div className="p-2">
                        {[
                          { href: '/profile', label: 'Profil', icon: User },
                          { href: '/favorites', label: 'Sevimlilar', icon: Heart },
                          { href: '/history', label: 'Ko\'rish tarixi', icon: History },
                          { href: '/friends', label: 'Do\'stlar', icon: Users },
                          { href: '/settings', label: 'Sozlamalar', icon: Settings },
                          ...(user?.role === 'admin' ? [{ href: '/admin', label: 'Admin panel', icon: Shield }] : []),
                        ].map(({ href, label, icon: Icon }) => (
                          <Link
                            key={href}
                            href={href}
                            onClick={() => setProfileOpen(false)}
                            className="flex items-center gap-3 px-3 py-2.5 rounded-xl text-sm text-[#e5e5e5] hover:bg-white/5 transition-colors"
                          >
                            <Icon className="w-4 h-4 text-[#888]" />
                            {label}
                          </Link>
                        ))}
                        <button
                          onClick={handleLogout}
                          className="w-full flex items-center gap-3 px-3 py-2.5 rounded-xl text-sm text-[#e50914] hover:bg-[#e50914]/10 transition-colors mt-1 border-t border-[#2a2a2a] pt-3"
                        >
                          <LogOut className="w-4 h-4" />
                          Chiqish
                        </button>
                      </div>
                    </div>
                  )}
                </div>
              </>
            ) : (
              <div className="hidden sm:flex items-center gap-2">
                <Link
                  href="/login"
                  className="px-4 py-2 text-sm font-medium text-white hover:text-[#e50914] transition-colors"
                >
                  Kirish
                </Link>
                <Link
                  href="/register"
                  className="px-4 py-2 bg-[#e50914] hover:bg-[#c0070f] text-white text-sm font-medium rounded-xl transition-colors"
                >
                  Ro&apos;yxatdan o&apos;tish
                </Link>
              </div>
            )}

            {/* Mobile menu toggle */}
            <button
              onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
              className="md:hidden p-2 rounded-lg text-[#888] hover:text-white transition-colors"
            >
              {mobileMenuOpen ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
            </button>
          </div>
        </div>

        {/* Mobile Menu */}
        {mobileMenuOpen && (
          <div className="md:hidden border-t border-[#2a2a2a] py-3 animate-slide-down">
            {navLinks.map(({ href, label, icon: Icon }) => (
              <Link
                key={href}
                href={href}
                onClick={() => setMobileMenuOpen(false)}
                className="flex items-center gap-3 px-4 py-3 text-sm text-[#e5e5e5] hover:bg-white/5 rounded-xl transition-colors"
              >
                <Icon className="w-4 h-4 text-[#888]" />
                {label}
              </Link>
            ))}
            {!isAuthenticated && (
              <div className="flex gap-2 px-4 pt-2 mt-2 border-t border-[#2a2a2a]">
                <Link href="/login" onClick={() => setMobileMenuOpen(false)}
                  className="flex-1 text-center py-2 text-sm text-white border border-[#2a2a2a] rounded-xl">
                  Kirish
                </Link>
                <Link href="/register" onClick={() => setMobileMenuOpen(false)}
                  className="flex-1 text-center py-2 text-sm text-white bg-[#e50914] rounded-xl">
                  Ro&apos;yxat
                </Link>
              </div>
            )}
          </div>
        )}
      </div>
    </nav>
  );
}
