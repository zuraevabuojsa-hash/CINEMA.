'use client';

import { useState } from 'react';
import { useRouter } from 'next/navigation';
import { X, Users, Lock, Unlock, Mic, MessageSquare, Copy, Send, Play } from 'lucide-react';
import { roomsAPI } from '@/lib/api';
import { generateRoomInviteUrl, copyToClipboard } from '@/lib/utils';
import toast from 'react-hot-toast';

interface Movie { id: string; title: string; poster: string; }

interface CreateRoomModalProps {
  movie: Movie;
  onClose: () => void;
}

export default function CreateRoomModal({ movie, onClose }: CreateRoomModalProps) {
  const router = useRouter();
  const [step, setStep] = useState<'form' | 'created'>('form');
  const [roomCode, setRoomCode] = useState('');
  const [inviteUrl, setInviteUrl] = useState('');
  const [loading, setLoading] = useState(false);

  const [roomName, setRoomName] = useState(`${movie.title} - Birga ko'rish`);
  const [isPrivate, setIsPrivate] = useState(true);
  const [maxParticipants, setMaxParticipants] = useState(2);
  const [voiceEnabled, setVoiceEnabled] = useState(true);
  const [chatEnabled, setChatEnabled] = useState(true);

  async function createRoom() {
    setLoading(true);
    try {
      const res = await roomsAPI.create({
        movie_id: movie.id,
        room_name: roomName,
        is_private: isPrivate,
        max_participants: maxParticipants,
        voice_enabled: voiceEnabled,
        chat_enabled: chatEnabled,
      });
      const { room } = res.data;
      setRoomCode(room.room_code);
      setInviteUrl(generateRoomInviteUrl(room.room_code));
      setStep('created');
      toast.success('Xona yaratildi!');
    } catch (err: unknown) {
      const error = err as { response?: { data?: { message?: string } } };
      toast.error(error.response?.data?.message || 'Xato yuz berdi');
    }
    setLoading(false);
  }

  function goToRoom() {
    router.push(`/watch/${roomCode}`);
    onClose();
  }

  async function copyInvite() {
    await copyToClipboard(inviteUrl);
    toast.success('Havola nusxalandi!');
  }

  function shareViaTelegram() {
    const url = `https://t.me/share/url?url=${encodeURIComponent(inviteUrl)}&text=${encodeURIComponent(`"${movie.title}" filmini birga ko'raylik!`)}`;
    window.open(url, '_blank');
  }

  function shareViaWhatsApp() {
    const url = `https://wa.me/?text=${encodeURIComponent(`"${movie.title}" filmini birga ko'raylik! ${inviteUrl}`)}`;
    window.open(url, '_blank');
  }

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
      <div className="absolute inset-0 bg-black/80 backdrop-blur-sm" onClick={onClose} />
      <div className="relative w-full max-w-md bg-[#1a1a1a] rounded-3xl border border-[#2a2a2a] shadow-2xl animate-slide-up overflow-hidden">
        {/* Header */}
        <div className="flex items-center justify-between p-6 border-b border-[#2a2a2a]">
          <h2 className="text-lg font-bold text-white">
            {step === 'form' ? 'Xona yaratish' : 'Xona tayyor!'}
          </h2>
          <button onClick={onClose} className="p-2 rounded-xl hover:bg-white/5 text-[#888] hover:text-white transition-colors">
            <X className="w-5 h-5" />
          </button>
        </div>

        {step === 'form' ? (
          <div className="p-6 space-y-5">
            {/* Movie Preview */}
            <div className="flex items-center gap-3 p-3 bg-[#0d0d0d] rounded-2xl border border-[#2a2a2a]">
              {/* eslint-disable-next-line @next/next/no-img-element */}
              <img src={movie.poster} alt={movie.title} className="w-12 h-16 object-cover rounded-xl" />
              <div>
                <p className="text-xs text-[#888]">Tanlangan kino</p>
                <p className="font-semibold text-white text-sm">{movie.title}</p>
              </div>
            </div>

            {/* Room Name */}
            <div>
              <label className="text-sm text-[#888] block mb-2">Xona nomi</label>
              <input
                type="text"
                value={roomName}
                onChange={(e) => setRoomName(e.target.value)}
                className="w-full bg-[#0d0d0d] border border-[#2a2a2a] rounded-2xl px-4 py-3 text-sm text-white focus:outline-none focus:border-[#e50914] transition-colors"
              />
            </div>

            {/* Privacy */}
            <div className="grid grid-cols-2 gap-3">
              {[
                { value: true, icon: Lock, label: 'Yopiq xona', desc: 'Faqat taklif orqali' },
                { value: false, icon: Unlock, label: 'Ochiq xona', desc: 'Hammaga ochiq' },
              ].map(({ value, icon: Icon, label, desc }) => (
                <button
                  key={String(value)}
                  onClick={() => setIsPrivate(value)}
                  className={`flex flex-col items-start p-4 rounded-2xl border transition-all ${
                    isPrivate === value
                      ? 'border-[#e50914] bg-[#e50914]/10'
                      : 'border-[#2a2a2a] hover:border-[#444]'
                  }`}
                >
                  <Icon className={`w-5 h-5 mb-2 ${isPrivate === value ? 'text-[#e50914]' : 'text-[#888]'}`} />
                  <p className={`text-sm font-medium ${isPrivate === value ? 'text-white' : 'text-[#888]'}`}>{label}</p>
                  <p className="text-xs text-[#666] mt-0.5">{desc}</p>
                </button>
              ))}
            </div>

            {/* Max Participants */}
            <div>
              <label className="text-sm text-[#888] block mb-2">
                Maksimal ishtirokchilar: <span className="text-white font-medium">{maxParticipants}</span>
              </label>
              <div className="flex gap-2">
                {[2, 4, 6, 10].map((n) => (
                  <button
                    key={n}
                    onClick={() => setMaxParticipants(n)}
                    className={`flex-1 py-2 rounded-xl text-sm font-medium transition-colors ${
                      maxParticipants === n
                        ? 'bg-[#e50914] text-white'
                        : 'bg-[#0d0d0d] border border-[#2a2a2a] text-[#888] hover:text-white'
                    }`}
                  >
                    {n}
                  </button>
                ))}
              </div>
            </div>

            {/* Options */}
            <div className="flex gap-3">
              {[
                { icon: Mic, label: 'Ovozli suhbat', value: voiceEnabled, set: setVoiceEnabled },
                { icon: MessageSquare, label: 'Matnli chat', value: chatEnabled, set: setChatEnabled },
              ].map(({ icon: Icon, label, value, set }) => (
                <button
                  key={label}
                  onClick={() => set(!value)}
                  className={`flex-1 flex items-center gap-2 p-3 rounded-2xl border text-sm transition-colors ${
                    value
                      ? 'border-[#e50914] bg-[#e50914]/10 text-[#e50914]'
                      : 'border-[#2a2a2a] text-[#888]'
                  }`}
                >
                  <Icon className="w-4 h-4" />
                  {label}
                </button>
              ))}
            </div>

            <button
              onClick={createRoom}
              disabled={loading || !roomName.trim()}
              className="w-full py-3.5 bg-[#e50914] hover:bg-[#c0070f] disabled:opacity-50 disabled:cursor-not-allowed text-white font-bold rounded-2xl transition-colors flex items-center justify-center gap-2"
            >
              {loading ? (
                <div className="w-5 h-5 border-2 border-white/30 border-t-white rounded-full animate-spin" />
              ) : (
                <>
                  <Users className="w-5 h-5" />
                  Xona yaratish
                </>
              )}
            </button>
          </div>
        ) : (
          <div className="p-6 space-y-5">
            {/* Success */}
            <div className="text-center">
              <div className="w-16 h-16 bg-green-500/20 rounded-full flex items-center justify-center mx-auto mb-3">
                <Users className="w-8 h-8 text-green-400" />
              </div>
              <p className="text-white font-semibold">Xona muvaffaqiyatli yaratildi!</p>
              <p className="text-[#888] text-sm mt-1">Do&apos;stingizni taklif qiling</p>
            </div>

            {/* Room Code */}
            <div className="text-center">
              <p className="text-xs text-[#888] mb-2">Xona kodi</p>
              <div className="text-3xl font-bold tracking-[0.3em] text-white bg-[#0d0d0d] rounded-2xl py-4 border border-[#2a2a2a]">
                {roomCode}
              </div>
            </div>

            {/* Invite URL */}
            <div>
              <p className="text-xs text-[#888] mb-2">Taklif havolasi</p>
              <div className="flex gap-2">
                <input
                  readOnly
                  value={inviteUrl}
                  className="flex-1 bg-[#0d0d0d] border border-[#2a2a2a] rounded-xl px-3 py-2.5 text-xs text-[#aaa] outline-none"
                />
                <button
                  onClick={copyInvite}
                  className="p-2.5 bg-[#2a2a2a] hover:bg-[#3a3a3a] text-white rounded-xl transition-colors"
                >
                  <Copy className="w-4 h-4" />
                </button>
              </div>
            </div>

            {/* Share buttons */}
            <div className="flex gap-2">
              <button
                onClick={shareViaTelegram}
                className="flex-1 flex items-center justify-center gap-2 py-2.5 bg-[#2AABEE]/20 hover:bg-[#2AABEE]/30 text-[#2AABEE] rounded-xl text-sm font-medium transition-colors border border-[#2AABEE]/30"
              >
                <Send className="w-4 h-4" />
                Telegram
              </button>
              <button
                onClick={shareViaWhatsApp}
                className="flex-1 flex items-center justify-center gap-2 py-2.5 bg-[#25D366]/20 hover:bg-[#25D366]/30 text-[#25D366] rounded-xl text-sm font-medium transition-colors border border-[#25D366]/30"
              >
                <MessageSquare className="w-4 h-4" />
                WhatsApp
              </button>
            </div>

            <button
              onClick={goToRoom}
              className="w-full py-3.5 bg-[#e50914] hover:bg-[#c0070f] text-white font-bold rounded-2xl transition-colors flex items-center justify-center gap-2"
            >
              <Play className="w-5 h-5 fill-white" />
              Xonaga kirish
            </button>
          </div>
        )}
      </div>
    </div>
  );
}
