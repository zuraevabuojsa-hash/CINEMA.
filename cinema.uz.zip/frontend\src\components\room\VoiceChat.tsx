'use client';

import { useEffect, useRef } from 'react';
import { getSocket } from '@/lib/socket';

interface Participant {
  user_id: string;
  username: string;
}

interface VoiceChatProps {
  roomCode: string;
  userId: string;
  participants: Participant[];
  micEnabled?: boolean;
}

// WebRTC konfiguratsiyasi
const RTC_CONFIG: RTCConfiguration = {
  iceServers: [
    { urls: 'stun:stun.l.google.com:19302' },
    { urls: 'stun:stun1.l.google.com:19302' },
  ],
};

export default function VoiceChat({ roomCode, userId, participants, micEnabled = false }: VoiceChatProps) {
  const localStreamRef = useRef<MediaStream | null>(null);
  const peerConnectionsRef = useRef<Map<string, RTCPeerConnection>>(new Map());
  const audioElementsRef = useRef<Map<string, HTMLAudioElement>>(new Map());

  useEffect(() => {
    initVoice();
    return () => {
      cleanup();
    };
  }, []);

  // Mikrofon holatini o'zgartirish
  useEffect(() => {
    async function updateMic() {
      if (micEnabled) {
        if (!localStreamRef.current) {
          try {
            const stream = await navigator.mediaDevices.getUserMedia({ audio: true, video: false });
            localStreamRef.current = stream;
            // Barcha ulangan peer'larga track qo'shish
            peerConnectionsRef.current.forEach((pc) => {
              stream.getTracks().forEach((track) => pc.addTrack(track, stream));
            });
          } catch (err) {
            console.warn('Mikrofon ruxsati berilmadi:', err);
          }
        } else {
          localStreamRef.current.getAudioTracks().forEach((track) => {
            track.enabled = true;
          });
        }
      } else if (localStreamRef.current) {
        localStreamRef.current.getAudioTracks().forEach((track) => {
          track.enabled = false;
        });
      }
    }
    updateMic();
  }, [micEnabled]);

  async function initVoice() {
    try {
      const socket = getSocket();

      // Boshqa ishtirokchilarga offer yuborish
      participants.forEach((p) => {
        if (p.user_id !== userId) {
          createPeerConnection(p.user_id, true);
        }
      });

      // WebRTC signal hodisalari
      socket.on('webrtc_offer', async ({ offer, from_id }: { offer: RTCSessionDescriptionInit; from_id: string }) => {
        if (from_id === userId) return;
        const pc = createPeerConnection(from_id, false);
        await pc.setRemoteDescription(new RTCSessionDescription(offer));
        const answer = await pc.createAnswer();
        await pc.setLocalDescription(answer);
        socket.emit('webrtc_answer', { room_code: roomCode, answer, target_id: from_id });
      });

      socket.on('webrtc_answer', async ({ answer, from_id }: { answer: RTCSessionDescriptionInit; from_id: string }) => {
        const pc = peerConnectionsRef.current.get(from_id);
        if (pc && pc.signalingState !== 'stable') {
          await pc.setRemoteDescription(new RTCSessionDescription(answer));
        }
      });

      socket.on('webrtc_ice_candidate', async ({ candidate, from_id }: { candidate: RTCIceCandidateInit; from_id: string }) => {
        const pc = peerConnectionsRef.current.get(from_id);
        if (pc && candidate) {
          try {
            await pc.addIceCandidate(new RTCIceCandidate(candidate));
          } catch (e) {
            console.warn('ICE candidate xatosi:', e);
          }
        }
      });
    } catch (err) {
      console.error('Voice chat error:', err);
    }
  }

  function createPeerConnection(targetId: string, initiator: boolean): RTCPeerConnection {
    const existing = peerConnectionsRef.current.get(targetId);
    if (existing && existing.signalingState !== 'closed') return existing;

    const pc = new RTCPeerConnection(RTC_CONFIG);
    peerConnectionsRef.current.set(targetId, pc);

    // Agar localStream bo'lsa uni qo'shish
    if (localStreamRef.current) {
      localStreamRef.current.getTracks().forEach((track) => {
        pc.addTrack(track, localStreamRef.current!);
      });
    }

    // Remote audio olish
    pc.ontrack = (event) => {
      let audio = audioElementsRef.current.get(targetId);
      if (!audio) {
        audio = new Audio();
        audio.autoplay = true;
        audioElementsRef.current.set(targetId, audio);
      }
      audio.srcObject = event.streams[0];
      audio.play().catch(() => {});
    };

    // ICE candidate yuborish
    pc.onicecandidate = (event) => {
      if (event.candidate) {
        getSocket().emit('webrtc_ice_candidate', {
          room_code: roomCode,
          candidate: event.candidate,
        });
      }
    };

    pc.onconnectionstatechange = () => {
      console.log(`[WebRTC] ${targetId}: ${pc.connectionState}`);
    };

    // Initiator bo'lsa offer yaratish
    if (initiator) {
      pc.createOffer({ offerToReceiveAudio: true }).then(async (offer) => {
        await pc.setLocalDescription(offer);
        getSocket().emit('webrtc_offer', {
          room_code: roomCode,
          offer,
          target_id: targetId,
        });
      });
    }

    return pc;
  }

  function cleanup() {
    localStreamRef.current?.getTracks().forEach((t) => t.stop());
    peerConnectionsRef.current.forEach((pc) => pc.close());
    peerConnectionsRef.current.clear();
    audioElementsRef.current.forEach((audio) => {
      audio.srcObject = null;
    });
    audioElementsRef.current.clear();

    const socket = getSocket();
    socket.off('webrtc_offer');
    socket.off('webrtc_answer');
    socket.off('webrtc_ice_candidate');
  }

  return null;
}
