'use client';

import { useState, useEffect } from 'react';
import {
  X, Ticket, Calendar, Clock, MapPin, CreditCard,
  CheckCircle2, Download, Printer, ChevronRight,
  ChevronLeft, User, Phone, Sparkles, AlertCircle,
  Smartphone, ShieldCheck, ExternalLink, Lock, QrCode, ArrowRight, Check
} from 'lucide-react';
import { ticketsAPI } from '@/lib/api';
import { useAuthStore } from '@/store/authStore';
import toast from 'react-hot-toast';

interface Movie {
  id: string;
  title: string;
  poster: string;
  duration?: number;
  year?: number;
}

interface Cinema {
  id: string;
  name: string;
  address: string;
  halls: string[];
}

interface Session {
  id: string;
  cinema_id: string;
  cinema_name: string;
  cinema_address: string;
  movie_id: string;
  date: string;
  time: string;
  format: string;
  price: number;
  hall: string;
}

interface Seat {
  id: string;
  row: string;
  number: number;
  type: 'standard' | 'vip';
  status: 'available' | 'occupied';
}

interface SeatRow {
  row: string;
  seats: Seat[];
}

interface TicketBookingModalProps {
  movie: Movie;
  onClose: () => void;
}

export default function TicketBookingModal({ movie, onClose }: TicketBookingModalProps) {
  const { user } = useAuthStore();

  const [step, setStep] = useState<'session' | 'seats' | 'payment' | 'success'>('session');
  const [cinemas, setCinemas] = useState<Cinema[]>([]);
  const [selectedCinema, setSelectedCinema] = useState<string>('c1');
  const [sessions, setSessions] = useState<Session[]>([]);
  const [selectedDate, setSelectedDate] = useState<string>('');
  const [selectedSession, setSelectedSession] = useState<Session | null>(null);

  // Seat state
  const [seatLayout, setSeatLayout] = useState<SeatRow[]>([]);
  const [selectedSeats, setSelectedSeats] = useState<string[]>([]);
  const [loadingSeats, setLoadingSeats] = useState<boolean>(false);

  // Payment state - Faqat Click orqali to'liq to'lov
  const [paymentMethod, setPaymentMethod] = useState<'click'>('click');
  const [clickTab, setClickTab] = useState<'card' | 'app'>('card');
  const [cardNumber, setCardNumber] = useState('');
  const [cardExpiry, setCardExpiry] = useState('');
  const [smsStep, setSmsStep] = useState(false);
  const [smsCode, setSmsCode] = useState('');
  const [smsTimer, setSmsTimer] = useState(60);
  const [buyerName, setBuyerName] = useState(user?.username || '');
  const [buyerPhone, setBuyerPhone] = useState('+998 ');
  const [isBooking, setIsBooking] = useState(false);
  const [bookedTicket, setBookedTicket] = useState<any>(null);

  // Load Cinemas & Dates
  useEffect(() => {
    async function init() {
      try {
        const res = await ticketsAPI.getCinemas();
        setCinemas(res.data.cinemas || []);
        if (res.data.cinemas?.length > 0) {
          setSelectedCinema(res.data.cinemas[0].id);
        }

        // Today's date
        const today = new Date().toISOString().split('T')[0];
        setSelectedDate(today);
      } catch (e) {
        console.error(e);
      }
    }
    init();
  }, []);

  // Load Sessions when Cinema or Date changes
  useEffect(() => {
    async function loadSessions() {
      if (!selectedCinema || !selectedDate) return;
      try {
        const res = await ticketsAPI.getSessions({
          movie_id: movie.id,
          cinema_id: selectedCinema,
          date: selectedDate,
        });
        setSessions(res.data.sessions || []);
      } catch (e) {
        console.error(e);
      }
    }
    loadSessions();
  }, [selectedCinema, selectedDate, movie.id]);

  // Load Seat Layout when session selected
  async function handleSelectSession(session: Session) {
    setSelectedSession(session);
    setSelectedSeats([]);
    setLoadingSeats(true);
    setStep('seats');

    try {
      const res = await ticketsAPI.getSessionDetails(session.id);
      setSeatLayout(res.data.layout || []);
    } catch {
      toast.error('Zal ma\'lumotlarini yuklab bo\'lmadi');
    }
    setLoadingSeats(false);
  }

  // Toggle Seat Selection
  function toggleSeat(seat: Seat) {
    if (seat.status === 'occupied') return;

    if (selectedSeats.includes(seat.id)) {
      setSelectedSeats(prev => prev.filter(s => s !== seat.id));
    } else {
      if (selectedSeats.length >= 6) {
        toast.error('Bir vaqtda eng ko\'pi bilan 6 ta o\'rindiq tanlash mumkin');
        return;
      }
      setSelectedSeats(prev => [...prev, seat.id]);
    }
  }

  // Calculate Total Price
  const basePrice = selectedSession?.price || 45000;
  const totalPrice = selectedSeats.reduce((acc, seatId) => {
    // Check if row G (VIP)
    const isVip = seatId.startsWith('G');
    const seatPrice = isVip ? basePrice + 20000 : basePrice;
    return acc + seatPrice;
  }, 0);

  // SMS timer countdown
  useEffect(() => {
    let timer: any;
    if (smsStep && smsTimer > 0) {
      timer = setInterval(() => {
        setSmsTimer(prev => prev - 1);
      }, 1000);
    }
    return () => clearInterval(timer);
  }, [smsStep, smsTimer]);

  // Format Card Number (adds spaces every 4 digits)
  function handleCardNumberChange(e: React.ChangeEvent<HTMLInputElement>) {
    const raw = e.target.value.replace(/\D/g, '').slice(0, 16);
    const formatted = raw.replace(/(\d{4})(?=\d)/g, '$1 ');
    setCardNumber(formatted);
  }

  // Format Expiry (MM/YY)
  function handleCardExpiryChange(e: React.ChangeEvent<HTMLInputElement>) {
    let raw = e.target.value.replace(/\D/g, '').slice(0, 4);
    if (raw.length >= 2) {
      raw = raw.slice(0, 2) + '/' + raw.slice(2);
    }
    setCardExpiry(raw);
  }

  function getCardBrand(num: string) {
    const clean = num.replace(/\s/g, '');
    if (clean.startsWith('8600')) return { name: 'UZCARD', color: 'bg-blue-600' };
    if (clean.startsWith('9860')) return { name: 'HUMO', color: 'bg-amber-600' };
    if (clean.startsWith('4')) return { name: 'VISA', color: 'bg-sky-600' };
    if (clean.startsWith('5')) return { name: 'Mastercard', color: 'bg-red-600' };
    return { name: 'UZCARD / HUMO', color: 'bg-[#0073ff]' };
  }

  // Click URL & USSD
  const clickPayUrl = `https://my.click.uz/services/pay?service_id=32598&merchant_id=24151&amount=${totalPrice}&transaction_param=CINEMA-${Date.now().toString().slice(-6)}`;
  const ussdCode = `*880*32598*${totalPrice}#`;

  // Start Click Payment flow
  async function handleStartClickPayment() {
    if (!buyerName.trim()) {
      toast.error('Iltimos, ismingizni kiriting');
      return;
    }
    if (buyerPhone.trim().length < 9) {
      toast.error('Telefon raqamingizni kiriting');
      return;
    }

    if (clickTab === 'card') {
      const cleanCard = cardNumber.replace(/\s/g, '');
      if (cleanCard.length < 16) {
        toast.error('16 xonali karta raqamini to\'liq kiriting');
        return;
      }
      if (cardExpiry.length < 5) {
        toast.error('Kartaning amal qilish muddatini kiriting (masalan: 12/28)');
        return;
      }

      if (!smsStep) {
        // Send SMS code
        setSmsStep(true);
        setSmsTimer(60);
        toast.success(`Click SMS: Tasdiqlash kodi ${buyerPhone} ga yuborildi!`);
        return;
      }

      // If in SMS step, check code
      if (!smsCode || smsCode.length < 4) {
        toast.error('SMS tasdiqlash kodini kiriting (Test kodi: 77777)');
        return;
      }
    }

    // Execute booking with Click
    await handleConfirmBooking();
  }

  // Submit Booking
  async function handleConfirmBooking() {
    if (!buyerName.trim()) {
      toast.error('Iltimos, ismingizni kiriting');
      return;
    }
    if (buyerPhone.trim().length < 9) {
      toast.error('Telefon raqamingizni kiriting');
      return;
    }

    setIsBooking(true);
    try {
      const res = await ticketsAPI.bookTicket({
        movie_id: movie.id,
        movie_title: movie.title,
        movie_poster: movie.poster,
        cinema_id: selectedSession?.cinema_id,
        cinema_name: selectedSession?.cinema_name,
        cinema_address: selectedSession?.cinema_address,
        session_id: selectedSession?.id,
        date: selectedSession?.date,
        time: selectedSession?.time,
        hall: selectedSession?.hall,
        format: selectedSession?.format,
        seats: selectedSeats,
        total_price: totalPrice,
        payment_method: 'CLICK',
        card_pan: cardNumber ? cardNumber.slice(-4) : '',
        buyer_name: buyerName,
        buyer_phone: buyerPhone,
      });

      setBookedTicket(res.data.ticket);
      setStep('success');
      toast.success('To\'lov Click orqali muvaffaqiyatli amalga oshirildi!');
    } catch (err: any) {
      toast.error(err.response?.data?.message || 'Xatolik yuz berdi');
    }
    setIsBooking(false);
  }

  // Print Ticket
  function handlePrint() {
    window.print();
  }

  // 4 dates: Bugun, Ertaga, Indinga, 4-kun
  const datesList = [];
  const today = new Date();
  for (let i = 0; i < 4; i++) {
    const d = new Date(today);
    d.setDate(today.getDate() + i);
    const dateStr = d.toISOString().split('T')[0];
    const labels = ['Bugun', 'Ertaga', 'Indinga', 'Keyingi kun'];
    const daysUz = ['Yak', 'Dush', 'Sesh', 'Chor', 'Pay', 'Jum', 'Shan'];
    datesList.push({
      date: dateStr,
      dayNumber: d.getDate(),
      dayName: daysUz[d.getDay()],
      label: labels[i],
    });
  }

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 overflow-y-auto bg-black/80 backdrop-blur-md">
      <div className="relative w-full max-w-4xl bg-[#14141f] border border-[#2a2a44] rounded-3xl shadow-2xl overflow-hidden my-auto max-h-[92vh] flex flex-col">

        {/* Modal Top Header */}
        <div className="flex items-center justify-between px-6 py-4 bg-[#1a1a2e] border-b border-[#2a2a44] flex-shrink-0">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-gradient-to-tr from-amber-500 to-orange-500 flex items-center justify-center shadow-lg shadow-orange-500/20">
              <Ticket className="w-5 h-5 text-white" />
            </div>
            <div>
              <h2 className="text-lg font-bold text-white flex items-center gap-2">
                Kino chiptalari
                <span className="text-xs px-2 py-0.5 rounded-full bg-orange-500/10 text-orange-400 border border-orange-500/20 font-medium">
                  Online xarid
                </span>
              </h2>
              <p className="text-xs text-[#888] truncate max-w-sm sm:max-w-md">
                {movie.title}
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-2 rounded-xl text-[#888] hover:text-white hover:bg-white/5 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Stepper Bar */}
        <div className="flex items-center justify-around px-6 py-2.5 bg-[#0e0e17] border-b border-[#222238] text-xs font-medium">
          <button
            onClick={() => setStep('session')}
            className={`flex items-center gap-1.5 transition-colors ${
              step === 'session' ? 'text-orange-400 font-bold' : 'text-[#888]'
            }`}
          >
            <span className="w-5 h-5 rounded-full bg-orange-500/20 text-orange-400 flex items-center justify-center text-[10px]">1</span>
            Seans tanlash
          </button>
          <ChevronRight className="w-3.5 h-3.5 text-[#444]" />
          <button
            onClick={() => selectedSession && setStep('seats')}
            disabled={!selectedSession}
            className={`flex items-center gap-1.5 transition-colors ${
              step === 'seats' ? 'text-orange-400 font-bold' : 'text-[#888] disabled:opacity-40'
            }`}
          >
            <span className="w-5 h-5 rounded-full bg-orange-500/20 text-orange-400 flex items-center justify-center text-[10px]">2</span>
            O&apos;rindiqlar
          </button>
          <ChevronRight className="w-3.5 h-3.5 text-[#444]" />
          <button
            disabled={selectedSeats.length === 0}
            className={`flex items-center gap-1.5 transition-colors ${
              step === 'payment' ? 'text-orange-400 font-bold' : 'text-[#888] disabled:opacity-40'
            }`}
          >
            <span className="w-5 h-5 rounded-full bg-orange-500/20 text-orange-400 flex items-center justify-center text-[10px]">3</span>
            To&apos;lov
          </button>
          <ChevronRight className="w-3.5 h-3.5 text-[#444]" />
          <span className={`flex items-center gap-1.5 ${step === 'success' ? 'text-green-400 font-bold' : 'text-[#555]'}`}>
            <span className="w-5 h-5 rounded-full bg-green-500/20 text-green-400 flex items-center justify-center text-[10px]">✓</span>
            Chipta
          </span>
        </div>

        {/* Modal Body Content */}
        <div className="flex-1 overflow-y-auto p-4 sm:p-6 space-y-6">

          {/* STEP 1: SELECT CINEMA, DATE & SESSION */}
          {step === 'session' && (
            <div className="space-y-6 animate-fadeIn">
              {/* Movie mini card */}
              <div className="flex items-center gap-4 p-4 rounded-2xl bg-[#1b1b2a] border border-[#2a2a44]">
                {/* eslint-disable-next-line @next/next/no-img-element */}
                <img src={movie.poster} alt={movie.title} className="w-16 h-24 object-cover rounded-xl shadow-md" />
                <div className="space-y-1">
                  <h3 className="text-base font-bold text-white">{movie.title}</h3>
                  <p className="text-xs text-[#888] flex items-center gap-2">
                    <span>{movie.year || 2024} yil</span>
                    <span>•</span>
                    <span>{movie.duration || 120} daqiqa</span>
                    <span>•</span>
                    <span className="text-amber-400 font-medium">Kinoteatrlarda premyera</span>
                  </p>
                  <p className="text-xs text-orange-400/90 font-medium pt-1">
                    Kinoteatr va sizga qulay seans vaqtini tanlang:
                  </p>
                </div>
              </div>

              {/* 1. Date Selector */}
              <div>
                <label className="text-xs font-semibold text-[#aaa] uppercase tracking-wider block mb-2.5">
                  1. Sanani tanlang
                </label>
                <div className="grid grid-cols-4 gap-2 sm:gap-3">
                  {datesList.map(d => {
                    const active = selectedDate === d.date;
                    return (
                      <button
                        key={d.date}
                        onClick={() => setSelectedDate(d.date)}
                        className={`flex flex-col items-center justify-center py-3 px-2 rounded-2xl border transition-all ${
                          active
                            ? 'bg-gradient-to-b from-orange-500 to-amber-600 border-orange-400 text-white shadow-lg shadow-orange-500/30'
                            : 'bg-[#1a1a2e] border-[#2a2a44] text-[#888] hover:text-white hover:border-[#444]'
                        }`}
                      >
                        <span className="text-[10px] uppercase font-bold tracking-wider opacity-80">{d.label}</span>
                        <span className="text-lg font-black my-0.5">{d.dayNumber}</span>
                        <span className="text-[10px] font-medium">{d.dayName}</span>
                      </button>
                    );
                  })}
                </div>
              </div>

              {/* 2. Cinema Selector */}
              <div>
                <label className="text-xs font-semibold text-[#aaa] uppercase tracking-wider block mb-2.5">
                  2. Kinoteatrni tanlang
                </label>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
                  {cinemas.map(c => {
                    const active = selectedCinema === c.id;
                    return (
                      <div
                        key={c.id}
                        onClick={() => setSelectedCinema(c.id)}
                        className={`cursor-pointer p-3.5 rounded-2xl border transition-all flex items-start gap-3 ${
                          active
                            ? 'bg-orange-500/10 border-orange-500/50 text-white shadow-md'
                            : 'bg-[#1a1a2e] border-[#2a2a44] text-[#888] hover:text-white hover:border-[#3a3a55]'
                        }`}
                      >
                        <div className={`p-2 rounded-xl mt-0.5 ${active ? 'bg-orange-500 text-white' : 'bg-[#252538] text-[#888]'}`}>
                          <MapPin className="w-4 h-4" />
                        </div>
                        <div className="min-w-0 flex-1">
                          <p className={`font-bold text-sm ${active ? 'text-white' : 'text-[#ddd]'}`}>{c.name}</p>
                          <p className="text-xs text-[#777] truncate">{c.address}</p>
                        </div>
                      </div>
                    );
                  })}
                </div>
              </div>

              {/* 3. Showtimes */}
              <div>
                <label className="text-xs font-semibold text-[#aaa] uppercase tracking-wider block mb-2.5">
                  3. Seans vaqtini tanlang
                </label>
                {sessions.length === 0 ? (
                  <div className="p-8 text-center text-[#888] bg-[#1a1a2e] rounded-2xl border border-[#2a2a44]">
                    Bu kunda seanslar topilmadi. Boshqa sanani tanlang.
                  </div>
                ) : (
                  <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-6 gap-2.5">
                    {sessions.map(s => (
                      <button
                        key={s.id}
                        onClick={() => handleSelectSession(s)}
                        className="group p-3 rounded-2xl bg-[#1b1b2a] border border-[#2a2a44] hover:border-orange-500 hover:bg-orange-500/10 transition-all text-center flex flex-col items-center"
                      >
                        <span className="text-base font-black text-white group-hover:text-orange-400 transition-colors">
                          {s.time}
                        </span>
                        <span className="text-[10px] px-2 py-0.5 rounded-md bg-white/5 text-[#aaa] my-1 border border-white/5">
                          {s.format}
                        </span>
                        <span className="text-xs font-semibold text-amber-400">
                          {s.price.toLocaleString()} so&apos;m
                        </span>
                        <span className="text-[10px] text-[#666] truncate max-w-full">
                          {s.hall}
                        </span>
                      </button>
                    ))}
                  </div>
                )}
              </div>
            </div>
          )}

          {/* STEP 2: SELECT SEATS */}
          {step === 'seats' && selectedSession && (
            <div className="space-y-6 animate-fadeIn">
              {/* Session summary bar */}
              <div className="flex flex-wrap items-center justify-between gap-3 p-3.5 bg-[#1b1b2a] border border-[#2a2a44] rounded-2xl">
                <div>
                  <p className="text-sm font-bold text-white">{selectedSession.cinema_name}</p>
                  <p className="text-xs text-[#888]">
                    {selectedSession.date} • {selectedSession.time} • {selectedSession.hall} ({selectedSession.format})
                  </p>
                </div>
                <button
                  onClick={() => setStep('session')}
                  className="px-3 py-1.5 text-xs text-orange-400 bg-orange-500/10 hover:bg-orange-500/20 border border-orange-500/30 rounded-xl transition-colors font-medium flex items-center gap-1"
                >
                  <ChevronLeft className="w-3.5 h-3.5" />
                  Seansni o&apos;zgartirish
                </button>
              </div>

              {/* Cinema Hall / Screen view */}
              <div className="p-4 sm:p-6 bg-[#0c0c14] border border-[#222238] rounded-3xl flex flex-col items-center">
                {/* Visual Screen */}
                <div className="w-full max-w-lg mb-8 text-center">
                  <div className="h-2 bg-gradient-to-r from-transparent via-orange-500 to-transparent rounded-full shadow-lg shadow-orange-500/50 mb-2" />
                  <p className="text-[11px] uppercase tracking-widest text-[#777] font-bold">EKRAN (SCREEN)</p>
                </div>

                {loadingSeats ? (
                  <div className="py-16 text-center text-[#888]">
                    <div className="w-8 h-8 border-2 border-orange-500 border-t-transparent rounded-full animate-spin mx-auto mb-3" />
                    Zal xaritasi yuklanmoqda...
                  </div>
                ) : (
                  <div className="w-full overflow-x-auto pb-4 flex justify-center">
                    <div className="space-y-2 min-w-[360px]">
                      {seatLayout.map(rowGroup => (
                        <div key={rowGroup.row} className="flex items-center gap-2 justify-center">
                          <span className="w-4 text-xs font-bold text-[#666] text-center font-mono">
                            {rowGroup.row}
                          </span>
                          <div className="flex gap-1.5 sm:gap-2">
                            {rowGroup.seats.map(seat => {
                              const isSelected = selectedSeats.includes(seat.id);
                              const isOccupied = seat.status === 'occupied';
                              const isVip = seat.type === 'vip';

                              return (
                                <button
                                  key={seat.id}
                                  disabled={isOccupied}
                                  onClick={() => toggleSeat(seat)}
                                  title={`${seat.id} (${isOccupied ? 'Band' : isVip ? 'VIP' : 'Standart'})`}
                                  className={`w-6 h-6 sm:w-7 sm:h-7 rounded-lg text-[10px] font-mono font-bold flex items-center justify-center transition-all ${
                                    isOccupied
                                      ? 'bg-[#222230] text-[#555] cursor-not-allowed opacity-50'
                                      : isSelected
                                      ? 'bg-gradient-to-tr from-orange-500 to-amber-500 text-white scale-110 shadow-md shadow-orange-500/50 ring-2 ring-white/30'
                                      : isVip
                                      ? 'bg-amber-500/20 text-amber-300 border border-amber-500/40 hover:bg-amber-500/40 hover:scale-105'
                                      : 'bg-[#1e1e2f] text-[#bbb] hover:bg-[#2e2e46] hover:text-white hover:scale-105 border border-[#303048]'
                                  }`}
                                >
                                  {seat.number}
                                </button>
                              );
                            })}
                          </div>
                          <span className="w-4 text-xs font-bold text-[#666] text-center font-mono">
                            {rowGroup.row}
                          </span>
                        </div>
                      ))}
                    </div>
                  </div>
                )}

                {/* Legend */}
                <div className="flex flex-wrap items-center justify-center gap-4 mt-6 pt-4 border-t border-[#1c1c2b] text-xs text-[#888]">
                  <div className="flex items-center gap-1.5">
                    <span className="w-4 h-4 rounded-md bg-[#1e1e2f] border border-[#303048]" />
                    <span>Bo&apos;sh (45 000 so&apos;m)</span>
                  </div>
                  <div className="flex items-center gap-1.5">
                    <span className="w-4 h-4 rounded-md bg-amber-500/20 border border-amber-500/40" />
                    <span>VIP (65 000 so&apos;m)</span>
                  </div>
                  <div className="flex items-center gap-1.5">
                    <span className="w-4 h-4 rounded-md bg-orange-500 shadow-sm" />
                    <span className="text-white font-medium">Tanlangan</span>
                  </div>
                  <div className="flex items-center gap-1.5">
                    <span className="w-4 h-4 rounded-md bg-[#222230] opacity-50" />
                    <span>Band qilingan</span>
                  </div>
                </div>
              </div>

              {/* Bottom selection bar */}
              <div className="p-4 bg-[#1b1b2a] border border-[#2a2a44] rounded-2xl flex flex-col sm:flex-row items-center justify-between gap-4">
                <div>
                  <p className="text-xs text-[#888]">Tanlangan o&apos;rindiqlar:</p>
                  <p className="text-sm font-bold text-white">
                    {selectedSeats.length > 0 ? selectedSeats.join(', ') : 'Hali tanlanmadi'}
                  </p>
                </div>
                <div className="flex items-center gap-4 w-full sm:w-auto justify-between sm:justify-end">
                  <div className="text-right">
                    <p className="text-xs text-[#888]">Jami summa:</p>
                    <p className="text-lg font-black text-amber-400">
                      {totalPrice.toLocaleString()} so&apos;m
                    </p>
                  </div>
                  <button
                    disabled={selectedSeats.length === 0}
                    onClick={() => setStep('payment')}
                    className="px-6 py-3 bg-gradient-to-r from-orange-500 to-amber-600 hover:from-orange-600 hover:to-amber-700 disabled:opacity-40 disabled:cursor-not-allowed text-white font-bold rounded-2xl transition-all shadow-lg shadow-orange-500/20 flex items-center gap-2"
                  >
                    Davom etish
                    <ChevronRight className="w-4 h-4" />
                  </button>
                </div>
              </div>
            </div>
          )}

          {/* STEP 3: PAYMENT & USER DETAILS */}
          {step === 'payment' && selectedSession && (
            <div className="space-y-6 animate-fadeIn max-w-xl mx-auto">
              {/* Order Recap */}
              <div className="p-4 bg-[#1b1b2a] border border-[#2a2a44] rounded-2xl space-y-2">
                <h4 className="text-xs font-bold uppercase tracking-wider text-orange-400">Buyurtma tafsilotlari</h4>
                <div className="flex justify-between text-sm py-1 border-b border-white/5">
                  <span className="text-[#888]">Film:</span>
                  <span className="font-bold text-white">{movie.title}</span>
                </div>
                <div className="flex justify-between text-sm py-1 border-b border-white/5">
                  <span className="text-[#888]">Kinoteatr:</span>
                  <span className="text-white">{selectedSession.cinema_name} ({selectedSession.hall})</span>
                </div>
                <div className="flex justify-between text-sm py-1 border-b border-white/5">
                  <span className="text-[#888]">Sana va vaqt:</span>
                  <span className="text-white">{selectedSession.date} soat {selectedSession.time}</span>
                </div>
                <div className="flex justify-between text-sm py-1 border-b border-white/5">
                  <span className="text-[#888]">O&apos;rindiqlar ({selectedSeats.length} ta):</span>
                  <span className="font-bold text-amber-400">{selectedSeats.join(', ')}</span>
                </div>
                <div className="flex justify-between text-base py-2 font-black text-white">
                  <span>To&apos;lov summasi:</span>
                  <span className="text-amber-400">{totalPrice.toLocaleString()} so&apos;m</span>
                </div>
              </div>

              {/* Buyer info form */}
              <div className="space-y-3">
                <label className="text-xs font-semibold text-[#aaa] uppercase tracking-wider block">
                  Aloqa ma&apos;lumotlari
                </label>
                <div>
                  <div className="relative">
                    <User className="absolute left-3.5 top-1/2 -translate-y-1/2 w-4 h-4 text-[#888]" />
                    <input
                      type="text"
                      value={buyerName}
                      onChange={e => setBuyerName(e.target.value)}
                      placeholder="Ism va familiyangiz"
                      className="w-full pl-10 pr-4 py-3 bg-[#1a1a2e] border border-[#2a2a44] rounded-2xl text-white placeholder-[#555] text-sm focus:outline-none focus:border-orange-500"
                    />
                  </div>
                </div>
                <div>
                  <div className="relative">
                    <Phone className="absolute left-3.5 top-1/2 -translate-y-1/2 w-4 h-4 text-[#888]" />
                    <input
                      type="text"
                      value={buyerPhone}
                      onChange={e => setBuyerPhone(e.target.value)}
                      placeholder="+998 90 123 45 67"
                      className="w-full pl-10 pr-4 py-3 bg-[#1a1a2e] border border-[#2a2a44] rounded-2xl text-white placeholder-[#555] text-sm focus:outline-none focus:border-orange-500"
                    />
                  </div>
                  <p className="text-[11px] text-[#666] mt-1 pl-1">
                    Elektron chipta va QR-kod ushbu raqamga va ekranda taqdim etiladi.
                  </p>
                </div>
              </div>

              {/* Click Payment System */}
              <div className="bg-[#151525] border-2 border-[#0073ff]/40 rounded-3xl p-5 space-y-4 shadow-xl relative overflow-hidden">
                {/* Background glow */}
                <div className="absolute top-0 right-0 w-40 h-40 bg-[#0073ff]/10 rounded-full blur-3xl pointer-events-none" />

                {/* Click Header */}
                <div className="flex items-center justify-between border-b border-[#252540] pb-3">
                  <div className="flex items-center gap-3">
                    <div className="px-3 py-1.5 rounded-xl bg-[#0073ff] text-white font-black text-sm tracking-wider shadow-md shadow-[#0073ff]/30">
                      CLICK
                    </div>
                    <div>
                      <h4 className="text-sm font-bold text-white flex items-center gap-1.5">
                        Click orqali to&apos;lov
                        <ShieldCheck className="w-4 h-4 text-emerald-400" />
                      </h4>
                      <p className="text-[11px] text-[#888]">100% xavfsiz va tezkor to&apos;lov tizimi</p>
                    </div>
                  </div>
                  <span className="text-xs px-2.5 py-1 rounded-full bg-emerald-500/10 text-emerald-400 border border-emerald-500/20 font-semibold">
                    0% komissiya
                  </span>
                </div>

                {/* Click sub-tabs */}
                <div className="flex gap-2 p-1 bg-[#10101c] rounded-xl border border-[#202035]">
                  <button
                    type="button"
                    onClick={() => { setClickTab('card'); setSmsStep(false); }}
                    className={`flex-1 py-2 text-xs font-bold rounded-lg transition-all flex items-center justify-center gap-2 ${
                      clickTab === 'card'
                        ? 'bg-[#0073ff] text-white shadow-md'
                        : 'text-[#888] hover:text-white'
                    }`}
                  >
                    <CreditCard className="w-3.5 h-3.5" />
                    Karta orqali (Uzcard / Humo)
                  </button>
                  <button
                    type="button"
                    onClick={() => { setClickTab('app'); setSmsStep(false); }}
                    className={`flex-1 py-2 text-xs font-bold rounded-lg transition-all flex items-center justify-center gap-2 ${
                      clickTab === 'app'
                        ? 'bg-[#0073ff] text-white shadow-md'
                        : 'text-[#888] hover:text-white'
                    }`}
                  >
                    <Smartphone className="w-3.5 h-3.5" />
                    Click ilovasi / USSD
                  </button>
                </div>

                {/* TAB 1: KARTA ORQALI */}
                {clickTab === 'card' && (
                  <div className="space-y-3.5 pt-1">
                    {!smsStep ? (
                      <>
                        <div>
                          <div className="flex justify-between items-center mb-1.5">
                            <label className="text-xs text-[#aaa] font-medium">Karta raqami</label>
                            <span className={`text-[10px] font-bold px-2 py-0.5 rounded text-white ${getCardBrand(cardNumber).color}`}>
                              {getCardBrand(cardNumber).name}
                            </span>
                          </div>
                          <div className="relative">
                            <CreditCard className="absolute left-3.5 top-1/2 -translate-y-1/2 w-4 h-4 text-[#888]" />
                            <input
                              type="text"
                              value={cardNumber}
                              onChange={handleCardNumberChange}
                              placeholder="8600 0000 0000 0000"
                              maxLength={19}
                              className="w-full pl-10 pr-4 py-3 bg-[#10101c] border border-[#252540] rounded-xl text-white font-mono placeholder-[#444] text-sm focus:outline-none focus:border-[#0073ff] tracking-wider"
                            />
                          </div>
                        </div>

                        <div className="grid grid-cols-2 gap-3">
                          <div>
                            <label className="text-xs text-[#aaa] font-medium block mb-1.5">Amal qilish muddati</label>
                            <input
                              type="text"
                              value={cardExpiry}
                              onChange={handleCardExpiryChange}
                              placeholder="MM/YY"
                              maxLength={5}
                              className="w-full px-3.5 py-3 bg-[#10101c] border border-[#252540] rounded-xl text-white font-mono text-center placeholder-[#444] text-sm focus:outline-none focus:border-[#0073ff] tracking-wider"
                            />
                          </div>
                          <div>
                            <label className="text-xs text-[#aaa] font-medium block mb-1.5">To&apos;lov miqdori</label>
                            <div className="py-3 px-3.5 bg-[#10101c] border border-[#252540] rounded-xl text-amber-400 font-black text-sm text-center">
                              {totalPrice.toLocaleString()} so&apos;m
                            </div>
                          </div>
                        </div>

                        <div className="p-2.5 rounded-xl bg-[#0073ff]/10 border border-[#0073ff]/20 text-[11px] text-[#9bbef5] flex items-center gap-2">
                          <Lock className="w-4 h-4 text-[#0073ff] flex-shrink-0" />
                          <span>To&apos;lov Click xavfsiz shifrlangan shlyuzi orqali amalga oshiriladi.</span>
                        </div>
                      </>
                    ) : (
                      /* SMS Verification Step */
                      <div className="p-4 bg-[#10101c] rounded-2xl border border-[#0073ff]/40 space-y-3">
                        <div className="text-center space-y-1">
                          <div className="w-10 h-10 rounded-xl bg-[#0073ff]/20 text-[#0073ff] flex items-center justify-center mx-auto">
                            <Smartphone className="w-5 h-5" />
                          </div>
                          <h5 className="text-sm font-bold text-white">Click SMS tasdiqlash kodi</h5>
                          <p className="text-xs text-[#888]">
                            <span className="text-white font-medium">{buyerPhone}</span> raqamiga yuborilgan 5 xonali kodni kiriting
                          </p>
                          <p className="text-[11px] text-[#0073ff]">
                            (Test rejimi: kod <strong className="text-amber-300">77777</strong> yoki ixtiyoriy 5 xonali son)
                          </p>
                        </div>

                        <div>
                          <input
                            type="text"
                            value={smsCode}
                            onChange={e => setSmsCode(e.target.value.slice(0, 6))}
                            placeholder="• • • • •"
                            maxLength={6}
                            autoFocus
                            className="w-full py-3.5 bg-[#19192e] border-2 border-[#0073ff] rounded-xl text-center text-xl font-mono font-black text-white tracking-[0.5em] focus:outline-none"
                          />
                        </div>

                        <div className="flex justify-between items-center text-xs text-[#777] pt-1">
                          <span>
                            {smsTimer > 0 ? `Qayta yuborish: ${smsTimer} soniya` : 'Kod kelmadimi?'}
                          </span>
                          {smsTimer === 0 ? (
                            <button
                              type="button"
                              onClick={() => { setSmsTimer(60); toast.success('Yangi kod yuborildi!'); }}
                              className="text-[#0073ff] hover:underline font-bold"
                            >
                              Qayta yuborish
                            </button>
                          ) : (
                            <button
                              type="button"
                              onClick={() => setSmsStep(false)}
                              className="text-[#888] hover:text-white"
                            >
                              Kartani o&apos;zgartirish
                            </button>
                          )}
                        </div>
                      </div>
                    )}
                  </div>
                )}

                {/* TAB 2: CLICK ILOVASI YOKI USSD */}
                {clickTab === 'app' && (
                  <div className="space-y-3.5 pt-1">
                    <div className="p-4 bg-[#10101c] rounded-2xl border border-[#252540] text-center space-y-3">
                      <div className="w-10 h-10 rounded-xl bg-[#0073ff]/20 text-[#0073ff] flex items-center justify-center mx-auto">
                        <Smartphone className="w-5 h-5" />
                      </div>
                      <div>
                        <h5 className="text-sm font-bold text-white">Click ilovasi yoki veb-saytida to&apos;lash</h5>
                        <p className="text-xs text-[#888] mt-1">
                          Quyidagi havola orqali Click rasmiy ilovasiga o&apos;tib to&apos;lovni tasdiqlang
                        </p>
                      </div>

                      <a
                        href={clickPayUrl}
                        target="_blank"
                        rel="noopener noreferrer"
                        className="inline-flex items-center gap-2 px-5 py-3 bg-[#0073ff] hover:bg-[#0060d5] text-white font-bold text-xs rounded-xl shadow-lg shadow-[#0073ff]/30 transition-all hover:scale-105"
                      >
                        <ExternalLink className="w-4 h-4" />
                        Click ilovasida to&apos;lash ({totalPrice.toLocaleString()} so&apos;m)
                      </a>

                      <div className="pt-2 border-t border-white/5">
                        <p className="text-[11px] text-[#777] mb-1">Yoki USSD orqali tezkor to&apos;lov:</p>
                        <code className="px-3 py-1.5 rounded-lg bg-[#18182c] border border-white/10 text-amber-400 font-mono text-xs font-bold inline-block">
                          {ussdCode}
                        </code>
                      </div>
                    </div>
                  </div>
                )}
              </div>

              {/* Action buttons */}
              <div className="flex gap-3 pt-2">
                <button
                  type="button"
                  onClick={() => setStep('seats')}
                  className="px-5 py-3.5 bg-white/5 hover:bg-white/10 text-white font-semibold rounded-2xl transition-colors border border-white/10"
                >
                  Orqaga
                </button>
                <button
                  type="button"
                  disabled={isBooking}
                  onClick={handleStartClickPayment}
                  className="flex-1 py-3.5 bg-gradient-to-r from-[#0073ff] to-[#0051b8] hover:from-[#0065e0] hover:to-[#0047a3] disabled:opacity-50 text-white font-bold rounded-2xl transition-all shadow-lg shadow-[#0073ff]/30 flex items-center justify-center gap-2"
                >
                  {isBooking ? (
                    <div className="w-5 h-5 border-2 border-white/30 border-t-white rounded-full animate-spin" />
                  ) : (
                    <>
                      <Sparkles className="w-4 h-4" />
                      {clickTab === 'card' && !smsStep
                        ? 'SMS kodni olish'
                        : `Click orqali to'lash (${totalPrice.toLocaleString()} so'm)`}
                    </>
                  )}
                </button>
              </div>
            </div>
          )}

          {/* STEP 4: SUCCESS / E-TICKET QR VIEW */}
          {step === 'success' && bookedTicket && (
            <div className="space-y-6 animate-fadeIn max-w-lg mx-auto print:max-w-none">
              <div className="text-center space-y-1">
                <div className="w-12 h-12 bg-green-500/20 text-green-400 rounded-2xl flex items-center justify-center mx-auto mb-2">
                  <CheckCircle2 className="w-6 h-6" />
                </div>
                <h3 className="text-xl font-black text-white">Chipta muvaffaqiyatli rasmiylashtirildi!</h3>
                <p className="text-xs text-[#888]">
                  Kinoteatrga kirishda ushbu QR-kodni nazoratchiga ko&apos;rsatishingiz kifoya.
                </p>
              </div>

              {/* Beautiful Ticket Card */}
              <div id="printable-ticket" className="bg-[#1f1f33] border-2 border-dashed border-[#3d3d66] rounded-3xl p-6 shadow-2xl relative overflow-hidden">
                {/* Glowing decor */}
                <div className="absolute top-0 right-0 w-32 h-32 bg-orange-500/10 rounded-full blur-2xl pointer-events-none" />

                <div className="flex items-start justify-between border-b border-[#2d2d4d] pb-4 mb-4">
                  <div>
                    <span className="text-[10px] font-black tracking-widest text-orange-400 uppercase">
                      CINEMAUZ ELEKTRON CHIPTA
                    </span>
                    <h4 className="text-xl font-black text-white mt-1">{bookedTicket.movie_title}</h4>
                    <p className="text-xs text-[#aaa]">{bookedTicket.cinema_name} • {bookedTicket.hall}</p>
                  </div>
                  <div className="text-right">
                    <span className="text-[10px] text-[#888] block">Chipta №:</span>
                    <span className="text-sm font-mono font-black text-white">{bookedTicket.ticket_number}</span>
                  </div>
                </div>

                <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 py-2 text-xs">
                  <div>
                    <span className="text-[#777] block text-[10px]">Sana:</span>
                    <span className="font-bold text-white">{bookedTicket.date}</span>
                  </div>
                  <div>
                    <span className="text-[#777] block text-[10px]">Vaqt:</span>
                    <span className="font-bold text-white">{bookedTicket.time}</span>
                  </div>
                  <div>
                    <span className="text-[#777] block text-[10px]">Format:</span>
                    <span className="font-bold text-orange-400">{bookedTicket.format}</span>
                  </div>
                  <div>
                    <span className="text-[#777] block text-[10px]">O&apos;rindiqlar:</span>
                    <span className="font-black text-amber-400 text-sm">{bookedTicket.seats.join(', ')}</span>
                  </div>
                </div>

                <div className="grid grid-cols-2 gap-3 py-2 border-t border-[#2d2d4d] mt-3 text-xs">
                  <div>
                    <span className="text-[#777] block text-[10px]">Haridor:</span>
                    <span className="text-white font-medium">{bookedTicket.buyer_name} ({bookedTicket.buyer_phone})</span>
                  </div>
                  <div className="text-right">
                    <span className="text-[#777] block text-[10px]">To&apos;langan summa:</span>
                    <span className="font-black text-amber-400 text-sm">{bookedTicket.total_price.toLocaleString()} so&apos;m</span>
                  </div>
                </div>

                <div className="flex items-center justify-between py-2 border-t border-[#2d2d4d] mt-1 text-xs">
                  <div className="flex items-center gap-1.5">
                    <span className="px-2 py-0.5 rounded bg-[#0073ff] text-white text-[10px] font-black">
                      CLICK
                    </span>
                    <span className="text-emerald-400 font-semibold text-[11px]">To&apos;langan</span>
                  </div>
                  {bookedTicket.click_trans_id && (
                    <span className="text-[10px] text-[#aaa] font-mono">
                      ID: {bookedTicket.click_trans_id}
                    </span>
                  )}
                </div>

                {/* QR Code section */}
                <div className="mt-4 pt-4 border-t border-dashed border-[#3d3d66] flex flex-col items-center justify-center">
                  <div className="p-3 bg-white rounded-2xl shadow-md inline-block">
                    {/* SVG QR Code Simulation */}
                    <img
                      src={`https://api.qrserver.com/v1/create-qr-code/?size=140x140&data=${encodeURIComponent(bookedTicket.qr_data)}`}
                      alt="Chipta QR-kodi"
                      className="w-32 h-32 object-contain"
                    />
                  </div>
                  <p className="text-[10px] text-[#888] font-mono mt-2">
                    KOD: {bookedTicket.ticket_number} • SCAN & ENTER
                  </p>
                </div>
              </div>

              {/* Action buttons */}
              <div className="flex gap-3 print:hidden">
                <button
                  onClick={handlePrint}
                  className="flex-1 py-3 bg-[#1b1b2a] hover:bg-[#252538] text-white font-bold rounded-2xl border border-[#2a2a44] transition-colors flex items-center justify-center gap-2 text-sm"
                >
                  <Printer className="w-4 h-4" />
                  Chop etish / Saqlash
                </button>
                <button
                  onClick={onClose}
                  className="flex-1 py-3 bg-gradient-to-r from-orange-500 to-amber-600 hover:from-orange-600 hover:to-amber-700 text-white font-bold rounded-2xl transition-colors flex items-center justify-center gap-2 text-sm shadow-lg shadow-orange-500/20"
                >
                  Tushunarli
                </button>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
