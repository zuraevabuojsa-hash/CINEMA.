export function LoadingSpinner({ size = 'md' }: { size?: 'sm' | 'md' | 'lg' }) {
  const sizes = { sm: 'w-4 h-4', md: 'w-8 h-8', lg: 'w-12 h-12' };
  return (
    <div className={`${sizes[size]} border-2 border-[#2a2a2a] border-t-[#e50914] rounded-full animate-spin`} />
  );
}

export function PageLoader() {
  return (
    <div className="min-h-screen flex items-center justify-center bg-[#0d0d0d]">
      <div className="flex flex-col items-center gap-4">
        <div className="w-12 h-12 border-3 border-[#2a2a2a] border-t-[#e50914] rounded-full animate-spin" style={{ borderWidth: '3px' }} />
        <p className="text-[#888] text-sm">Yuklanmoqda...</p>
      </div>
    </div>
  );
}

export function MovieCardSkeleton() {
  return (
    <div className="space-y-3">
      <div className="h-64 rounded-2xl skeleton" />
      <div className="h-4 w-3/4 rounded skeleton" />
      <div className="h-3 w-1/2 rounded skeleton" />
    </div>
  );
}

export function MovieGridSkeleton({ count = 8 }: { count?: number }) {
  return (
    <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 xl:grid-cols-6 gap-4">
      {Array.from({ length: count }).map((_, i) => (
        <MovieCardSkeleton key={i} />
      ))}
    </div>
  );
}
