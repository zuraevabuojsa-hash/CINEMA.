'use client';

import { useState } from 'react';
import Link from 'next/link';
import { Play, Star, Clock, Heart } from 'lucide-react';
import { formatDuration, AUDIO_LANG_LABELS } from '@/lib/utils';
import { useAuthStore } from '@/store/authStore';
import { usersAPI } from '@/lib/api';
import toast from 'react-hot-toast';

interface Movie {
  id: string;
  title: string;
  original_title?: string;
  poster: string;
  year: number;
  genres: string[];
  duration: number;
  rating: number;
  audio_tracks: string[];
  is_featured?: boolean;
}

interface MovieCardProps {
  movie: Movie;
  size?: 'sm' | 'md' | 'lg';
  onWatchTogether?: (movie: Movie) => void;
}

export default function MovieCard({ movie, size = 'md' }: MovieCardProps) {
  const { isAuthenticated } = useAuthStore();
  const [isFav, setIsFav] = useState(false);
  const [hovered, setHovered] = useState(false);

  async function toggleFavorite(e: React.MouseEvent) {
    e.preventDefault();
    e.stopPropagation();
    if (!isAuthenticated) {
      toast.error('Sevimliga qo\'shish uchun kirish kerak');
      return;
    }
    try {
      const res = await usersAPI.toggleFavorite(movie.id);
      setIsFav(res.data.is_favorite);
      toast.success(res.data.is_favorite ? 'Sevimlilarga qo\'shildi' : 'Sevimlilardan olib tashlandi');
    } catch {
      toast.error('Xato yuz berdi');
    }
  }

  const heights: Record<string, string> = { sm: 'h-52', md: 'h-64', lg: 'h-80' };

  return (
    <div
      className="relative group cursor-pointer"
      onMouseEnter={() => setHovered(true)}
      onMouseLeave={() => setHovered(false)}
    >
      <Link href={`/movies/${movie.id}`}>
        <div className={`relative ${heights[size]} rounded-2xl overflow-hidden bg-[#1a1a1a]`}>
          {/* Poster */}
          {/* eslint-disable-next-line @next/next/no-img-element */}
          <img
            src={movie.poster}
            alt={movie.title}
            className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-105"
            loading="lazy"
          />

          {/* Gradient overlay */}
          <div className="absolute inset-0 card-overlay opacity-0 group-hover:opacity-100 transition-opacity duration-300" />

          {/* Rating badge */}
          <div className="absolute top-2 left-2 flex items-center gap-1 bg-black/70 backdrop-blur-sm rounded-lg px-2 py-1">
            <Star className="w-3 h-3 text-[#f5c518] fill-[#f5c518]" />
            <span className="text-xs font-semibold text-white">{movie.rating.toFixed(1)}</span>
          </div>

          {/* Audio language badge */}
          {movie.audio_tracks?.includes('uzbek') && (
            <div className="absolute top-2 right-2 bg-[#e50914]/90 rounded-lg px-2 py-0.5">
              <span className="text-[10px] font-bold text-white">UZ</span>
            </div>
          )}

          {/* Favorite button */}
          <button
            onClick={toggleFavorite}
            className={`absolute top-2 right-2 p-1.5 rounded-full transition-all duration-200 ${
              movie.audio_tracks?.includes('uzbek') ? 'top-9' : 'top-2'
            } ${isFav ? 'bg-[#e50914] text-white' : 'bg-black/50 text-white opacity-0 group-hover:opacity-100'}`}
          >
            <Heart className={`w-3.5 h-3.5 ${isFav ? 'fill-white' : ''}`} />
          </button>

          {/* Hover actions */}
          {hovered && (
            <div className="absolute bottom-3 left-3 right-3 flex gap-2 animate-fade-in">
              <Link
                href={`/movies/${movie.id}`}
                className="w-full flex items-center justify-center gap-1.5 py-2.5 bg-[#e50914] hover:bg-[#c0070f] text-white text-xs font-semibold rounded-xl transition-colors shadow-lg shadow-[#e50914]/20"
                onClick={(e) => e.stopPropagation()}
              >
                <Play className="w-3.5 h-3.5 fill-white" />
                Ko&apos;rish
              </Link>
            </div>
          )}
        </div>

        {/* Info */}
        <div className="mt-3 px-1">
          <h3 className="font-semibold text-white text-sm line-clamp-1 group-hover:text-[#e50914] transition-colors">
            {movie.title}
          </h3>
          <div className="flex items-center gap-2 mt-1">
            <span className="text-xs text-[#888]">{movie.year}</span>
            <span className="text-[#444] text-xs">•</span>
            <span className="text-xs text-[#888]">{movie.genres?.[0]}</span>
            <span className="text-[#444] text-xs">•</span>
            <div className="flex items-center gap-1">
              <Clock className="w-3 h-3 text-[#888]" />
              <span className="text-xs text-[#888]">{formatDuration(movie.duration)}</span>
            </div>
          </div>
        </div>
      </Link>
    </div>
  );
}
