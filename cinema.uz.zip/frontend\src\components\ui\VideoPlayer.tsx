'use client';

import { useEffect, useRef, useState } from 'react';
import {
  Play, Pause, Volume2, VolumeX, Maximize, Minimize,
  SkipBack, SkipForward, Settings, X
} from 'lucide-react';
import { formatTime } from '@/lib/utils';

interface VideoPlayerProps {
  src: string;
  hlsSrc?: string | null;
  poster?: string;
  title?: string;
  onTimeUpdate?: (time: number) => void;
  onPlay?: () => void;
  onPause?: () => void;
  externalRef?: React.RefObject<HTMLVideoElement>;
  autoPlay?: boolean;
}

export default function VideoPlayer({
  src,
  hlsSrc,
  poster,
  title,
  onTimeUpdate,
  onPlay,
  onPause,
  externalRef,
  autoPlay = false,
}: VideoPlayerProps) {
  const internalRef = useRef<HTMLVideoElement>(null);
  const videoRef = externalRef || internalRef;
  const containerRef = useRef<HTMLDivElement>(null);

  const [isPlaying, setIsPlaying] = useState(false);
  const [currentTime, setCurrentTime] = useState(0);
  const [duration, setDuration] = useState(0);
  const [volume, setVolume] = useState(0.8);
  const [isMuted, setIsMuted] = useState(false);
  const [isFullscreen, setIsFullscreen] = useState(false);
  const [showControls, setShowControls] = useState(true);
  const [isSeeking, setIsSeeking] = useState(false);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState('');
  const [showSettings, setShowSettings] = useState(false);
  const controlsTimer = useRef<ReturnType<typeof setTimeout> | null>(null);

  useEffect(() => {
    const video = videoRef.current;
    if (!video) return;

    // HLS qo'llab-quvvatlash
    const videoSrc = hlsSrc || src;
    
    if (videoSrc && videoSrc.includes('.m3u8')) {
      // HLS stream
      if (video.canPlayType('application/vnd.apple.mpegurl')) {
        // Safari - native HLS
        video.src = videoSrc;
      } else {
        // Chrome/Firefox - hls.js orqali
        import('hls.js').then(({ default: Hls }) => {
          if (Hls.isSupported()) {
            const hls = new Hls({
              enableWorker: true,
              lowLatencyMode: false,
            });
            hls.loadSource(videoSrc);
            hls.attachMedia(video);
            hls.on(Hls.Events.ERROR, (_, data) => {
              if (data.fatal) {
                // HLS ishlamasa, oddiy MP4 ga qaytish
                video.src = src;
              }
            });
          } else {
            video.src = src;
          }
        }).catch(() => {
          video.src = src;
        });
      }
    } else {
      // MP4 yoki boshqa format
      video.src = videoSrc || src;
    }

    video.volume = volume;
    if (autoPlay) video.play().catch(() => {});

    return () => {
      video.pause();
    };
  }, [src, hlsSrc]);

  function togglePlay() {
    const video = videoRef.current;
    if (!video) return;
    if (isPlaying) {
      video.pause();
      onPause?.();
    } else {
      video.play().catch(() => setError("Video yuklanmadi. Internet aloqangizni tekshiring."));
      onPlay?.();
    }
  }

  function handleSeek(e: React.ChangeEvent<HTMLInputElement>) {
    const time = parseFloat(e.target.value);
    setCurrentTime(time);
    if (videoRef.current) videoRef.current.currentTime = time;
  }

  function skip(sec: number) {
    if (!videoRef.current) return;
    const t = Math.max(0, Math.min(duration, currentTime + sec));
    videoRef.current.currentTime = t;
    setCurrentTime(t);
  }

  function toggleMute() {
    if (!videoRef.current) return;
    const m = !isMuted;
    setIsMuted(m);
    videoRef.current.volume = m ? 0 : volume;
  }

  function toggleFullscreen() {
    if (!containerRef.current) return;
    if (!document.fullscreenElement) {
      containerRef.current.requestFullscreen();
      setIsFullscreen(true);
    } else {
      document.exitFullscreen();
      setIsFullscreen(false);
    }
  }

  function showControlsTemporarily() {
    setShowControls(true);
    if (controlsTimer.current) clearTimeout(controlsTimer.current);
    controlsTimer.current = setTimeout(() => {
      if (isPlaying) setShowControls(false);
    }, 3000);
  }

  const progress = duration > 0 ? (currentTime / duration) * 100 : 0;

  return (
    <div
      ref={containerRef}
      className="relative w-full aspect-video bg-black rounded-2xl overflow-hidden group"
      onMouseMove={showControlsTemporarily}
      onMouseLeave={() => isPlaying && setShowControls(false)}
    >
      {/* Video */}
      <video
        ref={videoRef}
        poster={poster}
        className="w-full h-full object-contain"
        onClick={togglePlay}
        onPlay={() => { setIsPlaying(true); setIsLoading(false); }}
        onPause={() => setIsPlaying(false)}
        onTimeUpdate={() => {
          if (!isSeeking && videoRef.current) {
            const t = videoRef.current.currentTime;
            setCurrentTime(t);
            onTimeUpdate?.(t);
          }
        }}
        onLoadedMetadata={() => {
          if (videoRef.current) {
            setDuration(videoRef.current.duration);
            setIsLoading(false);
          }
        }}
        onWaiting={() => setIsLoading(true)}
        onCanPlay={() => setIsLoading(false)}
        onError={() => {
          setError('Video yuklanmadi');
          setIsLoading(false);
        }}
        onEnded={() => setIsPlaying(false)}
        playsInline
      />

      {/* Loading spinner */}
      {isLoading && !error && (
        <div className="absolute inset-0 flex items-center justify-center bg-black/50">
          <div className="w-12 h-12 border-3 border-white/20 border-t-[#e50914] rounded-full animate-spin" style={{ borderWidth: '3px' }} />
        </div>
      )}

      {/* Error */}
      {error && (
        <div className="absolute inset-0 flex flex-col items-center justify-center bg-black/80 text-center p-6">
          <div className="text-4xl mb-3">⚠️</div>
          <p className="text-white font-semibold mb-1">{error}</p>
          <p className="text-[#888] text-sm mb-4">Video manbasiga ulanib bo'lmadi</p>
          <button
            onClick={() => { setError(''); if (videoRef.current) { videoRef.current.load(); videoRef.current.play().catch(() => {}); } }}
            className="px-4 py-2 bg-[#e50914] text-white rounded-xl text-sm font-medium"
          >
            Qayta urinish
          </button>
        </div>
      )}

      {/* Center play button */}
      {!isPlaying && !isLoading && !error && (
        <div className="absolute inset-0 flex items-center justify-center pointer-events-none">
          <div className="w-16 h-16 bg-black/60 backdrop-blur-sm rounded-full flex items-center justify-center">
            <Play className="w-8 h-8 text-white fill-white ml-1" />
          </div>
        </div>
      )}

      {/* Title */}
      {title && showControls && (
        <div className="absolute top-0 left-0 right-0 px-4 py-3 bg-gradient-to-b from-black/70 to-transparent">
          <p className="text-white text-sm font-medium truncate">{title}</p>
        </div>
      )}

      {/* Controls */}
      <div className={`absolute bottom-0 left-0 right-0 transition-opacity duration-300 ${showControls || !isPlaying ? 'opacity-100' : 'opacity-0'}`}>
        <div className="video-controls px-4 pb-4 pt-8">
          {/* Progress */}
          <div className="flex items-center gap-2 mb-3">
            <span className="text-xs text-white font-mono w-12">{formatTime(currentTime)}</span>
            <div className="flex-1">
              <input
                type="range" min={0} max={duration || 100} value={currentTime}
                onChange={handleSeek}
                onMouseDown={() => setIsSeeking(true)}
                onMouseUp={() => { setIsSeeking(false); }}
                className="w-full progress-bar cursor-pointer"
                style={{ background: `linear-gradient(to right, #e50914 ${progress}%, rgba(255,255,255,0.2) ${progress}%)` }}
              />
            </div>
            <span className="text-xs text-white font-mono w-12 text-right">{formatTime(duration)}</span>
          </div>

          {/* Buttons */}
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-1">
              <button onClick={togglePlay} className="p-2 hover:bg-white/10 rounded-xl text-white transition-colors">
                {isPlaying ? <Pause className="w-5 h-5 fill-white" /> : <Play className="w-5 h-5 fill-white" />}
              </button>
              <button onClick={() => skip(-10)} className="p-2 hover:bg-white/10 rounded-xl text-white transition-colors">
                <SkipBack className="w-4 h-4" />
              </button>
              <button onClick={() => skip(10)} className="p-2 hover:bg-white/10 rounded-xl text-white transition-colors">
                <SkipForward className="w-4 h-4" />
              </button>
              {/* Volume */}
              <div className="flex items-center gap-1 group/vol">
                <button onClick={toggleMute} className="p-2 hover:bg-white/10 rounded-xl text-white transition-colors">
                  {isMuted || volume === 0 ? <VolumeX className="w-4 h-4" /> : <Volume2 className="w-4 h-4" />}
                </button>
                <div className="w-0 overflow-hidden group-hover/vol:w-20 transition-all duration-200">
                  <input
                    type="range" min={0} max={1} step={0.05}
                    value={isMuted ? 0 : volume}
                    onChange={(e) => {
                      const v = parseFloat(e.target.value);
                      setVolume(v);
                      setIsMuted(v === 0);
                      if (videoRef.current) videoRef.current.volume = v;
                    }}
                    className="w-20"
                    style={{ background: `linear-gradient(to right, white ${(isMuted ? 0 : volume) * 100}%, rgba(255,255,255,0.2) ${(isMuted ? 0 : volume) * 100}%)` }}
                  />
                </div>
              </div>
            </div>

            <div className="flex items-center gap-1">
              <button
                onClick={toggleFullscreen}
                className="p-2 hover:bg-white/10 rounded-xl text-white transition-colors"
              >
                {isFullscreen ? <Minimize className="w-4 h-4" /> : <Maximize className="w-4 h-4" />}
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
