import axios from 'axios';

const API_URL = process.env.NEXT_PUBLIC_API_URL || (typeof window !== 'undefined' ? '/api' : 'http://localhost:5000/api');

const api = axios.create({
  baseURL: API_URL,
  headers: { 'Content-Type': 'application/json' },
});

// Token qo'shish
api.interceptors.request.use((config) => {
  if (typeof window !== 'undefined') {
    const token = localStorage.getItem('cinema_token');
    if (token) config.headers.Authorization = `Bearer ${token}`;
  }
  return config;
});

// Xato boshqarish
api.interceptors.response.use(
  (res) => res,
  (err) => {
    if (err.response?.status === 401 && typeof window !== 'undefined') {
      localStorage.removeItem('cinema_token');
      localStorage.removeItem('cinema_user');
      window.location.href = '/login';
    }
    return Promise.reject(err);
  }
);

export default api;

// Auth
export const authAPI = {
  login: (email: string, password: string) => api.post('/auth/login', { email, password }),
  register: (username: string, email: string, password: string) =>
    api.post('/auth/register', { username, email, password }),
  googleLogin: (data: { email: string; name?: string; avatar?: string; googleId?: string }) =>
    api.post('/auth/google', data),
  me: () => api.get('/auth/me'),
  forgotPassword: (email: string) => api.post('/auth/forgot-password', { email }),
};

// Movies
export const moviesAPI = {
  getAll: (params?: Record<string, string | number>) => api.get('/movies', { params }),
  getById: (id: string) => api.get(`/movies/${id}`),
  getFeatured: () => api.get('/movies/featured'),
  getGenres: () => api.get('/movies/genres'),
  getSeries: () => api.get('/movies/series'),
  search: (q: string) => api.get(`/movies/search/query`, { params: { q } }),
};

// Rooms
export const roomsAPI = {
  create: (data: Record<string, unknown>) => api.post('/rooms/create', data),
  getByCode: (code: string) => api.get(`/rooms/${code}`),
  join: (code: string) => api.post(`/rooms/${code}/join`),
  leave: (code: string) => api.post(`/rooms/${code}/leave`),
  myRooms: () => api.get('/rooms/user/my-rooms'),
};

// Users
export const usersAPI = {
  updateProfile: (data: Record<string, string>) => api.put('/users/profile', data),
  getFavorites: () => api.get('/users/favorites'),
  toggleFavorite: (movieId: string) => api.post(`/users/favorites/${movieId}`),
  getHistory: () => api.get('/users/history'),
  saveHistory: (movieId: string, currentTime: number) =>
    api.post(`/users/history/${movieId}`, { current_time: currentTime }),
  getFriends: () => api.get('/users/friends'),
  getFriendRequests: () => api.get('/users/friends/requests'),
  sendFriendRequest: (targetId: string) => api.post(`/users/friends/request/${targetId}`),
  acceptFriendRequest: (requestId: string) => api.post(`/users/friends/accept/${requestId}`),
  removeFriend: (friendId: string) => api.delete(`/users/friends/${friendId}`),
  searchUsers: (q: string) => api.get('/users/search', { params: { q } }),
  getNotifications: () => api.get('/users/notifications'),
  markNotificationRead: (id: string) => api.put(`/users/notifications/${id}/read`),
  markAllRead: () => api.put('/users/notifications/read-all'),
};

// Admin
export const adminAPI = {
  getStats: () => api.get('/admin/stats'),
  getUsers: () => api.get('/admin/users'),
  updateUserStatus: (id: string, status: string) => api.put(`/admin/users/${id}/status`, { status }),
  addMovie: (data: Record<string, unknown>) => api.post('/admin/movies', data),
  updateMovie: (id: string, data: Record<string, unknown>) => api.put(`/admin/movies/${id}`, data),
  deleteMovie: (id: string) => api.delete(`/admin/movies/${id}`),
  getRooms: () => api.get('/admin/rooms'),
  endRoom: (id: string) => api.delete(`/admin/rooms/${id}`),
};

// Tickets
export const ticketsAPI = {
  getCinemas: () => api.get('/tickets/cinemas'),
  getSessions: (params?: Record<string, string>) => api.get('/tickets/sessions', { params }),
  getSessionDetails: (sessionId: string) => api.get(`/tickets/session/${sessionId}`),
  bookTicket: (data: Record<string, unknown>) => api.post('/tickets/book', data),
  getMyTickets: () => api.get('/tickets/my-tickets'),
  getTicketById: (ticketId: string) => api.get(`/tickets/${ticketId}`),
  clickPrepare: (data: Record<string, unknown>) => api.post('/tickets/click/prepare', data),
  clickVerify: (data: Record<string, unknown>) => api.post('/tickets/click/verify', data),
};

