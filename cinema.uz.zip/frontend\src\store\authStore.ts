import { create } from 'zustand';
import { authAPI } from '@/lib/api';
import { reconnectSocket, disconnectSocket } from '@/lib/socket';

interface User {
  id: string;
  username: string;
  email: string;
  avatar: string;
  role: 'user' | 'admin';
}

interface AuthState {
  user: User | null;
  token: string | null;
  isLoading: boolean;
  isAuthenticated: boolean;
  login: (email: string, password: string) => Promise<void>;
  register: (username: string, email: string, password: string) => Promise<void>;
  googleLogin: (data: { email: string; name?: string; avatar?: string; googleId?: string }) => Promise<void>;
  logout: () => void;
  loadUser: () => Promise<void>;
  updateUser: (data: Partial<User>) => void;
}

export const useAuthStore = create<AuthState>((set, get) => ({
  user: null,
  token: null,
  isLoading: false,
  isAuthenticated: false,

  login: async (email, password) => {
    set({ isLoading: true });
    try {
      const res = await authAPI.login(email, password);
      const { token, user } = res.data;
      localStorage.setItem('cinema_token', token);
      localStorage.setItem('cinema_user', JSON.stringify(user));
      set({ user, token, isAuthenticated: true, isLoading: false });
      reconnectSocket();
    } catch (err) {
      set({ isLoading: false });
      throw err;
    }
  },

  register: async (username, email, password) => {
    set({ isLoading: true });
    try {
      const res = await authAPI.register(username, email, password);
      const { token, user } = res.data;
      localStorage.setItem('cinema_token', token);
      localStorage.setItem('cinema_user', JSON.stringify(user));
      set({ user, token, isAuthenticated: true, isLoading: false });
      reconnectSocket();
    } catch (err) {
      set({ isLoading: false });
      throw err;
    }
  },

  googleLogin: async (data: { email: string; name?: string; avatar?: string; googleId?: string }) => {
    set({ isLoading: true });
    try {
      const res = await authAPI.googleLogin(data);
      const { token, user } = res.data;
      localStorage.setItem('cinema_token', token);
      localStorage.setItem('cinema_user', JSON.stringify(user));
      set({ user, token, isAuthenticated: true, isLoading: false });
      reconnectSocket();
    } catch (err) {
      set({ isLoading: false });
      throw err;
    }
  },

  logout: () => {
    localStorage.removeItem('cinema_token');
    localStorage.removeItem('cinema_user');
    disconnectSocket();
    set({ user: null, token: null, isAuthenticated: false });
  },

  loadUser: async () => {
    const token = localStorage.getItem('cinema_token');
    const savedUser = localStorage.getItem('cinema_user');
    if (!token) return;

    // Tezroq yuklash uchun local user ni oldin set qilish
    if (savedUser) {
      try {
        const user = JSON.parse(savedUser);
        set({ user, token, isAuthenticated: true });
      } catch {}
    }

    try {
      const res = await authAPI.me();
      const user = res.data.user;
      localStorage.setItem('cinema_user', JSON.stringify(user));
      set({ user, token, isAuthenticated: true });
    } catch {
      localStorage.removeItem('cinema_token');
      localStorage.removeItem('cinema_user');
      set({ user: null, token: null, isAuthenticated: false });
    }
  },

  updateUser: (data) => {
    const current = get().user;
    if (current) {
      const updated = { ...current, ...data };
      localStorage.setItem('cinema_user', JSON.stringify(updated));
      set({ user: updated });
    }
  },
}));
