import { create } from 'zustand';

interface ThemeState {
  isDark: boolean;
  toggleTheme: () => void;
  setTheme: (dark: boolean) => void;
}

export const useThemeStore = create<ThemeState>((set) => ({
  isDark: true,

  toggleTheme: () => {
    set((state) => {
      const newDark = !state.isDark;
      if (typeof window !== 'undefined') {
        localStorage.setItem('cinema_theme', newDark ? 'dark' : 'light');
        document.documentElement.classList.toggle('dark', newDark);
        document.documentElement.classList.toggle('light', !newDark);
      }
      return { isDark: newDark };
    });
  },

  setTheme: (dark: boolean) => {
    if (typeof window !== 'undefined') {
      localStorage.setItem('cinema_theme', dark ? 'dark' : 'light');
      document.documentElement.classList.toggle('dark', dark);
      document.documentElement.classList.toggle('light', !dark);
    }
    set({ isDark: dark });
  },
}));
