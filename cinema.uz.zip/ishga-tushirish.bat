@echo off
title CinemaUz Platformasi
color 0A
echo ========================================================
echo               CinemaUz Loyihasi Ishga Tushmoqda
echo ========================================================
echo.

echo 1. Backend server ishga tushmoqda (port 5000)...
start "CinemaUz Backend" cmd /k "cd backend && npm start"

timeout /t 3 /nobreak >nul

echo 2. Frontend sayt ishga tushmoqda (port 3000)...
start "CinemaUz Frontend" cmd /k "cd frontend && npm run dev"

echo.
echo ========================================================
echo   Sayt manzili: http://localhost:3000
echo   Backend manzili: http://localhost:5000
echo ========================================================
echo.
pause
