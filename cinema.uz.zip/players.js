const PLAYERS = [
  {
    name: "Lionel Messi",
    aliases: ["messi", "lio messi", "lionel messi", "leo messi"],
    club: "Inter Miami",
    flag: "🇦🇷",
    country: "Argentina",
    position: "Forward",
    firstLetter: "L"
  },
  {
    name: "Cristiano Ronaldo",
    aliases: ["ronaldo", "cristiano ronaldo", "cr7", "cristiano"],
    club: "Al Nassr",
    flag: "🇵🇹",
    country: "Portugal",
    position: "Forward",
    firstLetter: "C"
  },
  {
    name: "Erling Haaland",
    aliases: ["haaland", "erling haaland", "erling braut haaland"],
    club: "Manchester City",
    flag: "🇳🇴",
    country: "Norway",
    position: "Forward",
    firstLetter: "E"
  },
  {
    name: "Kylian Mbappé",
    aliases: ["mbappe", "kylian mbappe", "kylian mbappé", "mbape"],
    club: "Real Madrid",
    flag: "🇫🇷",
    country: "France",
    position: "Forward",
    firstLetter: "K"
  },
  {
    name: "Jude Bellingham",
    aliases: ["bellingham", "jude bellingham"],
    club: "Real Madrid",
    flag: "🏴󠁧󠁢󠁥󠁮󠁧󠁿",
    country: "England",
    position: "Midfielder",
    firstLetter: "J"
  },
  {
    name: "Vinícius Júnior",
    aliases: ["vinicius jr", "vinicius junior", "vinicius", "vini jr", "vini"],
    club: "Real Madrid",
    flag: "🇧🇷",
    country: "Brazil",
    position: "Forward",
    firstLetter: "V"
  },
  {
    name: "Kevin De Bruyne",
    aliases: ["de bruyne", "kevin de bruyne", "kdb"],
    club: "Manchester City",
    flag: "🇧🇪",
    country: "Belgium",
    position: "Midfielder",
    firstLetter: "K"
  },
  {
    name: "Mohamed Salah",
    aliases: ["salah", "mohamed salah", "mo salah"],
    club: "Liverpool",
    flag: "🇪🇬",
    country: "Egypt",
    position: "Forward",
    firstLetter: "M"
  },
  {
    name: "Harry Kane",
    aliases: ["kane", "harry kane"],
    club: "Bayern Munich",
    flag: "🏴󠁧󠁢󠁥󠁮󠁧󠁿",
    country: "England",
    position: "Forward",
    firstLetter: "H"
  },
  {
    name: "Robert Lewandowski",
    aliases: ["lewandowski", "robert lewandowski", "lewy"],
    club: "Barcelona",
    flag: "🇵🇱",
    country: "Poland",
    position: "Forward",
    firstLetter: "R"
  },
  {
    name: "Neymar Jr",
    aliases: ["neymar", "neymar jr", "neymar junior"],
    club: "Al Hilal",
    flag: "🇧🇷",
    country: "Brazil",
    position: "Forward",
    firstLetter: "N"
  },
  {
    name: "Antoine Griezmann",
    aliases: ["griezmann", "antoine griezmann"],
    club: "Atletico Madrid",
    flag: "🇫🇷",
    country: "France",
    position: "Forward",
    firstLetter: "A"
  },
  {
    name: "Bukayo Saka",
    aliases: ["saka", "bukayo saka"],
    club: "Arsenal",
    flag: "🏴󠁧󠁢󠁥󠁮󠁧󠁿",
    country: "England",
    position: "Forward",
    firstLetter: "B"
  },
  {
    name: "Phil Foden",
    aliases: ["foden", "phil foden"],
    club: "Manchester City",
    flag: "🏴󠁧󠁢󠁥󠁮󠁧󠁿",
    country: "England",
    position: "Midfielder",
    firstLetter: "P"
  },
  {
    name: "Jamal Musiala",
    aliases: ["musiala", "jamal musiala"],
    club: "Bayern Munich",
    flag: "🇩🇪",
    country: "Germany",
    position: "Midfielder",
    firstLetter: "J"
  },
  {
    name: "Florian Wirtz",
    aliases: ["wirtz", "florian wirtz"],
    club: "Bayer Leverkusen",
    flag: "🇩🇪",
    country: "Germany",
    position: "Midfielder",
    firstLetter: "F"
  },
  {
    name: "Rodri",
    aliases: ["rodri", "rodrigo hernandez", "rodrigo"],
    club: "Manchester City",
    flag: "🇪🇸",
    country: "Spain",
    position: "Midfielder",
    firstLetter: "R"
  },
  {
    name: "Luka Modrić",
    aliases: ["modric", "luka modric", "luka modrić"],
    club: "Real Madrid",
    flag: "🇭🇷",
    country: "Croatia",
    position: "Midfielder",
    firstLetter: "L"
  },
  {
    name: "Bruno Fernandes",
    aliases: ["fernandes", "bruno fernandes"],
    club: "Manchester United",
    flag: "🇵🇹",
    country: "Portugal",
    position: "Midfielder",
    firstLetter: "B"
  },
  {
    name: "Bernardo Silva",
    aliases: ["silva", "bernardo silva"],
    club: "Manchester City",
    flag: "🇵🇹",
    country: "Portugal",
    position: "Midfielder",
    firstLetter: "B"
  },
  {
    name: "Son Heung-min",
    aliases: ["son", "heung-min son", "son heung min", "heung min son"],
    club: "Tottenham Hotspur",
    flag: "🇰🇷",
    country: "South Korea",
    position: "Forward",
    firstLetter: "S"
  },
  {
    name: "Marcus Rashford",
    aliases: ["rashford", "marcus rashford"],
    club: "Manchester United",
    flag: "🏴󠁧󠁢󠁥󠁮󠁧󠁿",
    country: "England",
    position: "Forward",
    firstLetter: "M"
  },
  {
    name: "Martin Ødegaard",
    aliases: ["odegaard", "martin odegaard", "martin ødegaard"],
    club: "Arsenal",
    flag: "🇳🇴",
    country: "Norway",
    position: "Midfielder",
    firstLetter: "M"
  },
  {
    name: "Virgil van Dijk",
    aliases: ["van dijk", "virgil van dijk", "dijk"],
    club: "Liverpool",
    flag: "🇳🇱",
    country: "Netherlands",
    position: "Defender",
    firstLetter: "V"
  },
  {
    name: "Alisson Becker",
    aliases: ["alisson", "alisson becker"],
    club: "Liverpool",
    flag: "🇧🇷",
    country: "Brazil",
    position: "Goalkeeper",
    firstLetter: "A"
  },
  {
    name: "Thibaut Courtois",
    aliases: ["courtois", "thibaut courtois"],
    club: "Real Madrid",
    flag: "🇧🇪",
    country: "Belgium",
    position: "Goalkeeper",
    firstLetter: "T"
  },
  {
    name: "Manuel Neuer",
    aliases: ["neuer", "manuel neuer"],
    club: "Bayern Munich",
    flag: "🇩🇪",
    country: "Germany",
    position: "Goalkeeper",
    firstLetter: "M"
  },
  {
    name: "Rafael Leão",
    aliases: ["leao", "rafael leao", "rafael leão"],
    club: "AC Milan",
    flag: "🇵🇹",
    country: "Portugal",
    position: "Forward",
    firstLetter: "R"
  },
  {
    name: "Victor Osimhen",
    aliases: ["osimhen", "victor osimhen"],
    club: "Galatasaray",
    flag: "🇳🇬",
    country: "Nigeria",
    position: "Forward",
    firstLetter: "V"
  },
  {
    name: "Lautaro Martínez",
    aliases: ["martinez", "lautaro martinez", "lautaro martínez"],
    club: "Inter Milan",
    flag: "🇦🇷",
    country: "Argentina",
    position: "Forward",
    firstLetter: "L"
  },
  {
    name: "Khvicha Kvaratskhelia",
    aliases: ["kvaratskhelia", "kvara", "khvicha kvaratskhelia"],
    club: "Napoli",
    flag: "🇬🇪",
    country: "Georgia",
    position: "Forward",
    firstLetter: "K"
  },
  {
    name: "Pedri",
    aliases: ["pedri", "pedro gonzalez"],
    club: "Barcelona",
    flag: "🇪🇸",
    country: "Spain",
    position: "Midfielder",
    firstLetter: "P"
  },
  {
    name: "Gavi",
    aliases: ["gavi", "pablo gavi"],
    club: "Barcelona",
    flag: "🇪🇸",
    country: "Spain",
    position: "Midfielder",
    firstLetter: "G"
  },
  {
    name: "Frenkie de Jong",
    aliases: ["de jong", "frenkie de jong"],
    club: "Barcelona",
    flag: "🇳🇱",
    country: "Netherlands",
    position: "Midfielder",
    firstLetter: "F"
  },
  {
    name: "Federico Valverde",
    aliases: ["valverde", "federico valverde", "fede valverde"],
    club: "Real Madrid",
    flag: "🇺🇾",
    country: "Uruguay",
    position: "Midfielder",
    firstLetter: "F"
  },
  {
    name: "Aurélien Tchouaméni",
    aliases: ["tchouameni", "aurelien tchouameni", "aurélien tchouaméni"],
    club: "Real Madrid",
    flag: "🇫🇷",
    country: "France",
    position: "Midfielder",
    firstLetter: "A"
  },
  {
    name: "Eduardo Camavinga",
    aliases: ["camavinga", "eduardo camavinga"],
    club: "Real Madrid",
    flag: "🇫🇷",
    country: "France",
    position: "Midfielder",
    firstLetter: "E"
  },
  {
    name: "Rodrygo Goes",
    aliases: ["rodrygo", "rodrygo goes"],
    club: "Real Madrid",
    flag: "🇧🇷",
    country: "Brazil",
    position: "Forward",
    firstLetter: "R"
  },
  {
    name: "Julián Álvarez",
    aliases: ["alvarez", "julian alvarez", "julián álvarez"],
    club: "Atletico Madrid",
    flag: "🇦🇷",
    country: "Argentina",
    position: "Forward",
    firstLetter: "J"
  },
  {
    name: "Alexis Mac Allister",
    aliases: ["mac allister", "alexis mac allister"],
    club: "Liverpool",
    flag: "🇦🇷",
    country: "Argentina",
    position: "Midfielder",
    firstLetter: "A"
  },
  {
    name: "Enzo Fernández",
    aliases: ["fernandez", "enzo fernandez", "enzo fernández"],
    club: "Chelsea",
    flag: "🇦🇷",
    country: "Argentina",
    position: "Midfielder",
    firstLetter: "E"
  },
  {
    name: "Cole Palmer",
    aliases: ["palmer", "cole palmer"],
    club: "Chelsea",
    flag: "🏴󠁧󠁢󠁥󠁮󠁧󠁿",
    country: "England",
    position: "Midfielder",
    firstLetter: "C"
  },
  {
    name: "Declan Rice",
    aliases: ["rice", "declan rice"],
    club: "Arsenal",
    flag: "🏴󠁧󠁢󠁥󠁮󠁧󠁿",
    country: "England",
    position: "Midfielder",
    firstLetter: "D"
  },
  {
    name: "William Saliba",
    aliases: ["saliba", "william saliba"],
    club: "Arsenal",
    flag: "🇫🇷",
    country: "France",
    position: "Defender",
    firstLetter: "W"
  },
  {
    name: "Gabriel Martinelli",
    aliases: ["martinelli", "gabriel martinelli"],
    club: "Arsenal",
    flag: "🇧🇷",
    country: "Brazil",
    position: "Forward",
    firstLetter: "G"
  },
  {
    name: "Gabriel Jesus",
    aliases: ["jesus", "gabriel jesus"],
    club: "Arsenal",
    flag: "🇧🇷",
    country: "Brazil",
    position: "Forward",
    firstLetter: "G"
  },
  {
    name: "Luis Díaz",
    aliases: ["diaz", "luis diaz", "luis díaz"],
    club: "Liverpool",
    flag: "🇨🇴",
    country: "Colombia",
    position: "Forward",
    firstLetter: "L"
  },
  {
    name: "Darwin Núñez",
    aliases: ["nunez", "darwin nunez", "darwin núñez"],
    club: "Liverpool",
    flag: "🇺🇾",
    country: "Uruguay",
    position: "Forward",
    firstLetter: "D"
  },
  {
    name: "Trent Alexander-Arnold",
    aliases: ["alexander-arnold", "trent alexander-arnold", "taa", "trent"],
    club: "Liverpool",
    flag: "🏴󠁧󠁢󠁥󠁮󠁧󠁿",
    country: "England",
    position: "Defender",
    firstLetter: "T"
  },
  {
    name: "Andrew Robertson",
    aliases: ["robertson", "andy robertson", "andrew robertson"],
    club: "Liverpool",
    flag: "🏴󠁧󠁢󠁳󠁣󠁴󠁿",
    country: "Scotland",
    position: "Defender",
    firstLetter: "A"
  },
  {
    name: "Rúben Dias",
    aliases: ["dias", "ruben dias", "rúben dias"],
    club: "Manchester City",
    flag: "🇵🇹",
    country: "Portugal",
    position: "Defender",
    firstLetter: "R"
  },
  {
    name: "Kyle Walker",
    aliases: ["walker", "kyle walker"],
    club: "Manchester City",
    flag: "🏴󠁧󠁢󠁥󠁮󠁧󠁿",
    country: "England",
    position: "Defender",
    firstLetter: "K"
  },
  {
    name: "Ederson Moraes",
    aliases: ["ederson", "ederson moraes"],
    club: "Manchester City",
    flag: "🇧🇷",
    country: "Brazil",
    position: "Goalkeeper",
    firstLetter: "E"
  },
  {
    name: "Jack Grealish",
    aliases: ["grealish", "jack grealish"],
    club: "Manchester City",
    flag: "🏴󠁧󠁢󠁥󠁮󠁧󠁿",
    country: "England",
    position: "Forward",
    firstLetter: "J"
  },
  {
    name: "Jérémy Doku",
    aliases: ["doku", "jeremy doku", "jérémy doku"],
    club: "Manchester City",
    flag: "🇧🇪",
    country: "Belgium",
    position: "Forward",
    firstLetter: "J"
  },
  {
    name: "Joško Gvardiol",
    aliases: ["gvardiol", "josko gvardiol", "joško gvardiol"],
    club: "Manchester City",
    flag: "🇭🇷",
    country: "Croatia",
    position: "Defender",
    firstLetter: "J"
  },
  {
    name: "Ilkay Gündogan",
    aliases: ["gundogan", "ilkay gundogan", "ilkay gündogan"],
    club: "Manchester City",
    flag: "🇩🇪",
    country: "Germany",
    position: "Midfielder",
    firstLetter: "I"
  },
  {
    name: "Leroy Sané",
    aliases: ["sane", "leroy sane", "leroy sané"],
    club: "Bayern Munich",
    flag: "🇩🇪",
    country: "Germany",
    position: "Forward",
    firstLetter: "L"
  },
  {
    name: "Kingsley Coman",
    aliases: ["coman", "kingsley coman"],
    club: "Bayern Munich",
    flag: "🇫🇷",
    country: "France",
    position: "Forward",
    firstLetter: "K"
  },
  {
    name: "Serge Gnabry",
    aliases: ["gnabry", "serge gnabry"],
    club: "Bayern Munich",
    flag: "🇩🇪",
    country: "Germany",
    position: "Forward",
    firstLetter: "S"
  },
  {
    name: "Alphonso Davies",
    aliases: ["davies", "alphonso davies"],
    club: "Bayern Munich",
    flag: "🇨🇦",
    country: "Canada",
    position: "Defender",
    firstLetter: "A"
  },
  {
    name: "Joshua Kimmich",
    aliases: ["kimmich", "joshua kimmich"],
    club: "Bayern Munich",
    flag: "🇩🇪",
    country: "Germany",
    position: "Midfielder",
    firstLetter: "J"
  },
  {
    name: "Thomas Müller",
    aliases: ["muller", "thomas muller", "thomas müller"],
    club: "Bayern Munich",
    flag: "🇩🇪",
    country: "Germany",
    position: "Forward",
    firstLetter: "T"
  },
  {
    name: "Leon Goretzka",
    aliases: ["goretzka", "leon goretzka"],
    club: "Bayern Munich",
    flag: "🇩🇪",
    country: "Germany",
    position: "Midfielder",
    firstLetter: "L"
  },
  {
    name: "Dayot Upamecano",
    aliases: ["upamecano", "dayot upamecano"],
    club: "Bayern Munich",
    flag: "🇫🇷",
    country: "France",
    position: "Defender",
    firstLetter: "D"
  },
  {
    name: "Kim Min-jae",
    aliases: ["kim", "min-jae kim", "kim min jae", "kim min-jae"],
    club: "Bayern Munich",
    flag: "🇰🇷",
    country: "South Korea",
    position: "Defender",
    firstLetter: "K"
  },
  {
    name: "Ronald Araújo",
    aliases: ["araujo", "ronald araujo", "ronald araújo"],
    club: "Barcelona",
    flag: "🇺🇾",
    country: "Uruguay",
    position: "Defender",
    firstLetter: "R"
  },
  {
    name: "Jules Koundé",
    aliases: ["kounde", "jules kounde", "jules koundé"],
    club: "Barcelona",
    flag: "🇫🇷",
    country: "France",
    position: "Defender",
    firstLetter: "J"
  },
  {
    name: "Raphinha Dias",
    aliases: ["raphinha", "raphina"],
    club: "Barcelona",
    flag: "🇧🇷",
    country: "Brazil",
    position: "Forward",
    firstLetter: "R"
  },
  {
    name: "Lamine Yamal",
    aliases: ["yamal", "lamine yamal", "lamine"],
    club: "Barcelona",
    flag: "🇪🇸",
    country: "Spain",
    position: "Forward",
    firstLetter: "L"
  },
  {
    name: "João Félix",
    aliases: ["felix", "joao felix", "joão félix"],
    club: "Chelsea",
    flag: "🇵🇹",
    country: "Portugal",
    position: "Forward",
    firstLetter: "J"
  },
  {
    name: "João Cancelo",
    aliases: ["cancelo", "joao cancelo", "joão cancelo"],
    club: "Al Hilal",
    flag: "🇵🇹",
    country: "Portugal",
    position: "Defender",
    firstLetter: "J"
  },
  {
    name: "Achraf Hakimi",
    aliases: ["hakimi", "achraf hakimi"],
    club: "PSG",
    flag: "🇲🇦",
    country: "Morocco",
    position: "Defender",
    firstLetter: "A"
  },
  {
    name: "Ousmane Dembélé",
    aliases: ["dembele", "ousmane dembele", "ousmane dembélé"],
    club: "PSG",
    flag: "🇫🇷",
    country: "France",
    position: "Forward",
    firstLetter: "O"
  },
  {
    name: "Warren Zaïre-Emery",
    aliases: ["zaire-emery", "warren zaire-emery", "warren zaire emery"],
    club: "PSG",
    flag: "🇫🇷",
    country: "France",
    position: "Midfielder",
    firstLetter: "W"
  },
  {
    name: "Marquinhos Correa",
    aliases: ["marquinhos"],
    club: "PSG",
    flag: "🇧🇷",
    country: "Brazil",
    position: "Defender",
    firstLetter: "M"
  },
  {
    name: "Gianluigi Donnarumma",
    aliases: ["donnarumma", "gianluigi donnarumma"],
    club: "PSG",
    flag: "🇮🇹",
    country: "Italy",
    position: "Goalkeeper",
    firstLetter: "G"
  },
  {
    name: "Vitinha Ferreira",
    aliases: ["vitinha"],
    club: "PSG",
    flag: "🇵🇹",
    country: "Portugal",
    position: "Midfielder",
    firstLetter: "V"
  },
  {
    name: "Bradley Barcola",
    aliases: ["barcola", "bradley barcola"],
    club: "PSG",
    flag: "🇫🇷",
    country: "France",
    position: "Forward",
    firstLetter: "B"
  },
  {
    name: "Nico Williams",
    aliases: ["nicolas williams", "nico williams"],
    club: "Athletic Bilbao",
    flag: "🇪🇸",
    country: "Spain",
    position: "Forward",
    firstLetter: "N"
  },
  {
    name: "Dani Olmo",
    aliases: ["olmo", "dani olmo"],
    club: "Barcelona",
    flag: "🇪🇸",
    country: "Spain",
    position: "Midfielder",
    firstLetter: "D"
  },
  {
    name: "Álvaro Morata",
    aliases: ["morata", "alvaro morata", "álvaro morata"],
    club: "AC Milan",
    flag: "🇪🇸",
    country: "Spain",
    position: "Forward",
    firstLetter: "A"
  },
  {
    name: "Alejandro Grimaldo",
    aliases: ["grimaldo", "alejandro grimaldo"],
    club: "Bayer Leverkusen",
    flag: "🇪🇸",
    country: "Spain",
    position: "Defender",
    firstLetter: "A"
  },
  {
    name: "Granit Xhaka",
    aliases: ["xhaka", "granit xhaka"],
    club: "Bayer Leverkusen",
    flag: "🇨🇭",
    country: "Switzerland",
    position: "Midfielder",
    firstLetter: "G"
  },
  {
    name: "Jeremie Frimpong",
    aliases: ["frimpong", "jeremie frimpong"],
    club: "Bayer Leverkusen",
    flag: "🇳🇱",
    country: "Netherlands",
    position: "Defender",
    firstLetter: "J"
  },
  {
    name: "Victor Boniface",
    aliases: ["boniface", "victor boniface"],
    club: "Bayer Leverkusen",
    flag: "🇳🇬",
    country: "Nigeria",
    position: "Forward",
    firstLetter: "V"
  },
  {
    name: "Hakan Çalhanoğlu",
    aliases: ["calhanoglu", "hakan calhanoglu", "hakan çalhanoğlu"],
    club: "Inter Milan",
    flag: "🇹🇷",
    country: "Turkey",
    position: "Midfielder",
    firstLetter: "H"
  },
  {
    name: "Nicolò Barella",
    aliases: ["barella", "nicolo barella", "nicolò barella"],
    club: "Inter Milan",
    flag: "🇮🇹",
    country: "Italy",
    position: "Midfielder",
    firstLetter: "N"
  },
  {
    name: "Marcus Thuram",
    aliases: ["thuram", "marcus thuram"],
    club: "Inter Milan",
    flag: "🇫🇷",
    country: "France",
    position: "Forward",
    firstLetter: "M"
  },
  {
    name: "Alessandro Bastoni",
    aliases: ["bastoni", "alessandro bastoni"],
    club: "Inter Milan",
    flag: "🇮🇹",
    country: "Italy",
    position: "Defender",
    firstLetter: "A"
  },
  {
    name: "Yann Sommer",
    aliases: ["sommer", "yann sommer"],
    club: "Inter Milan",
    flag: "🇨🇭",
    country: "Switzerland",
    position: "Goalkeeper",
    firstLetter: "Y"
  },
  {
    name: "Theo Hernández",
    aliases: ["hernandez", "theo hernandez", "theo hernández"],
    club: "AC Milan",
    flag: "🇫🇷",
    country: "France",
    position: "Defender",
    firstLetter: "T"
  },
  {
    name: "Mike Maignan",
    aliases: ["maignan", "mike maignan"],
    club: "AC Milan",
    flag: "🇫🇷",
    country: "France",
    position: "Goalkeeper",
    firstLetter: "M"
  },
  {
    name: "Dušan Vlahović",
    aliases: ["vlahovic", "dusan vlahovic", "dušan vlahović"],
    club: "Juventus",
    flag: "🇷🇸",
    country: "Serbia",
    position: "Forward",
    firstLetter: "D"
  },
  {
    name: "Federico Chiesa",
    aliases: ["chiesa", "federico chiesa"],
    club: "Liverpool",
    flag: "🇮🇹",
    country: "Italy",
    position: "Forward",
    firstLetter: "F"
  },
  {
    name: "Bremer Silva",
    aliases: ["bremer"],
    club: "Juventus",
    flag: "🇧🇷",
    country: "Brazil",
    position: "Defender",
    firstLetter: "B"
  },
  {
    name: "Paulo Dybala",
    aliases: ["dybala", "paulo dybala"],
    club: "AS Roma",
    flag: "🇦🇷",
    country: "Argentina",
    position: "Forward",
    firstLetter: "P"
  },
  {
    name: "Romelu Lukaku",
    aliases: ["lukaku", "romelu lukaku"],
    club: "Napoli",
    flag: "🇧🇪",
    country: "Belgium",
    position: "Forward",
    firstLetter: "R"
  },
  {
    name: "Victor Gyökeres",
    aliases: ["gyokeres", "victor gyokeres", "victor gyökeres"],
    club: "Sporting CP",
    flag: "🇸🇪",
    country: "Sweden",
    position: "Forward",
    firstLetter: "V"
  },
  {
    name: "Sadio Mané",
    aliases: ["mane", "sadio mane", "sadio mané"],
    club: "Al Nassr",
    flag: "🇸🇳",
    country: "Senegal",
    position: "Forward",
    firstLetter: "S"
  },
  {
    name: "Riyad Mahrez",
    aliases: ["mahrez", "riyad mahrez"],
    club: "Al Ahli",
    flag: "🇩🇿",
    country: "Algeria",
    position: "Forward",
    firstLetter: "R"
  },
  {
    name: "N'Golo Kanté",
    aliases: ["kante", "ngolo kante", "n'golo kante", "n'golo kanté"],
    club: "Al Ittihad",
    flag: "🇫🇷",
    country: "France",
    position: "Midfielder",
    firstLetter: "N"
  },
  {
    name: "Kalidou Koulibaly",
    aliases: ["koulibaly", "kalidou koulibaly"],
    club: "Al Hilal",
    flag: "🇸🇳",
    country: "Senegal",
    position: "Defender",
    firstLetter: "K"
  },
  {
    name: "Sergej Milinković-Savić",
    aliases: ["milinkovic-savic", "sms", "sergej milinkovic-savic", "sergej milinković-savić"],
    club: "Al Hilal",
    flag: "🇷🇸",
    country: "Serbia",
    position: "Midfielder",
    firstLetter: "S"
  },
  {
    name: "Aleksandar Mitrović",
    aliases: ["mitrovic", "aleksandar mitrovic", "aleksandar mitrović"],
    club: "Al Hilal",
    flag: "🇷🇸",
    country: "Serbia",
    position: "Forward",
    firstLetter: "A"
  },
  {
    name: "Roberto Firmino",
    aliases: ["firmino", "roberto firmino", "bobby firmino"],
    club: "Al Ahli",
    flag: "🇧🇷",
    country: "Brazil",
    position: "Forward",
    firstLetter: "R"
  },
  {
    name: "Marcelo Vieira",
    aliases: ["marcelo"],
    club: "Fluminense",
    flag: "🇧🇷",
    country: "Brazil",
    position: "Defender",
    firstLetter: "M"
  },
  {
    name: "James Rodríguez",
    aliases: ["james rodriguez", "james", "james rodríguez"],
    club: "Rayo Vallecano",
    flag: "🇨🇴",
    country: "Colombia",
    position: "Midfielder",
    firstLetter: "J"
  },
  {
    name: "Edinson Cavani",
    aliases: ["cavani", "edinson cavani"],
    club: "Boca Juniors",
    flag: "🇺🇾",
    country: "Uruguay",
    position: "Forward",
    firstLetter: "E"
  },
  {
    name: "Luis Suárez",
    aliases: ["suarez", "luis suarez", "luis suárez"],
    club: "Inter Miami",
    flag: "🇺🇾",
    country: "Uruguay",
    position: "Forward",
    firstLetter: "L"
  }
];
